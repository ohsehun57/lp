class Rectangulo:
    def __init__(self, color, base, altura):
        self.color = color
        self.base = base
        self.altura = altura

    def calcular_area(self):
        return self.base * self.altura

    def calcular_perimetro(self):
        return 2 * (self.base + self.altura)


# Ingreso de datos para el primer rectángulo
color1 = input("Ingrese el color del primer rectángulo: ")
base1 = float(input(f"Ingrese la base del rectángulo {color1}: "))
altura1 = float(input(f"Ingrese la altura del rectángulo {color1}: "))

# Ingreso de datos para el segundo rectángulo
color2 = input("Ingrese el color del segundo rectángulo: ")
base2 = float(input(f"Ingrese la base del rectángulo {color2}: "))
altura2 = float(input(f"Ingrese la altura del rectángulo {color2}: "))

# Crear objetos rectángulo
rectangulo1 = Rectangulo(color1, base1, altura1)
rectangulo2 = Rectangulo(color2, base2, altura2)

# Crear referencias
ref1 = rectangulo1
ref2 = rectangulo2

# Mostrar resultados usando ref1
area1 = ref1.calcular_area()
perimetro1 = ref1.calcular_perimetro()
print(f"\n[Rectángulo 1: {ref1.color}]")
print(f"Área: {area1:.2f}")
print(f"Perímetro: {perimetro1:.2f}")

# Mostrar resultados usando ref2
area2 = ref2.calcular_area()
perimetro2 = ref2.calcular_perimetro()
print(f"\n[Rectángulo 2: {ref2.color}]")
print(f"Área: {area2:.2f}")
print(f"Perímetro: {perimetro2:.2f}")
