import re

class PasoAPasoSolverConsola:
    def __init__(self):
        self._entrada = ""
        self._resultado_texto = []

    def get_entrada(self):
        return self._entrada

    def set_entrada(self, valor):
        self._entrada = valor.strip()

    def get_resultado(self):
        return "\n".join(self._resultado_texto)

    def set_resultado(self, texto):
        self._resultado_texto = texto.strip().split('\n')

    def _imprimir(self, texto, etiqueta='default'):
        colores = {
            'azul': '\033[94m',
            'verde': '\033[92m',
            'rojo': '\033[91m',
            'negro': '\033[30m',
            'gris': '\033[90m',
            'default': '\033[0m'
        }
        color = colores.get(etiqueta, colores['default'])
        reset = '\033[0m'
        print(f"{color}{texto}{reset}")
        self._resultado_texto.append(texto)

    def resolver(self):
        self._resultado_texto.clear()
        entrada = self.get_entrada().replace(" ", "")
        patron = r"([+-]?\d*)x([+-]?\d+)?=([+-]?\d+)"
        match = re.match(patron, entrada)

        if not match:
            self._imprimir("❌ Ecuación no válida. Usa el formato ax + b = c", 'rojo')
            return

        coef_str, constante_str, lado_derecho_str = match.groups()
        if coef_str in ("", "+", "-"):
            coef_str += "1"

        try:
            a = int(coef_str)
            b = int(constante_str) if constante_str else 0
            c = int(lado_derecho_str)
        except ValueError:
            self._imprimir("❌ Error en los coeficientes", 'rojo')
            return

        self._imprimir("\n📘 Paso 1: Ecuación original", 'azul')
        self._imprimir(f"   {a}x + ({b}) = {c}", 'negro')

        self._imprimir("\n🧮 Paso 2: Restamos {} a ambos lados".format(b), 'azul')
        self._imprimir(f"   {a}x = {c} - ({b})", 'gris')

        resta = c - b
        self._imprimir("\n🧮 Paso 3: Simplificamos", 'azul')
        self._imprimir(f"   {a}x = {resta}", 'gris')

        if a == 0:
            if b == c:
                self._imprimir("✅ Resultado: Infinitas soluciones.", 'verde')
            else:
                self._imprimir("❌ Resultado: Sin solución (a = 0).", 'rojo')
        else:
            self._imprimir(f"\n🧮 Paso 4: Dividimos entre {a} ambos lados", 'azul')
            self._imprimir(f"   x = {resta} / {a}", 'gris')
            x = resta / a
            self._imprimir(f"\n✅ Resultado final: x = {x}", 'verde')

    def borrar(self):
        self._entrada = ""
        self._resultado_texto.clear()

# Clase heredada con método adicional
class SolverAvanzadoConsola(PasoAPasoSolverConsola):
    def mostrar_creditos(self):
        self._imprimir("\n🧑‍💻 Desarrollado por Raúl Cristian Chura Chambilla", 'gris')


def main():
    solver = SolverAvanzadoConsola()
    print("📌 Bienvenido al solucionador de ecuaciones (ax + b = c)\n")

    while True:
        ecuacion = input("Ingresa la ecuación (o escribe 'salir' para terminar): ").strip()
        if ecuacion.lower() == 'salir':
            break
        solver.set_entrada(ecuacion)
        solver.resolver()
        solver.mostrar_creditos()
        print("\n" + "-"*60 + "\n")

if __name__ == "__main__":
    main()
