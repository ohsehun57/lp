import tkinter as tk
from tkinter import ttk, messagebox, colorchooser

class Rectangulo:
    """Clase que representa un rectángulo con base, altura y color."""
    
    def __init__(self, base, altura, color):
        """Inicializa un rectángulo con valores base, altura y color."""
        self.base = base
        self.altura = altura
        self.color = color
    
    def area(self):
        """Calcula y retorna el área del rectángulo."""
        return self.base * self.altura
    
    def perimetro(self):
        """Calcula y retorna el perímetro del rectángulo."""
        return 2 * (self.base + self.altura)
        
    def mostrar_info(self):
        """Retorna una cadena con la información del rectángulo."""
        return f"Base: {self.base}, Altura: {self.altura}, Color: {self.color}"


class VisualizadorRectangulos:
    """Aplicación para visualizar y comparar rectángulos."""
    
    def __init__(self, ventana):
        """Inicializa la aplicación con la ventana principal."""
        self.ventana = ventana
        self.ventana.title("Visualizador de Rectángulos Interactivo")
        self.ventana.geometry("800x600")
        self.ventana.config(bg="#f0f4f8")
        self.ventana.resizable(True, True)
        
        # Valores por defecto
        self.rectangulos = [
            Rectangulo(10, 6, "#1E88E5"),  # Azul
            Rectangulo(7, 3, "#FF9800")    # Naranja
        ]
        
        self.escala = 15  # Factor de escala para visualización
        
        # Crear interfaz
        self.crear_interfaz()
        
        # Mostrar rectángulos iniciales
        self.mostrar_rectangulos()
    
    def crear_interfaz(self):
        """Crea todos los elementos de la interfaz."""
        # Estilo para los widgets
        self.estilo = ttk.Style()
        self.estilo.configure("TButton", font=("Helvetica", 10))
        self.estilo.configure("TLabel", background="#f0f4f8", font=("Helvetica", 10))
        self.estilo.configure("Titulo.TLabel", font=("Helvetica", 16, "bold"), background="#f0f4f8")
        
        # Frame principal
        main_frame = ttk.Frame(self.ventana, padding="20")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Título
        titulo = ttk.Label(main_frame, text="Visualizador de Rectángulos Interactivo", style="Titulo.TLabel")
        titulo.pack(pady=10)
        
        # Canvas para mostrar rectángulos
        self.canvas_frame = ttk.Frame(main_frame)
        self.canvas_frame.pack(fill=tk.BOTH, expand=True, pady=10)
        
        self.canvas = tk.Canvas(self.canvas_frame, bg="white", bd=2, relief="groove")
        self.canvas.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Frame para controles
        controles_frame = ttk.Frame(main_frame)
        controles_frame.pack(fill=tk.X, pady=10)
        
        # Frames para controles de cada rectángulo
        self.crear_controles_rectangulo(controles_frame, 0, "Rectángulo 1")
        self.crear_controles_rectangulo(controles_frame, 1, "Rectángulo 2")
        
        # Frame para botones inferiores
        botones_frame = ttk.Frame(main_frame)
        botones_frame.pack(fill=tk.X, pady=10)
        
        # Botón para mostrar información
        btn_mostrar = ttk.Button(botones_frame, text="Mostrar Información", command=self.mostrar_info)
        btn_mostrar.pack(side=tk.LEFT, padx=5)
        
        # Botón para comparar
        btn_comparar = ttk.Button(botones_frame, text="Comparar Rectángulos", command=self.comparar_rectangulos)
        btn_comparar.pack(side=tk.LEFT, padx=5)
        
        # Frame para información
        info_frame = ttk.Frame(main_frame)
        info_frame.pack(fill=tk.X, pady=10)
        
        # Etiquetas para mostrar información
        self.etiquetas_info = []
        for i in range(2):
            etiqueta = ttk.Label(info_frame, text="", wraplength=700)
            etiqueta.pack(anchor=tk.W, pady=2)
            self.etiquetas_info.append(etiqueta)
        
        # Etiqueta para comparación
        self.etiqueta_comparacion = ttk.Label(info_frame, text="", wraplength=700)
        self.etiqueta_comparacion.pack(anchor=tk.W, pady=5)
        
    def crear_controles_rectangulo(self, parent, indice, titulo):
        """Crea controles para modificar un rectángulo específico."""
        frame = ttk.LabelFrame(parent, text=titulo)
        frame.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        
        # Variables para los controles
        self.vars_base = [tk.StringVar(value=str(self.rectangulos[0].base)), 
                         tk.StringVar(value=str(self.rectangulos[1].base))]
        self.vars_altura = [tk.StringVar(value=str(self.rectangulos[0].altura)), 
                           tk.StringVar(value=str(self.rectangulos[1].altura))]
        
        # Controles para base
        ttk.Label(frame, text="Base:").grid(row=0, column=0, padx=5, pady=5, sticky=tk.W)
        entrada_base = ttk.Entry(frame, width=8, textvariable=self.vars_base[indice])
        entrada_base.grid(row=0, column=1, padx=5, pady=5)
        
        # Controles para altura
        ttk.Label(frame, text="Altura:").grid(row=1, column=0, padx=5, pady=5, sticky=tk.W)
        entrada_altura = ttk.Entry(frame, width=8, textvariable=self.vars_altura[indice])
        entrada_altura.grid(row=1, column=1, padx=5, pady=5)
        
        # Botón para elegir color
        ttk.Button(frame, text="Elegir Color", 
                  command=lambda idx=indice: self.elegir_color(idx)).grid(row=2, column=0, padx=5, pady=5)
        
        # Botón para actualizar
        ttk.Button(frame, text="Actualizar", 
                  command=lambda idx=indice: self.actualizar_rectangulo(idx)).grid(row=2, column=1, padx=5, pady=5)
    
    def elegir_color(self, indice):
        """Abre un selector de color y actualiza el color del rectángulo."""
        color_actual = self.rectangulos[indice].color
        color = colorchooser.askcolor(color_actual)[1]
        if color:
            self.rectangulos[indice].color = color
            self.mostrar_rectangulos()
    
    def actualizar_rectangulo(self, indice):
        """Actualiza las dimensiones del rectángulo con los valores ingresados."""
        try:
            base = float(self.vars_base[indice].get())
            altura = float(self.vars_altura[indice].get())
            
            # Validación
            if base <= 0 or altura <= 0:
                messagebox.showerror("Error", "La base y altura deben ser mayores que cero.")
                return
                
            # Limitar tamaño para que sea visible
            if base > 30:
                base = 30
                self.vars_base[indice].set(str(base))
                messagebox.showinfo("Información", "La base se ha limitado a 30 para mejor visualización.")
                
            if altura > 20:
                altura = 20
                self.vars_altura[indice].set(str(altura))
                messagebox.showinfo("Información", "La altura se ha limitado a 20 para mejor visualización.")
            
            # Actualizar rectángulo
            self.rectangulos[indice].base = base
            self.rectangulos[indice].altura = altura
            
            # Actualizar visualización
            self.mostrar_rectangulos()
            
        except ValueError:
            messagebox.showerror("Error", "Por favor ingrese valores numéricos válidos.")
    
    def mostrar_rectangulos(self):
        """Muestra los rectángulos en el canvas y actualiza la información."""
        self.canvas.delete("all")
        
        # Obtener dimensiones del canvas
        canvas_width = self.canvas.winfo_width()
        canvas_height = self.canvas.winfo_height()
        
        # Si el canvas aún no tiene dimensiones (al inicio), usar valores predeterminados
        if canvas_width <= 1:
            canvas_width = 700
        if canvas_height <= 1:
            canvas_height = 300
        
        # Calcular posiciones para centrar los rectángulos
        pos_x1 = 50
        pos_y1 = canvas_height // 4
        pos_x2 = canvas_width // 2 + 50
        pos_y2 = canvas_height // 4
        
        # Dibujar rectángulos
        self.canvas.create_rectangle(
            pos_x1, pos_y1, 
            pos_x1 + self.rectangulos[0].base * self.escala, 
            pos_y1 + self.rectangulos[0].altura * self.escala, 
            fill=self.rectangulos[0].color,
            outline="black",
            width=2
        )
        
        self.canvas.create_rectangle(
            pos_x2, pos_y2, 
            pos_x2 + self.rectangulos[1].base * self.escala, 
            pos_y2 + self.rectangulos[1].altura * self.escala, 
            fill=self.rectangulos[1].color,
            outline="black",
            width=2
        )
        
        # Etiquetas con dimensiones
        self.canvas.create_text(
            pos_x1 + (self.rectangulos[0].base * self.escala) / 2,
            pos_y1 + (self.rectangulos[0].altura * self.escala) / 2,
            text=f"{self.rectangulos[0].base} x {self.rectangulos[0].altura}",
            fill="white" if self.es_color_oscuro(self.rectangulos[0].color) else "black",
            font=("Helvetica", 12, "bold")
        )
        
        self.canvas.create_text(
            pos_x2 + (self.rectangulos[1].base * self.escala) / 2,
            pos_y2 + (self.rectangulos[1].altura * self.escala) / 2,
            text=f"{self.rectangulos[1].base} x {self.rectangulos[1].altura}",
            fill="white" if self.es_color_oscuro(self.rectangulos[1].color) else "black",
            font=("Helvetica", 12, "bold")
        )
        
        # Actualizar información
        self.mostrar_info()
    
    def es_color_oscuro(self, color):
        """Determina si un color es oscuro para elegir el color de texto adecuado."""
        # Convertir el color hexadecimal a RGB
        r = int(color[1:3], 16)
        g = int(color[3:5], 16)
        b = int(color[5:7], 16)
        
        # Fórmula para calcular la luminosidad percibida
        luminosidad = (0.299 * r + 0.587 * g + 0.114 * b) / 255
        
        # Si la luminosidad es menor a 0.5, el color es oscuro
        return luminosidad < 0.5
    
    def mostrar_info(self):
        """Actualiza las etiquetas con la información de los rectángulos."""
        for i in range(2):
            self.etiquetas_info[i].config(
                text=f"Rectángulo {i+1}: {self.rectangulos[i].mostrar_info()} | "
                     f"Área: {self.rectangulos[i].area():.2f} | "
                     f"Perímetro: {self.rectangulos[i].perimetro():.2f}"
            )
    
    def comparar_rectangulos(self):
        """Compara los dos rectángulos y muestra el resultado."""
        r1, r2 = self.rectangulos
        
        # Comparar áreas
        if r1.area() > r2.area():
            texto_area = f"El Rectángulo 1 tiene mayor área ({r1.area():.2f} vs {r2.area():.2f})"
        elif r2.area() > r1.area():
            texto_area = f"El Rectángulo 2 tiene mayor área ({r2.area():.2f} vs {r1.area():.2f})"
        else:
            texto_area = f"Ambos rectángulos tienen la misma área ({r1.area():.2f})"
        
        # Comparar perímetros
        if r1.perimetro() > r2.perimetro():
            texto_perimetro = f"El Rectángulo 1 tiene mayor perímetro ({r1.perimetro():.2f} vs {r2.perimetro():.2f})"
        elif r2.perimetro() > r1.perimetro():
            texto_perimetro = f"El Rectángulo 2 tiene mayor perímetro ({r2.perimetro():.2f} vs {r1.perimetro():.2f})"
        else:
            texto_perimetro = f"Ambos rectángulos tienen el mismo perímetro ({r1.perimetro():.2f})"
        
        # Actualizar etiqueta de comparación
        self.etiqueta_comparacion.config(
            text=f"Comparación: {texto_area}. {texto_perimetro}."
        )


if __name__ == "__main__":
    # Crear ventana principal
    ventana = tk.Tk()
    
    # Iniciar aplicación
    app = VisualizadorRectangulos(ventana)
    
    # Ajustar el tamaño del canvas cuando se redimensiona la ventana
    def on_resize(event):
        app.mostrar_rectangulos()
    
    ventana.bind("<Configure>", on_resize)
    
    # Iniciar bucle de la ventana
    ventana.mainloop()