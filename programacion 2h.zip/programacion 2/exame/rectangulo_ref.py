class Rectangulo:
    def __init__(self, color, base, altura):
        self.color = color
        self.base = base
        self.altura = altura

    def calcular_area(self):
        return self.base * self.altura

    def calcular_perimetro(self):
        return 2 * (self.base + self.altura)
    def mostrar_info(self):
        print(f"rectangulode base {self.base} , de altura{self.altura} , de color{self.color}")



color1 = input("Ingrese el color del primer rectángulo: ")
base1 = float(input(f"Ingrese la base del rectángulo {color1}: "))
altura1 = float(input(f"Ingrese la altura del rectángulo {color1}: "))


color2 = input("Ingrese el color del segundo rectángulo: ")
base2 = float(input(f"Ingrese la base del rectángulo {color2}: "))
altura2 = float(input(f"Ingrese la altura del rectángulo {color2}: "))


rectangulo1 = Rectangulo(color1, base1, altura1)
rectangulo2 = Rectangulo(color2, base2, altura2)

ref1 = rectangulo1
ref2 = rectangulo2

ref1.mostrar_info()
print(f"area: {ref1.calcular_area()} ,  perimetro: {ref1.calcular_perimetro()}")

ref2.mostrar_info()
print(f"area: {ref2.calcular_area()} ,  perimetro: {ref2.calcular_perimetro()}")