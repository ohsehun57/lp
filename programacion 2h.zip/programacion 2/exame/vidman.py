import tkinter as tk
from tkinter import ttk
import math

# Clases de las figuras
class Figura:
    def _init_(self, tipo):
        self.tipo = tipo

class Cuadrado(Figura):
    def _init_(self, lado):
        super()._init_("Cuadrado")
        self.lado = lado

    def calcular_area(self):
        return self.lado ** 2

    def calcular_perimetro(self):
        return 4 * self.lado

class Rectangulo(Figura):
    def _init_(self, base, altura):
        super()._init_("Rectángulo")
        self.base = base
        self.altura = altura

    def calcular_area(self):
        return self.base * self.altura

    def calcular_perimetro(self):
        return 2 * (self.base + self.altura)

class Triangulo(Figura):
    def _init_(self, base, altura):
        super()._init_("Triángulo")
        self.base = base
        self.altura = altura

    def calcular_area(self):
        return (self.base * self.altura) / 2

    def calcular_perimetro(self):
        lado = math.sqrt((self.base / 2) * 2 + self.altura * 2)
        return self.base + 2 * lado

class Circulo(Figura):
    def _init_(self, radio):
        super()._init_("Círculo")
        self.radio = radio

    def calcular_area(self):
        return math.pi * self.radio ** 2

    def calcular_perimetro(self):
        return 2 * math.pi * self.radio

# Funciones
def mostrar_formulario(figura):
    for widget in marco_formulario.winfo_children():
        widget.destroy()
    etiquetas_resultado.config(text="")

    if figura == "Cuadrado":
        crear_entrada("Lado:", lambda valor: calcular(Cuadrado(float(valor))))
    elif figura == "Rectángulo":
        crear_dos_entradas("Base:", "Altura:", lambda b, h: calcular(Rectangulo(float(b), float(h))))
    elif figura == "Triángulo":
        crear_dos_entradas("Base:", "Altura:", lambda b, h: calcular(Triangulo(float(b), float(h))))
    elif figura == "Círculo":
        crear_entrada("Radio:", lambda valor: calcular(Circulo(float(valor))))

def crear_entrada(etiqueta_texto, funcion):
    ttk.Label(marco_formulario, text=etiqueta_texto, font=("Arial", 12)).grid(row=0, column=0, pady=5)
    entrada = ttk.Entry(marco_formulario)
    entrada.grid(row=0, column=1, pady=5)
    ttk.Button(marco_formulario, text="Calcular", command=lambda: funcion(entrada.get())).grid(row=1, columnspan=2, pady=10)

def crear_dos_entradas(et1, et2, funcion):
    ttk.Label(marco_formulario, text=et1, font=("Arial", 12)).grid(row=0, column=0, pady=5)
    entrada1 = ttk.Entry(marco_formulario)
    entrada1.grid(row=0, column=1, pady=5)

    ttk.Label(marco_formulario, text=et2, font=("Arial", 12)).grid(row=1, column=0, pady=5)
    entrada2 = ttk.Entry(marco_formulario)
    entrada2.grid(row=1, column=1, pady=5)

    ttk.Button(marco_formulario, text="Calcular", command=lambda: funcion(entrada1.get(), entrada2.get())).grid(row=2, columnspan=2, pady=10)

def calcular(figura):
    area = figura.calcular_area()
    perimetro = figura.calcular_perimetro()
    etiquetas_resultado.config(
        text=f"FIGURA: {figura.tipo}\nÁrea: {area:.2f}\nPerímetro: {perimetro:.2f}",
        foreground="blue"
    )

# Ventana principal
ventana = tk.Tk()
ventana.title("Calculadora de Área y Perímetro")
ventana.geometry("500x400")
ventana.configure(bg="#f0f8ff")

# Menú
barra_menu = tk.Menu(ventana)
ventana.config(menu=barra_menu)

menu_principal = tk.Menu(barra_menu, tearoff=0)
barra_menu.add_cascade(label="Menú", menu=menu_principal)
menu_principal.add_command(label="Inicio", command=lambda: etiquetas_resultado.config(text=""))
menu_principal.add_command(label="Ayuda", command=lambda: etiquetas_resultado.config(text="Selecciona una figura y proporciona sus medidas."))
menu_principal.add_command(label="Teoría", command=lambda: etiquetas_resultado.config(text="Calculadora de área y perímetro para figuras planas: cuadrado, rectángulo, triángulo y círculo."))
menu_principal.add_command(label="Acerca de", command=lambda: etiquetas_resultado.config(text="Hecho por [Tu Nombre] con ❤️ en Python y Tkinter."))
menu_principal.add_separator()
menu_principal.add_command(label="Salir", command=ventana.quit)

# Título
titulo = ttk.Label(ventana, text="Calculadora de Área y Perímetro", font=("Helvetica", 16, "bold"), background="#f0f8ff", foreground="#2a4d69")
titulo.pack(pady=15)

# Botones
marco_botones = tk.Frame(ventana, bg="#f0f8ff")
marco_botones.pack(pady=10)

for figura in ["Cuadrado", "Rectángulo", "Triángulo", "Círculo"]:
    ttk.Button(marco_botones, text=figura, width=15, command=lambda f=figura: mostrar_formulario(f)).pack(pady=5)

# Formulario
marco_formulario = tk.Frame(ventana, bg="#f0f8ff")
marco_formulario.pack(pady=10)

# Resultado
etiquetas_resultado = ttk.Label(ventana, text="", font=("Arial", 12), background="#f0f8ff")
etiquetas_resultado.pack(pady=10)

ventana.mainloop()