from OpenGL.GL import *
from OpenGL.GLUT import *
from OpenGL.GLU import *

class TrianguloApp:
    def __init__(self, ancho=500, alto=500, titulo="Triángulo en PyOpenGL"):
        self.ancho = ancho
        self.alto = alto
        self.titulo = titulo
        self.init_glut()

    def init_glut(self):
        glutInit()
        glutInitDisplayMode(GLUT_RGBA | GLUT_SINGLE)
        glutInitWindowSize(self.ancho, self.alto)
        glutInitWindowPosition(100, 100)
        glutCreateWindow(self.titulo.encode("utf-8"))  # Usar encode para pasar texto con acentos
        glutDisplayFunc(self.dibujar)
        self.configurar_ventana()

    def configurar_ventana(self):
        glClearColor(0.0, 0.0, 0.0, 0.0)  # Fondo blanco
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()
        gluOrtho2D(-1.0, 1.0, -1.0, 1.0)  # Coordenadas 2D

    def dibujar(self):
        glClear(GL_COLOR_BUFFER_BIT)
        glPointSize(2)
        glBegin(GL_POINTS)
        glColor3f(1.0, 0.0, 0.0); glVertex2f(-0.5, -0.5)
        glColor3f(0.0, 1.0, 0.0); glVertex2f(0.5, -0.5)
        glColor3f(0.0, 0.0, 1.0); glVertex2f(0.0, 0.5)
        glEnd()

        glFlush()

    def ejecutar(self):
        glutMainLoop()


if __name__ == "__main__":
    app = TrianguloApp()
    app.ejecutar()
