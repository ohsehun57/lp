from OpenGL.GL import *
from OpenGL.GLU import *
from OpenGL.GLUT import *

# Ángulos de rotación
rot_x = 0
rot_y = 0

def init():
    glClearColor(0.1, 0.1, 0.1, 1.0)  # Fondo oscuro
    glEnable(GL_DEPTH_TEST)

    # Activar iluminación
    glEnable(GL_LIGHTING)
    glEnable(GL_LIGHT0)  # Luz 0 por defecto

    # Parámetros de la luz
    light_position = [1.0, 1.0, 2.0, 0.0]  # Luz direccional
    light_diffuse = [1.0, 1.0, 1.0, 1.0]   # Luz blanca
    light_specular = [1.0, 1.0, 1.0, 1.0]

    glLightfv(GL_LIGHT0, GL_POSITION, light_position)
    glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse)
    glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular)

    # Material
    glEnable(GL_COLOR_MATERIAL)
    glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE)
    glMaterialfv(GL_FRONT, GL_SPECULAR, [1.0, 1.0, 1.0, 1.0])
    glMateriali(GL_FRONT, GL_SHININESS, 50)

def display():
    global rot_x, rot_y
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    glLoadIdentity()

    # Cámara
    gluLookAt(0, 0, 6, 0, 0, 0, 0, 1, 0)

    # Rotación
    glRotatef(rot_x, 1.0, 0.0, 0.0)
    glRotatef(rot_y, 0.0, 1.0, 0.0)

    # Dibujar tetera con color
    glColor3f(0.9, 0.4, 0.1)
    #glutWireTeapot(1.0)
    #glutWireCone(1,3,40,10)
    glutWireCylinder(1,3,40,10)
    #glutWireTorus(0.3,0.8,20,20)
    #glutWireIcosahedron()
    #glutWireOctahedron()

    glutSwapBuffers()

def reshape(w, h):
    if h == 0:
        h = 1
    aspect = w / h
    glViewport(0, 0, w, h)
    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()
    gluPerspective(45, aspect, 1, 100)
    glMatrixMode(GL_MODELVIEW)

def keyboard(key, x, y):
    global rot_x, rot_y
    if key == b'w':
        rot_x -= 5
    elif key == b's':
        rot_x += 5
    elif key == b'a':
        rot_y -= 5
    elif key == b'd':
        rot_y += 5
    elif key == b'\x1b':  # ESC
        glutLeaveMainLoop()
    glutPostRedisplay()

def main():
    glutInit()
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH)
    glutInitWindowSize(600, 600)
    glutCreateWindow(b"Tetera 3D")
    init()
    glutDisplayFunc(display)
    glutReshapeFunc(reshape)
    glutKeyboardFunc(keyboard)
    glutMainLoop()

if __name__ == "__main__":
    main()
