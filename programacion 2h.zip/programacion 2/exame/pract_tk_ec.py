import re
import tkinter as tk
from tkinter import ttk, filedialog
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas

class PasoAPasoSolver:
    def __init__(self, root):
        self._root = root
        self._root.title("🧮 Ecuación Paso a Paso")
        self._root.geometry("700x700")
        self._root.configure(bg="#ecf0f3")

        self._entrada = None
        self._texto_resultado = None
        self._resultado_texto = []  # Guarda el contenido para PDF

        self.style = ttk.Style()
        self.style.theme_use("clam")
        self.style.configure('TLabel', background='#ecf0f3', font=('Segoe UI', 12))
        self.style.configure('TEntry', font=('Consolas', 14))
        self.style.configure('TButton', font=('Segoe UI', 12, 'bold'), background='#3498db', foreground='white')

        self._construir_interfaz()

    def get_entrada(self):
        return self._entrada.get()

    def set_entrada(self, valor):
        self._entrada.delete(0, tk.END)
        self._entrada.insert(0, valor)

    def get_resultado(self):
        return self._texto_resultado.get('1.0', tk.END)

    def set_resultado(self, texto):
        self._texto_resultado.config(state='normal')
        self._texto_resultado.delete('1.0', tk.END)
        self._texto_resultado.insert(tk.END, texto)
        self._texto_resultado.config(state='disabled')

    def _construir_interfaz(self):
        titulo = ttk.Label(self._root, text="🔎 Resolver ecuación ax + b = c paso a paso",
                           font=('Segoe UI', 18, 'bold'), background='#ecf0f3', foreground='#2c3e50')
        titulo.pack(pady=(20, 10))

        entrada_frame = ttk.Frame(self._root)
        entrada_frame.pack(pady=10)

        ttk.Label(entrada_frame, text="Ingresa ecuación:", font=('Segoe UI', 12)).pack(side='left', padx=5)

        self._entrada = ttk.Entry(entrada_frame, width=35)
        self._entrada.pack(side='left', padx=5)
        self._entrada.bind('<Return>', self._resolver)

        ttk.Button(entrada_frame, text="Resolver", command=self._resolver).pack(side='left', padx=5)
        ttk.Button(entrada_frame, text="Borrar", command=self._borrar).pack(side='left', padx=5)
        ttk.Button(entrada_frame, text="Descargar PDF", command=self._descargar_pdf).pack(side='left', padx=5)

        self._texto_resultado = tk.Text(self._root, height=25, width=80, font=('Consolas', 12), wrap='word',
                                        bg='white', borderwidth=1, relief='solid')
        self._texto_resultado.pack(pady=10, padx=10, fill='both', expand=True)

        scrollbar = ttk.Scrollbar(self._texto_resultado, command=self._texto_resultado.yview)
        self._texto_resultado.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side='right', fill='y')

    def _imprimir(self, texto, etiqueta='default'):
        colores = {
            'azul': '#2980b9',
            'verde': '#27ae60',
            'rojo': '#c0392b',
            'negro': '#2c3e50',
            'gris': '#7f8c8d',
            'default': 'black'
        }
        self._texto_resultado.tag_config(etiqueta, foreground=colores.get(etiqueta, 'black'))
        self._texto_resultado.insert(tk.END, texto + '\n', etiqueta)
        self._texto_resultado.see(tk.END)
        self._resultado_texto.append(texto)

    def _resolver(self, event=None):
        self._texto_resultado.config(state='normal')
        self._texto_resultado.delete('1.0', tk.END)
        self._resultado_texto.clear()

        entrada = self.get_entrada().replace(" ", "")
        patron = r"([+-]?\d*)x([+-]?\d+)?=([+-]?\d+)"
        match = re.match(patron, entrada)

        if not match:
            self._imprimir("❌ Ecuación no válida. Usa el formato ax + b = c", 'rojo')
            return

        coef_str, constante_str, lado_derecho_str = match.groups()
        if coef_str in ("", "+", "-"):
            coef_str += "1"

        try:
            a = int(coef_str)
            b = int(constante_str) if constante_str else 0
            c = int(lado_derecho_str)
        except ValueError:
            self._imprimir("❌ Error en los coeficientes", 'rojo')
            return

        self._imprimir(f"\n📘 Paso 1: Ecuación original", 'azul')
        self._imprimir(f"   {a}x + ({b}) = {c}", 'negro')

        self._imprimir(f"\n🧮 Paso 2: Restamos {b} a ambos lados", 'azul')
        self._imprimir(f"   {a}x = {c} - ({b})", 'gris')

        resta = c - b
        self._imprimir(f"\n🧮 Paso 3: Simplificamos", 'azul')
        self._imprimir(f"   {a}x = {resta}", 'gris')

        if a == 0:
            if b == c:
                self._imprimir("✅ Resultado: Infinitas soluciones.", 'verde')
            else:
                self._imprimir("❌ Resultado: Sin solución (a = 0).", 'rojo')
        else:
            self._imprimir(f"\n🧮 Paso 4: Dividimos entre {a} ambos lados", 'azul')
            self._imprimir(f"   x = {resta} / {a}", 'gris')
            x = resta / a
            self._imprimir(f"\n✅ Resultado final: x = {x}", 'verde')

        self._texto_resultado.config(state='disabled')

    def _borrar(self):
        self._entrada.delete(0, tk.END)
        self._texto_resultado.config(state='normal')
        self._texto_resultado.delete('1.0', tk.END)
        self._texto_resultado.config(state='disabled')
        self._resultado_texto.clear()

    def _descargar_pdf(self):
        if not self._resultado_texto:
            return
        archivo = filedialog.asksaveasfilename(defaultextension=".pdf", filetypes=[("PDF Files", "*.pdf")])
        if not archivo:
            return

        c = canvas.Canvas(archivo, pagesize=letter)
        width, height = letter
        y = height - 40
        for linea in self._resultado_texto:
            c.drawString(40, y, linea)
            y -= 20
            if y < 40:
                c.showPage()
                y = height - 40
        c.save()

# Clase heredada
class SolverAvanzado(PasoAPasoSolver):
    def mostrar_creditos(self):
        self._imprimir("\n🧑‍💻 Desarrollado por Raúl Cristian Chura Chambilla", 'gris')

def main():
    root = tk.Tk()
    app = SolverAvanzado(root)
    app.mostrar_creditos()
    root.mainloop()

if __name__ == "__main__":
    main()
