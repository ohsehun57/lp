'''class Rectangulo:
    def __init__(self,color, base, altura):
        self.color = color
        self.base = base
        self.altura = altura
        self.area = self.base * self.altura
        self.perimetro = (self.base + self.altura) * 2
        print(f"Constructor: rectangulo creado con longitud {self.base} y ancho {self.altura} y color {ref2}")

    def mostrar_area(self):
        print(f"El area del rectangulo es: {self.area}")

    def mostrar_perimetro(self):
        print(f"El perimetro del rectangulo es: {self.perimetro}")

    def __del__(self):
        print("Destructor: rectangulo eliminado")

color = input("ingrese el color")
base = float(input("Ingrese el valor de la longitud: "))
altura = float(input("Ingrese el valor del ancho: "))
 
rectangulo1 = Rectangulo("color",base, altura)
rectangulo2 = Rectangulo("color",base, altura)
ref1=rectangulo1
ref2=rectangulo2

rectangulo1.mostrar_area()
rectangulo1.mostrar_perimetro()


rectangulo1.__del__()'''

class Rectangulo:
    def __init__(self, color, base, altura):
        self.color = color
        self.base = base
        self.altura = altura
        self.area = self.base * self.altura
        self.perimetro = (self.base + self.altura) * 2
        print(f"Constructor: rectángulo creado con longitud {self.base}, ancho {self.altura} y color {self.color}")

    def mostrar_area(self):
        print(f"El área del rectángulo es: {self.area}")

    def mostrar_perimetro(self):
        print(f"El perímetro del rectángulo es: {self.perimetro}")

    def __del__(self):
        print("Destructor: rectángulo eliminado")



color = input("Ingrese el color: ")
base = float(input("Ingrese el valor de la longitud: "))
altura = float(input("Ingrese el valor del ancho: "))


rectangulo1 = Rectangulo(color, base, altura)
rectangulo2 = Rectangulo(color, base, altura)
ref1 = rectangulo1
ref2 = rectangulo2

rectangulo1.mostrar_area()
rectangulo1.mostrar_perimetro()

def __del__(self):
        print("Destructor: rectángulo eliminado")

