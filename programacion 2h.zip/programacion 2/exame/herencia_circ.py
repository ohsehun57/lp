import math

class Figura:
    def __init__(self, color): 
        self.color = color
    
    def mostrar_info(self):
        print(f"El color de la figura es: {self.color}")

class Circulo(Figura):
    def __init__(self, color, radio):
        super().__init__(color)
        self.radio = radio

    def calcular_area(self):
        return math.pi * self.radio ** 2

    def calcular_perimetro(self):
        return 2 * math.pi * self.radio

    def mostrar_info(self):
        super().mostrar_info()
        print(f" Círculo")
        print(f"Radio: {self.radio}")
        print(f"Área: {self.calcular_area():.2f}")
        print(f"Perímetro: {self.calcular_perimetro():.2f}")

# Crear objetos
f1 = Figura("Rojo")
c1 = Circulo("Azul", 5)

# Mostrar información
f1.mostrar_info()
print()
c1.mostrar_info()
