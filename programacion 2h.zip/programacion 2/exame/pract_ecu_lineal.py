import re

class EcuacionLineal:
    def __init__(self, ecuacion):
        self._ecuacion = ecuacion.replace(" ", "")  # Encapsulamiento

    def get_ecuacion(self):
        return self._ecuacion

    def set_ecuacion(self, nueva_ecuacion):
        self._ecuacion = nueva_ecuacion.replace(" ", "")

    def resolver(self):
        patron = r"([+-]?\d*)x([+-]?\d+)?=([+-]?\d+)"
        match = re.match(patron, self._ecuacion)

        if not match:
            print("❌ Ecuación no válida. Usa el formato ax + b = c")
            return

        coef_str, constante_str, lado_derecho_str = match.groups()

        if coef_str in ("", "+", "-"):
            coef_str += "1"
        if constante_str is None:
            constante_str = "0"

        # Mostrar ecuación original con strings
        print(f"\n📘 Paso 1: Ecuación original")
        print(f"   {coef_str}x + ({constante_str}) = {lado_derecho_str}")

        print(f"\n🧮 Paso 2: Restamos {constante_str} a ambos lados")
        print(f"   {coef_str}x = {lado_derecho_str} - ({constante_str})")

        # Ahora hacemos la conversión a enteros más abajo
        try:
            a = int(coef_str)
            b = int(constante_str)
            c = int(lado_derecho_str)
        except ValueError:
            print("❌ Error en los coeficientes numéricos.")
            return

        resta = c - b
        print(f"\n🧮 Paso 3: Simplificamos")
        print(f"   {a}x = {resta}")

        if a == 0:
            if b == c:
                print("✅ Resultado: Infinitas soluciones.")
            else:
                print("❌ Resultado: Sin solución (a = 0).")
            return

        print(f"\n🧮 Paso 4: Dividimos entre {a} ambos lados")
        print(f"   x = {resta} / {a}")
        x = resta / a
        print(f"\n✅ Resultado final: x = {x}")

class EcuacionConCreditos(EcuacionLineal):
    def mostrar_creditos(self):
        print("\n🧑‍💻 Desarrollado por Raúl Cristian Chura Chambilla")

if __name__ == "__main__":
    entrada = input("Ingrese una ecuación lineal (formato ax + b = c): ")
    solver = EcuacionConCreditos(entrada)
    solver.resolver()
    solver.mostrar_creditos()
