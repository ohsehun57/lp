# Inicializamos los 5 conjuntos vacíos
matriz = [set() for _ in range(5)]

# Lista de operaciones (a, o, pag)
operaciones = [
    (1, 2, 2),  # inserta 1 en los dos primeros
    (2, 4, 2),  # invierte los primeros 4 conjuntos
    (1, 5, 3),  # inserta 3 en todos
    (2, 3, 1),  # invierte los primeros 3
    (1, 1, 3),  # inserta 5 en el primero
    (2, 2, 2),  # invierte los primeros 2
    (3, 3, 3),  # elimina 3 de todos
    (3, 1, 2),  # elimina 1 de todos
    (3, 5, 5),  # elimina 5 de todos
    (3, 2, 4)   # elimina 2 de todos
]

# Lista para guardar los resultados (mínimo del conjunto en pag-1)
resultados = []

for idx, (a, o, pag) in enumerate(operaciones):
    if a == 1:
        # Inserción: insertar número (idx+1)*2 - 1 en los primeros o conjuntos
        num_insertar = (idx + 1) * 2 - 1
        for i in range(o):
            matriz[i].add(num_insertar)
    elif a == 2:
        # Inversión: invertir los primeros o conjuntos
        matriz[:o] = matriz[:o][::-1]
    elif a == 3:
        # Eliminación: eliminar número o de todos los conjuntos
        num_eliminar = o
        for i in range(5):
            matriz[i].discard(num_eliminar)

    # Determinar el mínimo del conjunto en posición pag-1
    conjunto_actual = matriz[pag - 1]
    if conjunto_actual:
        min_valor = min(conjunto_actual)
    else:
        min_valor = 0
    resultados.append(min_valor)

    # Mostrar estado después de cada operación (opcional)
    print(f"Operación {idx+1}: matriz = {matriz}, mínimo en conjunto {pag} = {min_valor}")

# Resultado final
print("\nResultados finales por operación:")
print(resultados)
