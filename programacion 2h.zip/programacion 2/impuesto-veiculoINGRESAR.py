
from abc import ABC, abstractmethod
import math

# Clase AbsT
class Vehiculo(ABC):
    def __init__(self, marca, modelo, anio):
        ANIO_actual = 2025 
        if not (1980 <= anio <= ANIO_actual):
            raise AnioInvalidoError(f"El año debe estar entre 1980 y {ANIO_actual}.")
        self.marca = marca
        self.modelo = modelo
        self.anio = anio

    @abstractmethod
    def calcular_impuesto(self):
        pass

    def mostrar_info(self):
        print(f"Marca: {self.marca}, Modelo: {self.modelo}, Año: {self.anio}")
        
class AnioInvalidoError(ValueError):
    pass

# CLASE HIJA PPIIPIP
class Auto(Vehiculo):
    def __init__(self, marca, modelo, anio):
        super().__init__(marca, modelo, anio)

    def calcular_impuesto(self):
        return 0.05 * (2025 - self.anio)

class Motocicleta(Vehiculo):
    def __init__(self, marca, modelo, anio):
        super().__init__(marca, modelo, anio)

    def calcular_impuesto(self):
        return 0.03 * (2025 - self.anio)

class Camioneta(Vehiculo):
    def __init__(self, marca, modelo, anio):
        super().__init__(marca, modelo, anio)

    def calcular_impuesto(self):
        if self.anio > 2015:
            return 500
        else:
            return 300


def gestionar_vehiculos():
    vehiculos = []
    
    while True:
        print("\n==== Menú de Gestión de Vehículos ====")
        print("1. Agregar nuevo vehículo")
        print("2. Mostrar todos los vehículos registrados y sus impuestos")
        print("3. Salir del programa")
        
        opcion = input("Seleccione una opción (1, 2 o 3): ").strip()

        if opcion == '1':
            print("\n--- Agregar Vehículo ---")
            tipo_vehiculo = input("Ingrese el tipo de vehículo (auto, motocicleta, camioneta): ").lower()

            try:
                marca = input("Ingrese la marca: ")
                modelo = input("Ingrese el modelo: ")
                anio = int(input("Ingrese el año: "))

                vehiculo_creado = None
                if tipo_vehiculo == 'auto':
                    vehiculo_creado = Auto(marca, modelo, anio)
                elif tipo_vehiculo == 'motocicleta':
                    vehiculo_creado = Motocicleta(marca, modelo, anio)
                elif tipo_vehiculo == 'camioneta':
                    vehiculo_creado = Camioneta(marca, modelo, anio)
                else:
                    print("Tipo de vehículo no reconocido. Por favor, elija entre 'auto', 'motocicleta' o 'camioneta'.")
                    continue
                
                vehiculos.append(vehiculo_creado)
                print(f"¡{tipo_vehiculo.capitalize()} '{marca} {modelo}' agregado exitosamente!")
               
                print(f"Impuesto calculado para este vehículo: ${vehiculo_creado.calcular_impuesto():.2f}")

            except ValueError:
                print("Error: El año debe ser un número entero válido.")
            except AnioInvalidoError as e:
                print(f"Error al crear vehículo: {e}")
            except Exception as e:
                print(f"Ocurrió un error inesperado: {e}")
        
        elif opcion == '2':
          
            if vehiculos:
                print("\n--- Información de Todos los Vehículos Registrados ---")
                for vehiculo in vehiculos:
                    vehiculo.mostrar_info()
                    print(f"Impuesto: ${vehiculo.calcular_impuesto():.2f}\n")
            else:
                print("\nNo se han registrado vehículos todavía.")

        elif opcion == '3':
            print("Saliendo del programa. ¡Hasta luego!")
            break
        
        else:
            print("Opción no válida. Por favor, elija 1, 2 o 3.")

if __name__ == "__main__":
    gestionar_vehiculos()
    
1"""


from abc import ABC, abstractmethod
import math

# Clase AbsT
class Vehiculo(ABC):
    def __init__(self, marca, modelo, anio):
        ANIO_actual = 2025 
        if not (1980 <= anio <= ANIO_actual):
            raise AnioInvalidoError(f"El año debe estar entre 1980 y {ANIO_actual}.")
        self.marca = marca
        self.modelo = modelo
        self.anio = anio

    @abstractmethod
    def calcular_impuesto(self):
        pass

    def mostrar_info(self):
        print(f"Marca: {self.marca}, Modelo: {self.modelo}, Año: {self.anio}")
        
class AnioInvalidoError(ValueError):
    pass

# CLASE HIJA PPIIPIP
class Auto(Vehiculo):
    def __init__(self, marca, modelo, anio):
        super().__init__(marca, modelo, anio)

    def calcular_impuesto(self):
        return 0.05 * (2025 - self.anio)

class Motocicleta(Vehiculo):
    def __init__(self, marca, modelo, anio):
        super().__init__(marca, modelo, anio)

    def calcular_impuesto(self):
        return 0.03 * (2025 - self.anio)

# Pregunta Extra: Clase Camioneta
class Camioneta(Vehiculo):
    def __init__(self, marca, modelo, anio):
        super().__init__(marca, modelo, anio)

    def calcular_impuesto(self):
        if self.anio > 2015:
            return 500
        else:
            return 300

# Refactored gestionar_vehiculos function
def gestionar_vehiculos():
    vehiculos = []
    
    while True:
        print("\n--- Agregar Vehículo ---")
        tipo_vehiculo = input("Ingrese el tipo de vehículo (auto, motocicleta, camioneta) o 'salir' para terminar: ").lower()

        if tipo_vehiculo == 'salir':
            break

        try:
            marca = input("Ingrese la marca: ")
            modelo = input("Ingrese el modelo: ")
            anio = int(input("Ingrese el año: "))

            if tipo_vehiculo == 'auto':
                vehiculo = Auto(marca, modelo, anio)
            elif tipo_vehiculo == 'motocicleta':
                vehiculo = Motocicleta(marca, modelo, anio)
            elif tipo_vehiculo == 'camioneta':
                vehiculo = Camioneta(marca, modelo, anio)
            else:
                print("Tipo de vehículo no reconocido. Intente de nuevo.")
                continue
            
            vehiculos.append(vehiculo)
            print(f"¡{tipo_vehiculo.capitalize()} '{marca} {modelo}' agregado exitosamente!")
            # AQUÍ SE MUESTRA EL IMPUESTO INMEDIATAMENTE DESPUÉS DE AGREGARLO
            print(f"Impuesto calculado para este vehículo: ${vehiculo.calcular_impuesto():.2f}")

        except ValueError:
            print("Error: El año debe ser un número entero válido.")
        except AnioInvalidoError as e:
            print(f"Error al crear vehículo: {e}")
        except Exception as e:
            print(f"Ocurrió un error inesperado: {e}")

    # Parte 3: Polimorfismo - Mostrar información de todos los vehículos (esto se mantiene)
    if vehiculos:
        print("\n--- Información de Todos los Vehículos Registrados ---")
        for vehiculo in vehiculos:
            vehiculo.mostrar_info()
            print(f"Impuesto: ${vehiculo.calcular_impuesto():.2f}\n")
    else:
        print("\nNo se registraron vehículos.")

# Ejecutar el sistema
if __name__ == "__main__":
    gestionar_vehiculos()"""