import os

class Libro:
    # Constructor: Ahora acepta un parámetro 'disponible' con valor por defecto True
    def __init__(self, codigo, titulo, autor, disponible=True):
        self.__codigo = codigo          # Atributo privado
        self.__titulo = titulo          # Atributo privado
        self.__autor = autor            # Atributo privado
        self.__disponible = disponible  # Atributo privado, su estado se carga o es por defecto
        print(f"Libro '{self.__titulo}' creado.")

    def __del__(self):
        print(f"Libro '{self.__titulo}' eliminado.")

    def mostrar_info(self):
        estado = "Disponible" if self.__disponible else "Reservado"
        print(f"Código: {self.__codigo}")
        print(f"Título: {self.__titulo}")
        print(f"Autor: {self.__autor}")
        print(f"Estado: {estado}")

    def reservar(self):
        if self.__disponible:
            self.__disponible = False
            return True
        else:
            return False

    def cancelar_reserva(self):
        self.__disponible = True

    def esta_disponible(self):
        return self.__disponible

    # Getters para acceder a los atributos privados
    def get_codigo(self):
        return self.__codigo

    def get_titulo(self):
        return self.__titulo

    def get_autor(self):
        return self.__autor


class Usuario:
    def __init__(self, dni, nombre):
        self.__dni = dni      # Atributo privado
        self.__nombre = nombre  # Atributo privado
        print(f"Usuario '{self.__nombre}' creado.")

    def __del__(self):
        print(f"Usuario '{self.__nombre}' eliminado.")

    def mostrar_info(self):
        print(f"DNI: {self.__dni}")
        print(f"Nombre: {self.__nombre}")

    # Getters para acceder a los atributos privados
    def get_dni(self):
        return self.__dni

    def get_nombre(self):
        return self.__nombre


class Reserva:
    # Constructor: Ahora acepta un parámetro 'activa' con valor por defecto True para nuevas reservas
    def __init__(self, usuario, libro, activa=True):
        self.__usuario = usuario  # Atributo privado (referencia al objeto Usuario)
        self.__libro = libro      # Atributo privado (referencia al objeto Libro)
        self.__activa = activa    # Atributo privado, su estado se carga o es por defecto

        # Solo intenta reservar el libro si la reserva es nueva y el libro está realmente disponible
        if activa and libro.esta_disponible():
            libro.reservar()
            print(f"Reserva creada para {usuario.get_nombre()} y libro '{libro.get_titulo()}'.")
        elif not activa:
            # Mensaje para cuando se carga una reserva existente (activa o inactiva)
            print(f"Reserva cargada (estado {'activa' if activa else 'inactiva'}) para {usuario.get_nombre()} y libro '{libro.get_titulo()}'.")
        else:
            print(f"Error: Libro '{libro.get_titulo()}' no disponible para crear/cargar reserva.")


    def __del__(self):
        print(f"Reserva para {self.__usuario.get_nombre()} y libro '{self.__libro.get_titulo()}' eliminada.")

    def mostrar_info(self):
        if self.__activa:
            print(f"{self.__usuario.get_nombre()} reservó el libro '{self.__libro.get_titulo()}'")
        else:
            print(f"Reserva inactiva para {self.__usuario.get_nombre()} y libro '{self.__libro.get_titulo()}'.")

    def cancelar(self):
        # Solo cancela la reserva del libro si la reserva actual está activa
        if self.__activa:
            self.__libro.cancelar_reserva()
            self.__activa = False
            print("Reserva cancelada.")
        else:
            print("La reserva ya está inactiva o no se puede cancelar.")


    def es_activa(self):
        return self.__activa

    # Getters para acceder a los atributos privados
    def get_usuario_dni(self):
        return self.__usuario.get_dni()

    def get_libro_codigo(self):
        return self.__libro.get_codigo()


class Biblioteca:
    def __init__(self):
        self.__libros = []    # Lista privada de objetos Libro
        self.__usuarios = []  # Lista privada de objetos Usuario
        self.__reservas = []  # Lista privada de objetos Reserva
        print("Biblioteca creada.")
        self.cargar_datos() # Cargar datos al iniciar la biblioteca

    def __del__(self):
        print("Biblioteca eliminada.")
        self.guardar_datos() # Guardar datos al salir

    def guardar_datos(self):
        # Guardar libros
        with open("libros.txt", "w") as f:
            for l in self.__libros: # Acceso directo al atributo privado
                # Guardamos el estado de disponibilidad del libro
                f.write(f"{l.get_codigo()},{l.get_titulo()},{l.get_autor()},{int(l.esta_disponible())}\n")

        # Guardar usuarios
        with open("usuarios.txt", "w") as f:
            for u in self.__usuarios: # Acceso directo al atributo privado
                f.write(f"{u.get_dni()},{u.get_nombre()}\n")

        # Guardar reservas activas
        with open("reservas.txt", "w") as f:
            for r in self.__reservas: # Acceso directo al atributo privado
                if r.es_activa(): # Solo guardamos reservas activas para simplificar la carga
                    f.write(f"{r.get_usuario_dni()},{r.get_libro_codigo()}\n")

    def cargar_datos(self):
        if os.path.exists("libros.txt"):
            with open("libros.txt", "r") as f:
                for line in f:
                    codigo, titulo, autor, disponible_str = line.strip().split(",")
                    # Convertir 'disponible_str' a booleano
                    disponible = bool(int(disponible_str))
                    libro = Libro(codigo, titulo, autor, disponible=disponible)
                    self.__libros.append(libro) # Acceso directo al atributo privado

        if os.path.exists("usuarios.txt"):
            with open("usuarios.txt", "r") as f:
                for line in f:
                    dni, nombre = line.strip().split(",")
                    usuario = Usuario(dni, nombre)
                    self.__usuarios.append(usuario) # Acceso directo al atributo privado

        if os.path.exists("reservas.txt"):
            with open("reservas.txt", "r") as f:
                for line in f:
                    dni, codigo_libro = line.strip().split(",")
                    # Buscar los objetos Usuario y Libro correspondientes en las listas privadas
                    usuario = next((u for u in self.__usuarios if u.get_dni() == dni), None)
                    libro = next((l for l in self.__libros if l.get_codigo() == codigo_libro), None)

                    # Importante: Solo crear la reserva si el usuario y el libro existen
                    if usuario and libro:
                        # Si el libro está no disponible, significa que la reserva estaba activa
                        # al momento de guardar. Creamos la reserva como activa.
                        reserva = Reserva(usuario, libro, activa=True)
                        self.__reservas.append(reserva) # Acceso directo al atributo privado
                    else:
                        print(f"Advertencia: No se pudo cargar la reserva para DNI: {dni}, Código Libro: {codigo_libro}. Usuario o libro no encontrado.")


    def registrar_libro(self):
        codigo = input("Código del libro: ")
        if any(l.get_codigo() == codigo for l in self.__libros): # Acceso directo
            print("❌ Ya existe un libro con ese código.")
            return
        titulo = input("Título del libro: ")
        autor = input("Autor: ")
        libro = Libro(codigo, titulo, autor)
        self.__libros.append(libro) # Añadir a la lista privada
        self.guardar_datos()
        print("✅ Libro registrado.\n")

    def registrar_usuario(self):
        dni = input("DNI del usuario: ")
        if any(u.get_dni() == dni for u in self.__usuarios): # Acceso directo
            print("❌ Ya existe un usuario con ese DNI.")
            return
        nombre = input("Nombre del usuario: ")
        usuario = Usuario(dni, nombre)
        self.__usuarios.append(usuario) # Añadir a la lista privada
        self.guardar_datos()
        print("✅ Usuario registrado.\n")

    def hacer_reserva(self):
        dni = input("DNI del usuario: ")
        codigo = input("Código del libro a reservar: ")

        usuario = next((u for u in self.__usuarios if u.get_dni() == dni), None) # Acceso directo
        libro = next((l for l in self.__libros if l.get_codigo() == codigo), None) # Acceso directo

        if not usuario:
            print("❌ Usuario no encontrado.")
            return
        if not libro:
            print("❌ Libro no encontrado.")
            return
        if not libro.esta_disponible():
            print("❌ Libro ya está reservado.")
            return
        # Validar que el usuario no tenga la misma reserva activa del libro
        for r in self.__reservas: # Acceso directo al atributo privado
            if r.get_usuario_dni() == dni and r.get_libro_codigo() == codigo and r.es_activa():
                print("❌ El usuario ya tiene reservado este libro.")
                return

        # Crear la reserva, la clase Reserva se encargará de marcar el libro como no disponible
        reserva = Reserva(usuario, libro)
        if reserva.es_activa(): # Verificar si la reserva se creó correctamente (libro disponible)
            self.__reservas.append(reserva) # Añadir a la lista privada
            self.guardar_datos()
            reserva.mostrar_info()
        else:
            print("❌ No se pudo realizar la reserva.")

    def cancelar_reserva(self):
        dni = input("DNI del usuario: ")
        codigo = input("Código del libro a cancelar: ")

        encontrada = False
        for r in self.__reservas: # Acceso directo al atributo privado
            if r.get_usuario_dni() == dni and r.get_libro_codigo() == codigo and r.es_activa():
                r.cancelar()
                encontrada = True
                break # Salir del bucle una vez que se cancela la reserva
        
        if encontrada:
            self.guardar_datos()
        else:
            print("❌ Reserva no encontrada o ya cancelada.")

    def mostrar_libros_disponibles(self):
        print("\n📗 Libros disponibles:")
        disponibles_encontrados = False
        for l in self.__libros: # Acceso directo al atributo privado
            if l.esta_disponible():
                l.mostrar_info()
                print()
                disponibles_encontrados = True
        if not disponibles_encontrados:
            print("No hay libros disponibles en este momento.")


    def mostrar_libros_reservados(self):
        print("\n📕 Libros reservados:")
        reservados_encontrados = False
        for l in self.__libros: # Acceso directo al atributo privado
            if not l.esta_disponible():
                l.mostrar_info()
                print()
                reservados_encontrados = True
        if not reservados_encontrados:
            print("No hay libros reservados en este momento.")

    def buscar_libro(self):
        criterio = input("Buscar por (titulo/autor): ").lower()
        texto = input("Texto a buscar: ").lower()
        encontrados = []
        if criterio == "titulo":
            encontrados = [l for l in self.__libros if texto in l.get_titulo().lower()] # Acceso directo
        elif criterio == "autor":
            encontrados = [l for l in self.__libros if texto in l.get_autor().lower()] # Acceso directo
        else:
            print("❌ Criterio inválido.")
            return

        if encontrados:
            print(f"\n🔍 Libros encontrados por {criterio}:")
            for l in encontrados:
                l.mostrar_info()
                print()
        else:
            print("No se encontraron libros con ese criterio.")

    def menu(self):
        while True:
            print("""
===== SISTEMA DE GESTION DE RESERVAS =====
1. Registrar libro
2. Registrar usuario
3. Hacer reserva
4. Cancelar reserva
5. Mostrar libros disponibles
6. Mostrar libros reservados
7. Buscar libro
0. Salir
""")
            op = input("Opción: ")
            if op == "1":
                self.registrar_libro()
            elif op == "2":
                self.registrar_usuario()
            elif op == "3":
                self.hacer_reserva()
            elif op == "4":
                self.cancelar_reserva()
            elif op == "5":
                self.mostrar_libros_disponibles()
            elif op == "6":
                self.mostrar_libros_reservados()
            elif op == "7":
                self.buscar_libro()
            elif op == "0":
                print("Hasta pronto.")
                self.guardar_datos() # Asegurarse de guardar al salir
                break
            else:
                print("❌ Opción inválida.\n")


# --------------------------
# Ejecutar programa

if __name__ == "__main__":
    biblioteca = Biblioteca()
    biblioteca.menu()