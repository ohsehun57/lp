import tkinter as tk
from tkinter import messagebox
from abc import ABC, abstractmethod
import math

# --- Clases de FORMA (Estructura Original) ---

class FORMA(ABC):
    @abstractmethod
    def calcula_area(self):
        pass

class cuadrado(FORMA):
    def __init__(self, lado):
        if lado <= 0:
            raise ValueError("El lado debe ser mayor que 0.")
        self.lado = lado

    def calcula_area(self):
        return self.lado**2

class triangulo(FORMA):
    def __init__(self, base, altura):
        if base <= 0 or altura <= 0:
            raise ValueError("Base y altura deben ser mayores que 0.")
        self.base = base
        self.altura = altura

    def calcula_area(self):
        return (self.base * self.altura) / 2

class rectangulo(FORMA):
    def __init__(self, ancho, largo):
        if ancho <= 0 or largo <= 0:
            raise ValueError("Ancho y largo deben ser mayores que 0.")
        self.ancho = ancho
        self.largo = largo

    def calcula_area(self):
        return (self.ancho * self.largo)

class circulo(FORMA):
    def __init__(self, radio):
        if radio <= 0:
            raise ValueError("El radio debe ser mayor que 0.")
        self.radio = radio

    def calcula_area(self):
        return self.radio**2 * math.pi

# --- Aplicación Tkinter ---

class AreaCalculatorApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Calculadora de Área de Figuras Geométricas")
        
        # Configurar la ventana para pantalla completa
        self.root.attributes('-fullscreen', True)
        self.root.bind('<Escape>', lambda e: self.root.attributes('-fullscreen', False)) # Salir con Esc

        # Estilos modernos con colores agradables
        self.bg_color = "#2c3e50"  # Azul oscuro (fondo principal)
        self.frame_bg_color = "#34495e" # Azul oscuro más claro
        self.text_color = "#ecf0f1" # Blanco grisáceo para texto
        self.accent_color = "#3498db" # Azul brillante para botones/resaltados
        self.entry_bg = "#ecf0f1" # Fondo claro para campos de entrada
        self.canvas_bg = "#ffffff" # Fondo blanco para el canvas de dibujo
        self.figure_color = "#e74c3c" # Rojo para las figuras dibujadas

        self.root.config(bg=self.bg_color)
        self.root.option_add('*Font', 'SegoeUI 12') # Fuente más moderna
        self.root.option_add('*Label.Foreground', self.text_color)
        self.root.option_add('*Frame.Background', self.bg_color)
        self.root.option_add('*LabelFrame.Background', self.frame_bg_color)
        self.root.option_add('*LabelFrame.Foreground', self.text_color)
        self.root.option_add('*Button.Background', self.accent_color)
        self.root.option_add('*Button.Foreground', 'white')
        self.root.option_add('*Entry.Background', self.entry_bg)
        self.root.option_add('*Entry.Foreground', '#2c3e50') # Texto oscuro en campos claros
        self.root.option_add('*OptionMenu.background', self.frame_bg_color)
        self.root.option_add('*OptionMenu.foreground', self.text_color)
        self.root.option_add('*Menu.background', self.frame_bg_color)
        self.root.option_add('*Menu.foreground', self.text_color)


        self.create_widgets()

    def create_widgets(self):
        # Frame principal para contener todo y centrarlo
        main_frame = tk.Frame(self.root, bg=self.bg_color)
        main_frame.pack(expand=True, fill="both", padx=50, pady=50) 

        # Título de la aplicación
        title_label = tk.Label(main_frame, text="CALCULADORA DE ÁREAS", 
                               font=("SegoeUI", 24, "bold"), bg=self.bg_color, fg=self.accent_color)
        title_label.pack(pady=20)

        # Contenedor para los controles (izquierda) y el canvas (derecha)
        content_frame = tk.Frame(main_frame, bg=self.bg_color)
        content_frame.pack(fill="both", expand=True)

        # Frame de Controles (lado izquierdo)
        controls_frame = tk.Frame(content_frame, bg=self.bg_color)
        controls_frame.pack(side="left", fill="y", padx=20, pady=10)

        # Frame para selección de figura
        selection_frame = tk.LabelFrame(controls_frame, text="Seleccione una Figura", 
                                        bg=self.frame_bg_color, fg=self.text_color, bd=2, relief="groove", padx=15, pady=15)
        selection_frame.pack(pady=15, padx=0, fill="x") # Ajustado padx a 0 para que ocupe todo el ancho de controls_frame

        self.figure_type = tk.StringVar(self.root)
        self.figure_type.set("cuadrado") # Valor por defecto
        
        figure_options = ["cuadrado", "triangulo", "rectangulo", "circulo"]
        
        self.figure_menu = tk.OptionMenu(selection_frame, self.figure_type, *figure_options, command=self.on_figure_select)
        self.figure_menu.config(width=20, relief="flat", highlightbackground=self.accent_color, highlightthickness=1)
        self.figure_menu.pack(pady=10)

        # Frame para parámetros de entrada
        self.params_frame = tk.LabelFrame(controls_frame, text="Ingrese Parámetros", 
                                          bg=self.frame_bg_color, fg=self.text_color, bd=2, relief="groove", padx=15, pady=15)
        self.params_frame.pack(pady=15, padx=0, fill="x")

        self.labels = {}
        self.entries = {}

        self.create_param_inputs("cuadrado") # Inicializar con inputs de cuadrado

        # Botón de calcular
        calculate_button = tk.Button(controls_frame, text="CALCULAR ÁREA", command=self.calculate_area, 
                                     font=("SegoeUI", 14, "bold"), relief="raised", bd=3, cursor="hand2")
        calculate_button.pack(pady=20, ipadx=20, ipady=10)

        # Frame para mostrar el resultado
        result_frame = tk.LabelFrame(controls_frame, text="Resultado", 
                                      bg=self.frame_bg_color, fg=self.text_color, bd=2, relief="groove", padx=15, pady=15)
        result_frame.pack(pady=15, padx=0, fill="x")

        self.result_label = tk.Label(result_frame, text="Área: ", 
                                      font=("SegoeUI", 16, "bold"), bg=self.frame_bg_color, fg=self.text_color)
        self.result_label.pack(pady=10)

        # Canvas para dibujar la figura (lado derecho)
        self.canvas_frame = tk.LabelFrame(content_frame, text="Representación de la Figura", 
                                           bg=self.frame_bg_color, fg=self.text_color, bd=2, relief="groove", padx=10, pady=10)
        self.canvas_frame.pack(side="right", fill="both", expand=True, padx=20, pady=10)

        self.canvas = tk.Canvas(self.canvas_frame, bg=self.canvas_bg, highlightthickness=0)
        self.canvas.pack(fill="both", expand=True)

        self.draw_figure("cuadrado") # Dibujar cuadrado al inicio

    def clear_param_inputs(self):
        for label in self.labels.values():
            label.destroy()
        for entry in self.entries.values():
            entry.destroy()
        self.labels.clear()
        self.entries.clear()

    def create_param_inputs(self, figure):
        self.clear_param_inputs()

        # Usar un GridLayout para organizar los inputs de manera más limpia
        row_num = 0
        if figure == "cuadrado":
            self.labels["lado"] = tk.Label(self.params_frame, text="Lado:", bg=self.frame_bg_color)
            self.labels["lado"].grid(row=row_num, column=0, pady=5, padx=10, sticky="w")
            self.entries["lado"] = tk.Entry(self.params_frame, width=25)
            self.entries["lado"].grid(row=row_num, column=1, pady=5, padx=10, sticky="ew")
        elif figure == "triangulo":
            self.labels["base"] = tk.Label(self.params_frame, text="Base:", bg=self.frame_bg_color)
            self.labels["base"].grid(row=row_num, column=0, pady=5, padx=10, sticky="w")
            self.entries["base"] = tk.Entry(self.params_frame, width=25)
            self.entries["base"].grid(row=row_num, column=1, pady=5, padx=10, sticky="ew")
            row_num += 1
            self.labels["altura"] = tk.Label(self.params_frame, text="Altura:", bg=self.frame_bg_color)
            self.labels["altura"].grid(row=row_num, column=0, pady=5, padx=10, sticky="w")
            self.entries["altura"] = tk.Entry(self.params_frame, width=25)
            self.entries["altura"].grid(row=row_num, column=1, pady=5, padx=10, sticky="ew")
        elif figure == "rectangulo":
            self.labels["ancho"] = tk.Label(self.params_frame, text="Ancho:", bg=self.frame_bg_color)
            self.labels["ancho"].grid(row=row_num, column=0, pady=5, padx=10, sticky="w")
            self.entries["ancho"] = tk.Entry(self.params_frame, width=25)
            self.entries["ancho"].grid(row=row_num, column=1, pady=5, padx=10, sticky="ew")
            row_num += 1
            self.labels["largo"] = tk.Label(self.params_frame, text="Largo:", bg=self.frame_bg_color)
            self.labels["largo"].grid(row=row_num, column=0, pady=5, padx=10, sticky="w")
            self.entries["largo"] = tk.Entry(self.params_frame, width=25)
            self.entries["largo"].grid(row=row_num, column=1, pady=5, padx=10, sticky="ew")
        elif figure == "circulo":
            self.labels["radio"] = tk.Label(self.params_frame, text="Radio:", bg=self.frame_bg_color)
            self.labels["radio"].grid(row=row_num, column=0, pady=5, padx=10, sticky="w")
            self.entries["radio"] = tk.Entry(self.params_frame, width=25)
            self.entries["radio"].grid(row=row_num, column=1, pady=5, padx=10, sticky="ew")
        
        self.params_frame.grid_columnconfigure(1, weight=1) # Permite que la columna de entrada se expanda

    def draw_figure(self, figure_name):
        self.canvas.delete("all")  # Limpiar el canvas antes de dibujar

        canvas_width = self.canvas.winfo_width()
        canvas_height = self.canvas.winfo_height()
        center_x, center_y = canvas_width / 2, canvas_height / 2
        
        # Tamaño base para las figuras (ajustado para que no sean demasiado grandes/pequeñas)
        base_size = min(canvas_width, canvas_height) * 0.4 

        if figure_name == "cuadrado":
            side = base_size
            x1, y1 = center_x - side/2, center_y - side/2
            x2, y2 = center_x + side/2, center_y + side/2
            self.canvas.create_rectangle(x1, y1, x2, y2, outline=self.figure_color, width=3, fill=self.figure_color)
        elif figure_name == "triangulo":
            # Un triángulo equilátero para simplificar
            side = base_size * 1.2 # Un poco más grande para que se vea mejor
            height = side * (math.sqrt(3) / 2)
            
            p1_x, p1_y = center_x, center_y - height/2 # Vértice superior
            p2_x, p2_y = center_x - side/2, center_y + height/2 # Vértice inferior izquierdo
            p3_x, p3_y = center_x + side/2, center_y + height/2 # Vértice inferior derecho
            self.canvas.create_polygon(p1_x, p1_y, p2_x, p2_y, p3_x, p3_y, outline=self.figure_color, width=3, fill=self.figure_color)
        elif figure_name == "rectangulo":
            width = base_size * 1.5
            height = base_size * 0.8
            x1, y1 = center_x - width/2, center_y - height/2
            x2, y2 = center_x + width/2, center_y + height/2
            self.canvas.create_rectangle(x1, y1, x2, y2, outline=self.figure_color, width=3, fill=self.figure_color)
        elif figure_name == "circulo":
            radius = base_size * 0.6
            x1, y1 = center_x - radius, center_y - radius
            x2, y2 = center_x + radius, center_y + radius
            self.canvas.create_oval(x1, y1, x2, y2, outline=self.figure_color, width=3, fill=self.figure_color)

    def on_figure_select(self, *args):
        selected_figure = self.figure_type.get()
        self.create_param_inputs(selected_figure)
        self.draw_figure(selected_figure) # Dibujar la figura seleccionada
        self.result_label.config(text="Área: ") # Limpiar resultado anterior

    def calculate_area(self):
        selected_figure = self.figure_type.get()
        try:
            area = None
            if selected_figure == "cuadrado":
                lado = float(self.entries["lado"].get())
                c = cuadrado(lado)
                area = c.calcula_area()
            elif selected_figure == "triangulo":
                base = float(self.entries["base"].get())
                altura = float(self.entries["altura"].get())
                t = triangulo(base, altura)
                area = t.calcula_area()
            elif selected_figure == "rectangulo":
                ancho = float(self.entries["ancho"].get())
                largo = float(self.entries["largo"].get())
                r = rectangulo(ancho, largo)
                area = r.calcula_area()
            elif selected_figure == "circulo":
                radio = float(self.entries["radio"].get())
                cir = circulo(radio)
                area = cir.calcula_area()

            if area is not None:
                self.result_label.config(text=f"Área: {area:.2f} unidades²")

        except ValueError as ve:
            messagebox.showerror("Error de Entrada", str(ve))
        except Exception as e:
            messagebox.showerror("Error Inesperado", f"Ocurrió un error: {e}")

if __name__ == "__main__":
    root = tk.Tk()
    app = AreaCalculatorApp(root)
    
    # Es crucial llamar a update_idletasks y geometry después de que el mainloop 
    # haya procesado el tamaño del canvas, para que draw_figure tenga el tamaño correcto
    root.update_idletasks() 
    app.draw_figure(app.figure_type.get()) # Dibujar la figura inicial después de que el canvas tenga tamaño

    root.mainloop()