import tkinter as tk
from tkinter import scrolledtext, Toplevel, Label, Entry, Button, StringVar, OptionMenu
from tkinter import ttk # Import ttk for themed widgets
import os
from datetime import datetime, timedelta
import uuid # Importar la librería UUID

# --- Clases de Lógica de Negocio ---

class Libro:
    def __init__(self, codigo, titulo, autor, genero, total_copias=1, copias_disponibles=1, id_uuid=None):
        self.__uuid = id_uuid if id_uuid else str(uuid.uuid4()) # Generar UUID
        self.__codigo = codigo
        self.__titulo = titulo
        self.__autor = autor
        self.__genero = genero 
        self.__total_copias = int(total_copias) 
        self.__copias_disponibles = int(copias_disponibles) 

    def __del__(self):
        pass

    def mostrar_info(self):
        return (f"Código: {self.__codigo}\n"
                f"Título: {self.__titulo}\n"
                f"Autor: {self.__autor}\n"
                f"Género: {self.__genero}\n"
                f"Copias Disponibles: {self.__copias_disponibles} de {self.__total_copias}")

    def reservar(self):
        if self.__copias_disponibles > 0:
            self.__copias_disponibles -= 1
            return True
        else:
            return False

    def cancelar_reserva(self):
        if self.__copias_disponibles < self.__total_copias: # Asegura no exceder el total de copias
            self.__copias_disponibles += 1
            return True
        return False

    def esta_disponible(self):
        return self.__copias_disponibles > 0

    def get_uuid(self):
        return self.__uuid

    def get_codigo(self):
        return self.__codigo

    def get_titulo(self):
        return self.__titulo

    def get_autor(self):
        return self.__autor
    
    def get_genero(self):
        return self.__genero

    def get_total_copias(self):
        return self.__total_copias

    def get_copias_disponibles(self):
        return self.__copias_disponibles


class Usuario:
    def __init__(self, dni, nombre, id_uuid=None):
        self.__uuid = id_uuid if id_uuid else str(uuid.uuid4()) # Generar UUID
        self.__dni = dni
        self.__nombre = nombre

    def __del__(self):
        pass

    def mostrar_info(self):
        return (f"DNI: {self.__dni}\n"
                f"Nombre: {self.__nombre}")

    def get_uuid(self):
        return self.__uuid

    def get_dni(self):
        return self.__dni

    def get_nombre(self):
        return self.__nombre


class Bibliotecario:
    def __init__(self, id_bibliotecario, nombre, rol="Empleado", id_uuid=None): # Nuevo campo 'rol'
        self.__uuid = id_uuid if id_uuid else str(uuid.uuid4()) # Generar UUID
        self.__id = id_bibliotecario
        self.__nombre = nombre
        self.__rol = rol # Rol del bibliotecario

    def __del__(self):
        pass

    def mostrar_info(self):
        return (f"ID Bibliotecario: {self.__id}\n"
                f"Nombre: {self.__nombre}\n"
                f"Rol: {self.__rol}")

    def get_uuid(self):
        return self.__uuid

    def get_id(self):
        return self.__id

    def get_nombre(self):
        return self.__nombre
    
    def get_rol(self):
        return self.__rol


class Prestamo:
    TASA_MULTA_DIA = 0.50 

    def __init__(self, usuario_uuid, libro_uuid, bibliotecario_uuid, fecha_prestamo, fecha_devolucion_estimada, fecha_devolucion_real=None, monto_multa=0.0, multa_pagada=False, activo=True):
        self.__usuario_uuid = usuario_uuid
        self.__libro_uuid = libro_uuid
        self.__bibliotecario_uuid = bibliotecario_uuid
        self.__fecha_prestamo = fecha_prestamo
        self.__fecha_devolucion_estimada = fecha_devolucion_estimada
        self.__fecha_devolucion_real = fecha_devolucion_real
        self.__monto_multa = monto_multa
        self.__multa_pagada = multa_pagada
        self.__activo = activo
        
    def mostrar_info(self, biblioteca_instancia): 
        usuario = biblioteca_instancia.get_usuario_by_uuid(self.__usuario_uuid)
        libro = biblioteca_instancia.get_libro_by_uuid(self.__libro_uuid)
        bibliotecario = biblioteca_instancia.get_bibliotecario_by_uuid(self.__bibliotecario_uuid)

        usuario_nombre = usuario.get_nombre() if usuario else "Desconocido"
        usuario_dni = usuario.get_dni() if usuario else "N/A"
        libro_titulo = libro.get_titulo() if libro else "Desconocido"
        libro_codigo = libro.get_codigo() if libro else "N/A"
        bibliotecario_nombre = bibliotecario.get_nombre() if bibliotecario else "Desconocido"
        bibliotecario_id = bibliotecario.get_id() if bibliotecario else "N/A"

        estado = "Activo" if self.__activo else "Devuelto"
        devolucion_real_str = self.__fecha_devolucion_real.strftime('%Y-%m-%d') if self.__fecha_devolucion_real else "Pendiente"
        multa_info = f"Multa: S/.{self.__monto_multa:.2f} ({'Pagada' if self.__multa_pagada else 'Pendiente'})" if self.__monto_multa > 0 else "Sin multa"
        
        return (f"Usuario: {usuario_nombre} (DNI: {usuario_dni})\n"
                f"Libro: '{libro_titulo}' (Código: {libro_codigo})\n"
                f"Bibliotecario: {bibliotecario_nombre} (ID: {bibliotecario_id})\n"
                f"Fecha Préstamo: {self.__fecha_prestamo.strftime('%Y-%m-%d')}\n"
                f"Fecha Devolución Estimada: {self.__fecha_devolucion_estimada.strftime('%Y-%m-%d')}\n"
                f"Fecha Devolución Real: {devolucion_real_str}\n"
                f"Estado del Préstamo: {estado}\n"
                f"{multa_info}")

    def devolver_libro(self, fecha_devolucion_real=None):
        if self.__activo:
            self.__activo = False
            self.__fecha_devolucion_real = fecha_devolucion_real if fecha_devolucion_real else datetime.now()
            self._calcular_multa() 
            return True
        else:
            return False

    def _calcular_multa(self):
        if self.__fecha_devolucion_real and self.__fecha_devolucion_real > self.__fecha_devolucion_estimada:
            dias_retraso = (self.__fecha_devolucion_real - self.__fecha_devolucion_estimada).days
            self.__monto_multa = dias_retraso * self.TASA_MULTA_DIA
        else:
            self.__monto_multa = 0.0

    def marcar_multa_pagada(self):
        self.__multa_pagada = True

    def es_activo(self):
        return self.__activo

    def get_usuario_uuid(self):
        return self.__usuario_uuid

    def get_libro_uuid(self):
        return self.__libro_uuid

    def get_bibliotecario_uuid(self):
        return self.__bibliotecario_uuid

    def get_fecha_prestamo(self):
        return self.__fecha_prestamo

    def get_fecha_devolucion_estimada(self):
        return self.__fecha_devolucion_estimada
    
    def get_fecha_devolucion_real(self):
        return self.__fecha_devolucion_real

    def get_monto_multa(self):
        return self.__monto_multa

    def esta_multa_pagada(self):
        return self.__multa_pagada


class Biblioteca:
    def __init__(self):
        self.__libros = []
        self.__usuarios = []
        self.__bibliotecarios = []
        self.__prestamos = []
        self.cargar_datos()

    def __del__(self):
        self.guardar_datos()

    def guardar_datos(self):
        try:
            # Guardar libros (UUID, Código, Título, Autor, Género, Total Copias, Copias Disponibles)
            with open("libros.txt", "w") as f:
                for l in self.__libros:
                    f.write(f"{l.get_uuid()},{l.get_codigo()},{l.get_titulo()},{l.get_autor()},{l.get_genero()},"
                            f"{l.get_total_copias()},{l.get_copias_disponibles()}\n")

            # Guardar usuarios (UUID, DNI, Nombre)
            with open("usuarios.txt", "w") as f:
                for u in self.__usuarios:
                    f.write(f"{u.get_uuid()},{u.get_dni()},{u.get_nombre()}\n")

            # Guardar bibliotecarios (UUID, ID, Nombre, Rol)
            with open("bibliotecarios.txt", "w") as f:
                for b in self.__bibliotecarios:
                    f.write(f"{b.get_uuid()},{b.get_id()},{b.get_nombre()},{b.get_rol()}\n")

            # Guardar préstamos (UUIDs de objetos relacionados, fechas, multa, estado)
            with open("prestamos.txt", "w") as f:
                for p in self.__prestamos:
                    fecha_real_str = p.get_fecha_devolucion_real().strftime('%Y-%m-%d') if p.get_fecha_devolucion_real() else "None"
                    f.write(f"{p.get_usuario_uuid()},{p.get_libro_uuid()},{p.get_bibliotecario_uuid()},"
                            f"{p.get_fecha_prestamo().strftime('%Y-%m-%d')},"
                            f"{p.get_fecha_devolucion_estimada().strftime('%Y-%m-%d')},"
                            f"{fecha_real_str},{p.get_monto_multa()},{int(p.esta_multa_pagada())},{int(p.es_activo())}\n")
            return "Datos guardados exitosamente."
        except Exception as e:
            return f"Error al guardar datos: {e}"

    def cargar_datos(self):
        # Cargar libros
        if os.path.exists("libros.txt"):
            with open("libros.txt", "r") as f:
                for line in f:
                    try:
                        # UUID, Código, Título, Autor, Género, Total Copias, Copias Disponibles
                        uuid_str, codigo, titulo, autor, genero, total_copias_str, copias_disponibles_str = line.strip().split(",")
                        libro = Libro(codigo, titulo, autor, genero, int(total_copias_str), int(copias_disponibles_str), id_uuid=uuid_str)
                        self.__libros.append(libro)
                    except ValueError:
                        print(f"Advertencia: Línea de libro con formato incorrecto o antiguo: {line.strip()}")
                        # Manejo básico para compatibilidad con versiones anteriores sin género/copias
                        # Puedes agregar una lógica más sofisticada si necesitas migración de datos complejos
                        parts = line.strip().split(",")
                        if len(parts) == 4: # Formato antiguo: codigo,titulo,autor,disponible
                            codigo, titulo, autor, disponible_str = parts
                            disponible = bool(int(disponible_str))
                            libro = Libro(codigo, titulo, autor, "General", 1, 1 if disponible else 0, id_uuid=str(uuid.uuid4()))
                        else: # Intentar con el formato más reciente sin UUID si es el caso
                            codigo, titulo, autor, genero, total_copias_str, copias_disponibles_str = parts
                            libro = Libro(codigo, titulo, autor, genero, int(total_copias_str), int(copias_disponibles_str), id_uuid=str(uuid.uuid4()))
                        self.__libros.append(libro)


        # Cargar usuarios
        if os.path.exists("usuarios.txt"):
            with open("usuarios.txt", "r") as f:
                for line in f:
                    try:
                        # UUID, DNI, Nombre
                        uuid_str, dni, nombre = line.strip().split(",")
                        usuario = Usuario(dni, nombre, id_uuid=uuid_str)
                        self.__usuarios.append(usuario)
                    except ValueError:
                        print(f"Advertencia: Línea de usuario con formato incorrecto o antiguo: {line.strip()}")
                        dni, nombre = line.strip().split(",") # Intenta formato antiguo
                        usuario = Usuario(dni, nombre, id_uuid=str(uuid.uuid4()))
                        self.__usuarios.append(usuario)

        # Cargar bibliotecarios
        if os.path.exists("bibliotecarios.txt"):
            with open("bibliotecarios.txt", "r") as f:
                for line in f:
                    try:
                        # UUID, ID, Nombre, Rol
                        uuid_str, id_bib, nombre_bib, rol_str = line.strip().split(",")
                        bibliotecario = Bibliotecario(id_bib, nombre_bib, rol=rol_str, id_uuid=uuid_str)
                        self.__bibliotecarios.append(bibliotecario)
                    except ValueError:
                        print(f"Advertencia: Línea de bibliotecario con formato incorrecto o antiguo: {line.strip()}")
                        parts = line.strip().split(",")
                        if len(parts) == 3: # Formato antiguo: UUID,ID,Nombre
                            uuid_str, id_bib, nombre_bib = parts
                            bibliotecario = Bibliotecario(id_bib, nombre_bib, rol="Empleado", id_uuid=uuid_str) # Rol por defecto
                        else: # Formato más antiguo: ID,Nombre
                            id_bib, nombre_bib = parts
                            bibliotecario = Bibliotecario(id_bib, nombre_bib, rol="Empleado", id_uuid=str(uuid.uuid4()))
                        self.__bibliotecarios.append(bibliotecario)

        # Cargar préstamos (después de cargar libros, usuarios y bibliotecarios)
        if os.path.exists("prestamos.txt"):
            with open("prestamos.txt", "r") as f:
                for line in f:
                    try:
                        # UUIDs de objetos relacionados, fechas, multa, estado
                        parts = line.strip().split(",")
                        usuario_uuid, libro_uuid, bibliotecario_uuid, fecha_prestamo_str, fecha_devolucion_estimada_str, \
                        fecha_devolucion_real_str, monto_multa_str, multa_pagada_str, activo_str = parts
                        
                        fecha_prestamo = datetime.strptime(fecha_prestamo_str, '%Y-%m-%d')
                        fecha_devolucion_estimada = datetime.strptime(fecha_devolucion_estimada_str, '%Y-%m-%d')
                        fecha_devolucion_real = datetime.strptime(fecha_devolucion_real_str, '%Y-%m-%d') if fecha_devolucion_real_str != "None" else None
                        monto_multa = float(monto_multa_str)
                        multa_pagada = bool(int(multa_pagada_str))
                        activo = bool(int(activo_str))

                        prestamo = Prestamo(usuario_uuid, libro_uuid, bibliotecario_uuid, fecha_prestamo, fecha_devolucion_estimada, fecha_devolucion_real, monto_multa, multa_pagada, activo=activo)
                        self.__prestamos.append(prestamo)
                    except ValueError:
                        print(f"Advertencia: Línea de préstamo con formato incorrecto o antiguo: {line.strip()}")
                        # Manejo para formato antiguo de préstamos (sin UUIDs, fechas reales, multas)
                        # Este bloque asume el formato anterior a la última actualización
                        try:
                            dni, codigo_libro, id_bibliotecario, fecha_prestamo_str, fecha_devolucion_estimada_str, activo_str = line.strip().split(",")
                            
                            usuario = next((u for u in self.__usuarios if u.get_dni() == dni), None)
                            libro = next((l for l in self.__libros if l.get_codigo() == codigo_libro), None)
                            bibliotecario = next((b for b in self.__bibliotecarios if b.get_id() == id_bibliotecario), None)

                            if usuario and libro and bibliotecario:
                                fecha_prestamo = datetime.strptime(fecha_prestamo_str, '%Y-%m-%d')
                                fecha_devolucion_estimada = datetime.strptime(fecha_devolucion_estimada_str, '%Y-%m-%d')
                                activo = bool(int(activo_str))
                                
                                prestamo = Prestamo(usuario.get_uuid(), libro.get_uuid(), bibliotecario.get_uuid(), 
                                                    fecha_prestamo, fecha_devolucion_estimada, 
                                                    None, 0.0, False, activo)
                                self.__prestamos.append(prestamo)
                        except ValueError:
                            print(f"Error: Línea de préstamo no pudo ser parseada con ningún formato conocido: {line.strip()}")


    def registrar_libro_gui(self, codigo, titulo, autor, genero, total_copias_str):
        if not codigo or not titulo or not autor or not genero or not total_copias_str:
            return "❌ Todos los campos son obligatorios."
        
        if any(l.get_codigo() == codigo for l in self.__libros):
            return "❌ Ya existe un libro con ese código."
        
        if not total_copias_str.isdigit() or int(total_copias_str) <= 0:
            return "❌ El número de copias debe ser un entero positivo."
        
        total_copias = int(total_copias_str)
        libro = Libro(codigo, titulo, autor, genero, total_copias=total_copias, copias_disponibles=total_copias)
        self.__libros.append(libro)
        self.guardar_datos()
        return "✅ Libro registrado correctamente."

    def registrar_usuario_gui(self, dni, nombre):
        if not dni or not nombre:
            return "❌ Ambos campos (DNI, Nombre) son obligatorios."
        if not dni.isdigit():
            return "❌ El DNI debe contener solo números."

        if any(u.get_dni() == dni for u in self.__usuarios):
            return "❌ Ya existe un usuario con ese DNI."
        usuario = Usuario(dni, nombre)
        self.__usuarios.append(usuario)
        self.guardar_datos()
        return "✅ Usuario registrado correctamente."
    
    def registrar_bibliotecario_gui(self, id_bibliotecario, nombre, rol):
        if not id_bibliotecario or not nombre or not rol:
            return "❌ Todos los campos (ID, Nombre, Rol) son obligatorios."
        if not id_bibliotecario.isalnum(): # ID alfanumérico
            return "❌ El ID del bibliotecario debe ser alfanumérico."

        if any(b.get_id() == id_bibliotecario for b in self.__bibliotecarios):
            return "❌ Ya existe un bibliotecario con ese ID."
        bibliotecario = Bibliotecario(id_bibliotecario, nombre, rol=rol)
        self.__bibliotecarios.append(bibliotecario)
        self.guardar_datos()
        return "✅ Bibliotecario registrado correctamente."

    def hacer_prestamo_gui(self, dni_usuario, codigo_libro, id_bibliotecario):
        usuario = self.get_usuario_by_dni(dni_usuario)
        libro = self.get_libro_by_codigo(codigo_libro)
        bibliotecario = self.get_bibliotecario_by_id(id_bibliotecario)

        if not usuario:
            return "❌ Usuario no encontrado."
        if not libro:
            return "❌ Libro no encontrado."
        if not bibliotecario:
            return "❌ Bibliotecario no encontrado."
        
        if not libro.esta_disponible(): # Verifica si hay copias disponibles
            return "❌ Libro no disponible (todas las copias prestadas)."
        
        # Verificar si el usuario ya tiene este libro prestado (activo)
        for p in self.__prestamos:
            if p.es_activo() and p.get_usuario_uuid() == usuario.get_uuid() and p.get_libro_uuid() == libro.get_uuid():
                return "❌ Este usuario ya tiene prestado este libro."

        fecha_prestamo = datetime.now()
        fecha_devolucion_estimada = fecha_prestamo + timedelta(days=15) # Préstamo por 15 días

        # Crear el préstamo y marcar la copia como reservada en el libro
        prestamo = Prestamo(usuario.get_uuid(), libro.get_uuid(), bibliotecario.get_uuid(), fecha_prestamo, fecha_devolucion_estimada, activo=True)
        
        if libro.reservar(): # Intenta reservar una copia del libro
            self.__prestamos.append(prestamo)
            self.guardar_datos()
            return f"✅ Préstamo creado exitosamente:\n{prestamo.mostrar_info(self)}"
        else:
            return "❌ No se pudo realizar el préstamo (error al reservar copia)."

    def devolver_prestamo_gui(self, dni_usuario, codigo_libro):
        usuario_obj = self.get_usuario_by_dni(dni_usuario)
        libro_obj = self.get_libro_by_codigo(codigo_libro)

        if not usuario_obj:
            return "❌ Usuario no encontrado."
        if not libro_obj:
            return "❌ Libro no encontrado."

        prestamo_encontrado = None
        for p in self.__prestamos:
            # Buscar por UUIDs para mayor robustez
            if p.es_activo() and p.get_usuario_uuid() == usuario_obj.get_uuid() and p.get_libro_uuid() == libro_obj.get_uuid():
                prestamo_encontrado = p
                break
        
        if prestamo_encontrado:
            if prestamo_encontrado.devolver_libro(): # La multa se calcula dentro de devolver_libro
                libro_obj.cancelar_reserva() # Liberar una copia del libro
                self.guardar_datos()
                return prestamo_encontrado # Retornar el objeto préstamo para manejar la multa en la GUI
            else:
                return "❌ El préstamo ya estaba inactivo (libro ya devuelto)."
        else:
            return "❌ Préstamo activo no encontrado para este usuario y libro."

    # --- Métodos de búsqueda por UUID/DNI/Código ---
    def get_libro_by_uuid(self, uuid_str):
        return next((l for l in self.__libros if l.get_uuid() == uuid_str), None)

    def get_usuario_by_uuid(self, uuid_str):
        return next((u for u in self.__usuarios if u.get_uuid() == uuid_str), None)

    def get_bibliotecario_by_uuid(self, uuid_str):
        return next((b for b in self.__bibliotecarios if b.get_uuid() == uuid_str), None)

    def get_libro_by_codigo(self, codigo):
        return next((l for l in self.__libros if l.get_codigo() == codigo), None)

    def get_usuario_by_dni(self, dni):
        return next((u for u in self.__usuarios if u.get_dni() == dni), None)

    def get_bibliotecario_by_id(self, id_bib):
        return next((b for b in self.__bibliotecarios if b.get_id() == id_bib), None)
    
    def get_bibliotecario_by_id_and_role(self, id_bib, role):
        return next((b for b in self.__bibliotecarios if b.get_id() == id_bib and b.get_rol() == role), None)


    # --- Métodos para la GUI ---
    def get_libros(self):
        return self.__libros
    
    def get_usuarios(self):
        return self.__usuarios
    
    def get_bibliotecarios(self):
        return self.__bibliotecarios

    def get_prestamos(self):
        return self.__prestamos

    def mostrar_libros_disponibles_gui(self):
        disponibles = [l for l in self.__libros if l.esta_disponible()]
        return disponibles

    def mostrar_libros_reservados_gui(self): # Ahora "prestados"
        prestados = [l for l in self.__libros if not l.esta_disponible()]
        return prestados

    def buscar_libro_gui(self, criterio, texto):
        encontrados = []
        if criterio == "titulo":
            encontrados = [l for l in self.__libros if texto.lower() in l.get_titulo().lower()]
        elif criterio == "autor":
            encontrados = [l for l in self.__libros if texto.lower() in l.get_autor().lower()]
        elif criterio == "genero": # Nuevo criterio de búsqueda
            encontrados = [l for l in self.__libros if texto.lower() in l.get_genero().lower()]
        else:
            return [] # Criterio inválido
        return encontrados

    def get_prestamos_vencidos(self):
        hoy = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
        vencidos = [p for p in self.__prestamos if p.es_activo() and p.get_fecha_devolucion_estimada() < hoy]
        return vencidos

    def get_prestamos_proximos_a_vencer(self, dias=3):
        hoy = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
        fecha_limite = hoy + timedelta(days=dias)
        proximos = [p for p in self.__prestamos if p.es_activo() and hoy <= p.get_fecha_devolucion_estimada() <= fecha_limite]
        return proximos

# --- Interfaz Gráfica con Tkinter y ttk ---

class BibliotecaGUI:
    def __init__(self, master):
        self.master = master
        master.title("📚 Sistema de Gestión de Biblioteca UNAP 📚")
        master.geometry("1300x850") 
        master.minsize(1000, 700)
        master.configure(bg="#ECEFF1")

        self.biblioteca = Biblioteca()
        # Inicializar current_librarian de forma segura
        bibliotecarios_existentes = self.biblioteca.get_bibliotecarios()
        self.current_librarian = bibliotecarios_existentes[0] if bibliotecarios_existentes else None

        # Estilos con ttk
        s = ttk.Style()
        s.theme_use('clam') 
        s.configure('TFrame', background='#ECEFF1')
        s.configure('TLabel', background='#ECEFF1', font=('Segoe UI', 10))
        s.configure('TButton', font=('Segoe UI', 10, 'bold'), padding=8, background='#607D8B', foreground='white')
        s.map('TButton', background=[('active', '#78909C')]) 
        s.configure('TEntry', font=('Segoe UI', 10), padding=4)
        s.configure('TNotebook.Tab', font=('Segoe UI', 10, 'bold'), padding=[10, 5])
        s.configure('Treeview.Heading', font=('Segoe UI', 10, 'bold'), background='#455A64', foreground='white')
        s.configure('Treeview', font=('Segoe UI', 10), rowheight=25)
        s.map('Treeview', background=[('selected', '#B0BEC5')]) 

        # Título principal
        self.main_title_label = tk.Label(master, text="Gestión de Biblioteca UNAP", font=('Segoe UI', 26, 'bold'),
                                         bg="#3F51B5", fg="white", pady=15)
        self.main_title_label.pack(fill='x', pady=(0, 15))

        # Cuaderno de pestañas (Notebook)
        self.notebook = ttk.Notebook(master)
        self.notebook.pack(pady=10, padx=20, expand=True, fill='both') # Empaquetar directamente

        # --- Pestañas ---
        self.tab_libros = ttk.Frame(self.notebook)
        self.tab_usuarios = ttk.Frame(self.notebook)
        self.tab_bibliotecarios = ttk.Frame(self.notebook)
        self.tab_prestamos = ttk.Frame(self.notebook)

        self.notebook.add(self.tab_libros, text='Libros 📚')
        self.notebook.add(self.tab_usuarios, text='Usuarios 👥')
        self.notebook.add(self.tab_bibliotecarios, text='Bibliotecarios 👩‍🏫')
        self.notebook.add(self.tab_prestamos, text='Préstamos 📖')

        # --- Inicializar Pestañas ---
        self._setup_libros_tab()
        self._setup_usuarios_tab()
        self._setup_bibliotecarios_tab()
        self._setup_prestamos_tab()
        
        # --- Status Bar ---
        self.status_bar = tk.Label(master, text="Bienvenido al sistema de biblioteca.", bd=1, relief=tk.SUNKEN, anchor=tk.W, bg="#CFD8DC", fg="#455A64", font=('Segoe UI', 9))
        self.status_bar.pack(side=tk.BOTTOM, fill=tk.X)

        # Manejo de cierre de ventana (directo, sin confirmación)
        master.protocol("WM_DELETE_WINDOW", self._direct_exit) 

        # Aplicar permisos al inicio, ya que no hay pantalla de login
        self._apply_role_permissions()

    def _update_status(self, message):
        self.status_bar.config(text=message)

    def _clear_input_fields(self, entries):
        for entry in entries:
            entry.delete(0, tk.END)

    # --- Custom Dialogs (para confirmación de multa, si aplica) ---
    def _show_custom_confirmation_dialog(self, title, message, callback_yes, callback_no=None):
        dialog = Toplevel(self.master)
        dialog.title(title)
        dialog.geometry("350x150")
        dialog.resizable(False, False)
        dialog.grab_set() 
        dialog.transient(self.master) 
        dialog.focus_set() 

        frame = ttk.Frame(dialog, padding="15")
        frame.pack(expand=True, fill='both')

        ttk.Label(frame, text=message, wraplength=300, font=('Segoe UI', 10, 'bold')).pack(pady=15)

        button_frame = ttk.Frame(frame)
        button_frame.pack(pady=10)

        def on_yes():
            dialog.destroy()
            if callback_yes:
                callback_yes()

        def on_no():
            dialog.destroy()
            if callback_no:
                callback_no()

        ttk.Button(button_frame, text="Sí", command=on_yes, width=10).pack(side='left', padx=10)
        ttk.Button(button_frame, text="No", command=on_no, width=10).pack(side='left', padx=10)

        dialog.wait_window(dialog) 

    def _direct_exit(self):
        """Guarda los datos y cierra la aplicación directamente."""
        self.biblioteca.guardar_datos()
        self.master.destroy()

    def _apply_role_permissions(self):
        # Si no hay bibliotecario actual (ej. primera ejecución sin datos),
        # el botón de registrar bibliotecario debe estar habilitado para permitir la creación.
        # Asegúrate de que self.btn_registrar_bibliotecario ya esté inicializado.
        # Esto se hace en _setup_bibliotecarios_tab, que se llama en __init__.
        
        if self.current_librarian is None:
            self.btn_registrar_bibliotecario.config(state='normal')
            self._update_status("No hay bibliotecarios registrados. Puede registrar uno en la pestaña 'Bibliotecarios'.")
        elif self.current_librarian.get_rol() == "Administrador":
            self.btn_registrar_bibliotecario.config(state='normal')
            self._update_status(f"Bienvenido, {self.current_librarian.get_nombre()} ({self.current_librarian.get_rol()}). Todos los permisos habilitados.")
        elif self.current_librarian.get_rol() == "Empleado":
            self.btn_registrar_bibliotecario.config(state='disabled')
            self._update_status(f"Bienvenido, {self.current_librarian.get_nombre()} ({self.current_librarian.get_rol()}). Permisos de 'Empleado': No puede registrar nuevos bibliotecarios.")


    # --- Configuración de Pestañas (misma lógica, pero ahora con validaciones y UUIDs) ---

    def _setup_libros_tab(self):
        input_frame = ttk.LabelFrame(self.tab_libros, text="Gestión de Libros", padding=(15, 15))
        input_frame.pack(padx=20, pady=10, fill='x')

        input_frame.columnconfigure(1, weight=1) 

        tk.Label(input_frame, text="Código:", font=('Segoe UI', 10, 'bold')).grid(row=0, column=0, padx=5, pady=5, sticky='w')
        self.entry_libro_codigo = ttk.Entry(input_frame)
        self.entry_libro_codigo.grid(row=0, column=1, padx=5, pady=5, sticky='ew')

        tk.Label(input_frame, text="Título:", font=('Segoe UI', 10, 'bold')).grid(row=1, column=0, padx=5, pady=5, sticky='w')
        self.entry_libro_titulo = ttk.Entry(input_frame)
        self.entry_libro_titulo.grid(row=1, column=1, padx=5, pady=5, sticky='ew')

        tk.Label(input_frame, text="Autor:", font=('Segoe UI', 10, 'bold')).grid(row=2, column=0, padx=5, pady=5, sticky='w')
        self.entry_libro_autor = ttk.Entry(input_frame)
        self.entry_libro_autor.grid(row=2, column=1, padx=5, pady=5, sticky='ew')

        tk.Label(input_frame, text="Género:", font=('Segoe UI', 10, 'bold')).grid(row=3, column=0, padx=5, pady=5, sticky='w')
        self.entry_libro_genero = ttk.Entry(input_frame) 
        self.entry_libro_genero.grid(row=3, column=1, padx=5, pady=5, sticky='ew')

        tk.Label(input_frame, text="Total Copias:", font=('Segoe UI', 10, 'bold')).grid(row=4, column=0, padx=5, pady=5, sticky='w')
        self.entry_libro_total_copias = ttk.Entry(input_frame) 
        self.entry_libro_total_copias.grid(row=4, column=1, padx=5, pady=5, sticky='ew')


        button_frame = ttk.Frame(input_frame)
        button_frame.grid(row=5, column=0, columnspan=2, pady=10)
        
        ttk.Button(button_frame, text="Registrar Libro", command=self._registrar_libro_action).pack(side='left', padx=5)
        ttk.Button(button_frame, text="Mostrar Disponibles", command=self._mostrar_libros_disponibles).pack(side='left', padx=5)
        ttk.Button(button_frame, text="Mostrar Prestados", command=self._mostrar_libros_prestados).pack(side='left', padx=5)
        ttk.Button(button_frame, text="Mostrar Todos", command=self._mostrar_todos_los_libros).pack(side='left', padx=5)

        search_frame = ttk.LabelFrame(input_frame, text="Buscar Libro", padding=(10, 5))
        search_frame.grid(row=0, column=2, rowspan=6, padx=15, pady=5, sticky='ns') 
        search_frame.columnconfigure(1, weight=1)

        tk.Label(search_frame, text="Criterio:", font=('Segoe UI', 10, 'bold')).grid(row=0, column=0, padx=5, pady=2, sticky='w')
        self.search_criterio = StringVar(search_frame)
        self.search_criterio.set("titulo")
        criterio_options = ["titulo", "autor", "genero"] 
        ttk.OptionMenu(search_frame, self.search_criterio, *criterio_options).grid(row=0, column=1, padx=5, pady=2, sticky='ew')

        tk.Label(search_frame, text="Texto:", font=('Segoe UI', 10, 'bold')).grid(row=1, column=0, padx=5, pady=2, sticky='w')
        self.entry_search_text = ttk.Entry(search_frame)
        self.entry_search_text.grid(row=1, column=1, padx=5, pady=2, sticky='ew')
        
        ttk.Button(search_frame, text="Buscar", command=self._buscar_libro_action).grid(row=2, column=0, columnspan=2, pady=5)


        self.tree_libros = ttk.Treeview(self.tab_libros, columns=("Código", "Título", "Autor", "Género", "Copias Disponibles", "Total Copias"), show="headings", height=10)
        self.tree_libros.heading("Código", text="Código")
        self.tree_libros.heading("Título", text="Título")
        self.tree_libros.heading("Autor", text="Autor")
        self.tree_libros.heading("Género", text="Género") 
        self.tree_libros.heading("Copias Disponibles", text="Disp.") 
        self.tree_libros.heading("Total Copias", text="Total") 
        
        self.tree_libros.column("Código", width=80, anchor='center')
        self.tree_libros.column("Título", width=200)
        self.tree_libros.column("Autor", width=150)
        self.tree_libros.column("Género", width=100)
        self.tree_libros.column("Copias Disponibles", width=70, anchor='center')
        self.tree_libros.column("Total Copias", width=70, anchor='center')

        self.tree_libros.pack(padx=20, pady=10, fill='both', expand=True)

        self._populate_libros_treeview(self.biblioteca.get_libros()) 

    def _registrar_libro_action(self):
        codigo = self.entry_libro_codigo.get().strip()
        titulo = self.entry_libro_titulo.get().strip()
        autor = self.entry_libro_autor.get().strip()
        genero = self.entry_libro_genero.get().strip() 
        total_copias_str = self.entry_libro_total_copias.get().strip() 

        result = self.biblioteca.registrar_libro_gui(codigo, titulo, autor, genero, total_copias_str)
        self._update_status(result)
        if "✅" in result:
            self._clear_input_fields([self.entry_libro_codigo, self.entry_libro_titulo, self.entry_libro_autor, 
                                      self.entry_libro_genero, self.entry_libro_total_copias])
            self._populate_libros_treeview(self.biblioteca.get_libros())

    def _mostrar_libros_disponibles(self):
        libros = self.biblioteca.mostrar_libros_disponibles_gui()
        self._populate_libros_treeview(libros)
        self._update_status("Mostrando libros disponibles.")

    def _mostrar_libros_prestados(self):
        libros = self.biblioteca.mostrar_libros_reservados_gui() 
        self._populate_libros_treeview(libros)
        self._update_status("Mostrando libros prestados.")
    
    def _mostrar_todos_los_libros(self):
        libros = self.biblioteca.get_libros()
        self._populate_libros_treeview(libros)
        self._update_status("Mostrando todos los libros.")

    def _buscar_libro_action(self):
        criterio = self.search_criterio.get()
        texto = self.entry_search_text.get().strip()

        if not texto:
            self._update_status("❌ Ingrese texto para buscar.")
            return

        libros_encontrados = self.biblioteca.buscar_libro_gui(criterio, texto)
        if libros_encontrados:
            self._populate_libros_treeview(libros_encontrados)
            self._update_status(f"✅ Se encontraron {len(libros_encontrados)} libro(s) por '{texto}'.")
        else:
            self._populate_libros_treeview([])
            self._update_status(f"⚠️ No se encontraron libros con '{texto}'.")
        self._clear_input_fields([self.entry_search_text])


    def _populate_libros_treeview(self, libros):
        for item in self.tree_libros.get_children():
            self.tree_libros.delete(item)
        
        if not libros:
            self.tree_libros.insert("", "end", values=("", "", "No hay libros para mostrar.", "", "", ""))
            return

        for libro in libros:
            self.tree_libros.insert("", "end", values=(
                libro.get_codigo(), 
                libro.get_titulo(), 
                libro.get_autor(), 
                libro.get_genero(), 
                libro.get_copias_disponibles(), 
                libro.get_total_copias()
            ))


    def _setup_usuarios_tab(self):
        input_frame = ttk.LabelFrame(self.tab_usuarios, text="Gestión de Usuarios", padding=(15, 15))
        input_frame.pack(padx=20, pady=10, fill='x')
        input_frame.columnconfigure(1, weight=1)

        tk.Label(input_frame, text="DNI:", font=('Segoe UI', 10, 'bold')).grid(row=0, column=0, padx=5, pady=5, sticky='w')
        self.entry_usuario_dni = ttk.Entry(input_frame)
        self.entry_usuario_dni.grid(row=0, column=1, padx=5, pady=5, sticky='ew')

        tk.Label(input_frame, text="Nombre:", font=('Segoe UI', 10, 'bold')).grid(row=1, column=0, padx=5, pady=5, sticky='w')
        self.entry_usuario_nombre = ttk.Entry(input_frame)
        self.entry_usuario_nombre.grid(row=1, column=1, padx=5, pady=5, sticky='ew')

        button_frame = ttk.Frame(input_frame)
        button_frame.grid(row=2, column=0, columnspan=2, pady=10)
        
        ttk.Button(button_frame, text="Registrar Usuario", command=self._registrar_usuario_action).pack(side='left', padx=5)
        ttk.Button(button_frame, text="Mostrar Usuarios", command=self._mostrar_todos_los_usuarios).pack(side='left', padx=5)

        self.tree_usuarios = ttk.Treeview(self.tab_usuarios, columns=("DNI", "Nombre", "UUID"), show="headings", height=10)
        self.tree_usuarios.heading("DNI", text="DNI")
        self.tree_usuarios.heading("Nombre", text="Nombre")
        self.tree_usuarios.heading("UUID", text="UUID (Interno)") 
        
        self.tree_usuarios.column("DNI", width=150, anchor='center')
        self.tree_usuarios.column("Nombre", width=250)
        self.tree_usuarios.column("UUID", width=250)

        self.tree_usuarios.pack(padx=20, pady=10, fill='both', expand=True)
        self._populate_usuarios_treeview(self.biblioteca.get_usuarios())

    def _registrar_usuario_action(self):
        dni = self.entry_usuario_dni.get().strip()
        nombre = self.entry_usuario_nombre.get().strip()

        result = self.biblioteca.registrar_usuario_gui(dni, nombre)
        self._update_status(result)
        if "✅" in result:
            self._clear_input_fields([self.entry_usuario_dni, self.entry_usuario_nombre])
            self._populate_usuarios_treeview(self.biblioteca.get_usuarios())

    def _mostrar_todos_los_usuarios(self):
        usuarios = self.biblioteca.get_usuarios()
        self._populate_usuarios_treeview(usuarios)
        self._update_status("Mostrando todos los usuarios.")

    def _populate_usuarios_treeview(self, usuarios):
        for item in self.tree_usuarios.get_children():
            self.tree_usuarios.delete(item)
        
        if not usuarios:
            self.tree_usuarios.insert("", "end", values=("", "No hay usuarios para mostrar.", ""))
            return

        for usuario in usuarios:
            self.tree_usuarios.insert("", "end", values=(usuario.get_dni(), usuario.get_nombre(), usuario.get_uuid()))

    def _setup_bibliotecarios_tab(self):
        input_frame = ttk.LabelFrame(self.tab_bibliotecarios, text="Gestión de Bibliotecarios", padding=(15, 15))
        input_frame.pack(padx=20, pady=10, fill='x')
        input_frame.columnconfigure(1, weight=1)

        tk.Label(input_frame, text="ID Bibliotecario:", font=('Segoe UI', 10, 'bold')).grid(row=0, column=0, padx=5, pady=5, sticky='w')
        self.entry_bibliotecario_id = ttk.Entry(input_frame)
        self.entry_bibliotecario_id.grid(row=0, column=1, padx=5, pady=5, sticky='ew')

        tk.Label(input_frame, text="Nombre:", font=('Segoe UI', 10, 'bold')).grid(row=1, column=0, padx=5, pady=5, sticky='w')
        self.entry_bibliotecario_nombre = ttk.Entry(input_frame)
        self.entry_bibliotecario_nombre.grid(row=1, column=1, padx=5, pady=5, sticky='ew')

        tk.Label(input_frame, text="Rol:", font=('Segoe UI', 10, 'bold')).grid(row=2, column=0, padx=5, pady=5, sticky='w')
        self.bibliotecario_rol_var = StringVar(input_frame)
        self.bibliotecario_rol_var.set("Empleado") # Default role
        roles = ["Administrador", "Empleado"]
        ttk.OptionMenu(input_frame, self.bibliotecario_rol_var, *roles).grid(row=2, column=1, padx=5, pady=5, sticky='ew')


        button_frame = ttk.Frame(input_frame)
        button_frame.grid(row=3, column=0, columnspan=2, pady=10)
        
        self.btn_registrar_bibliotecario = ttk.Button(button_frame, text="Registrar Bibliotecario", command=self._registrar_bibliotecario_action)
        self.btn_registrar_bibliotecario.pack(side='left', padx=5)
        ttk.Button(button_frame, text="Mostrar Bibliotecarios", command=self._mostrar_todos_los_bibliotecarios).pack(side='left', padx=5)

        self.tree_bibliotecarios = ttk.Treeview(self.tab_bibliotecarios, columns=("ID", "Nombre", "Rol", "UUID"), show="headings", height=10)
        self.tree_bibliotecarios.heading("ID", text="ID Bibliotecario")
        self.tree_bibliotecarios.heading("Nombre", text="Nombre")
        self.tree_bibliotecarios.heading("Rol", text="Rol") # Nueva columna
        self.tree_bibliotecarios.heading("UUID", text="UUID (Interno)") 
        
        self.tree_bibliotecarios.column("ID", width=100, anchor='center')
        self.tree_bibliotecarios.column("Nombre", width=180)
        self.tree_bibliotecarios.column("Rol", width=100, anchor='center')
        self.tree_bibliotecarios.column("UUID", width=250)

        self.tree_bibliotecarios.pack(padx=20, pady=10, fill='both', expand=True)
        self._populate_bibliotecarios_treeview(self.biblioteca.get_bibliotecarios())

        # No llamar _apply_role_permissions aquí, se llama una vez al final de __init__
        # para asegurar que todos los widgets estén creados.


    def _registrar_bibliotecario_action(self):
        id_bibliotecario = self.entry_bibliotecario_id.get().strip()
        nombre = self.entry_bibliotecario_nombre.get().strip()
        rol = self.bibliotecario_rol_var.get().strip()

        result = self.biblioteca.registrar_bibliotecario_gui(id_bibliotecario, nombre, rol)
        self._update_status(result)
        if "✅" in result:
            self._clear_input_fields([self.entry_bibliotecario_id, self.entry_bibliotecario_nombre])
            self._populate_bibliotecarios_treeview(self.biblioteca.get_bibliotecarios())
            # Si se registra el primer bibliotecario, actualizar el current_librarian y los permisos
            if self.current_librarian is None and self.biblioteca.get_bibliotecarios():
                self.current_librarian = self.biblioteca.get_bibliotecarios()[0] 
                self._apply_role_permissions()


    def _mostrar_todos_los_bibliotecarios(self):
        bibliotecarios = self.biblioteca.get_bibliotecarios()
        self._populate_bibliotecarios_treeview(bibliotecarios)
        self._update_status("Mostrando todos los bibliotecarios.")

    def _populate_bibliotecarios_treeview(self, bibliotecarios):
        for item in self.tree_bibliotecarios.get_children():
            self.tree_bibliotecarios.delete(item)
        
        if not bibliotecarios:
            self.tree_bibliotecarios.insert("", "end", values=("", "No hay bibliotecarios para mostrar.", "", ""))
            return

        for bibliotecario in bibliotecarios:
            self.tree_bibliotecarios.insert("", "end", values=(bibliotecario.get_id(), bibliotecario.get_nombre(), bibliotecario.get_rol(), bibliotecario.get_uuid()))

    def _setup_prestamos_tab(self):
        input_frame = ttk.LabelFrame(self.tab_prestamos, text="Gestión de Préstamos y Devoluciones", padding=(15, 15))
        input_frame.pack(padx=20, pady=10, fill='x')
        input_frame.columnconfigure(1, weight=1)

        tk.Label(input_frame, text="DNI Usuario:", font=('Segoe UI', 10, 'bold')).grid(row=0, column=0, padx=5, pady=5, sticky='w')
        self.entry_prestamo_dni_usuario = ttk.Entry(input_frame)
        self.entry_prestamo_dni_usuario.grid(row=0, column=1, padx=5, pady=5, sticky='ew')

        tk.Label(input_frame, text="Código Libro:", font=('Segoe UI', 10, 'bold')).grid(row=1, column=0, padx=5, pady=5, sticky='w')
        self.entry_prestamo_codigo_libro = ttk.Entry(input_frame)
        self.entry_prestamo_codigo_libro.grid(row=1, column=1, padx=5, pady=5, sticky='ew')

        tk.Label(input_frame, text="ID Bibliotecario:", font=('Segoe UI', 10, 'bold')).grid(row=2, column=0, padx=5, pady=5, sticky='w')
        self.entry_prestamo_id_bibliotecario = ttk.Entry(input_frame)
        self.entry_prestamo_id_bibliotecario.grid(row=2, column=1, padx=5, pady=5, sticky='ew')

        button_frame = ttk.Frame(input_frame)
        button_frame.grid(row=3, column=0, columnspan=2, pady=10)
        
        ttk.Button(button_frame, text="Realizar Préstamo", command=self._hacer_prestamo_action).pack(side='left', padx=5)
        ttk.Button(button_frame, text="Devolver Libro", command=self._devolver_prestamo_action).pack(side='left', padx=5)
        ttk.Button(button_frame, text="Mostrar Todos", command=self._mostrar_todos_los_prestamos).pack(side='left', padx=5)
        ttk.Button(button_frame, text="Préstamos Activos", command=self._mostrar_prestamos_activos).pack(side='left', padx=5)
        ttk.Button(button_frame, text="Próximos a Vencer", command=self._mostrar_prestamos_proximos_a_vencer).pack(side='left', padx=5)
        ttk.Button(button_frame, text="Préstamos Vencidos", command=self._mostrar_prestamos_vencidos).pack(side='left', padx=5)


        self.tree_prestamos = ttk.Treeview(self.tab_prestamos, 
                                           columns=("Usuario", "Libro", "Bibliotecario", "Fecha Préstamo", 
                                                    "Fecha Dev. Estimada", "Fecha Dev. Real", "Multa", "Pagada", "Estado"), 
                                           show="headings", height=10)
        self.tree_prestamos.heading("Usuario", text="Usuario")
        self.tree_prestamos.heading("Libro", text="Libro")
        self.tree_prestamos.heading("Bibliotecario", text="Bibliotecario")
        self.tree_prestamos.heading("Fecha Préstamo", text="Fecha Préstamo")
        self.tree_prestamos.heading("Fecha Dev. Estimada", text="Fecha Dev. Estimada")
        self.tree_prestamos.heading("Fecha Dev. Real", text="Fecha Dev. Real")
        self.tree_prestamos.heading("Multa", text="Multa")
        self.tree_prestamos.heading("Pagada", text="Pagada")
        self.tree_prestamos.heading("Estado", text="Estado")
        
        self.tree_prestamos.column("Usuario", width=150)
        self.tree_prestamos.column("Libro", width=180)
        self.tree_prestamos.column("Bibliotecario", width=120)
        self.tree_prestamos.column("Fecha Préstamo", width=100, anchor='center')
        self.tree_prestamos.column("Fecha Dev. Estimada", width=120, anchor='center')
        self.tree_prestamos.column("Fecha Dev. Real", width=120, anchor='center')
        self.tree_prestamos.column("Multa", width=70, anchor='center')
        self.tree_prestamos.column("Pagada", width=70, anchor='center')
        self.tree_prestamos.column("Estado", width=80, anchor='center')

        self.tree_prestamos.pack(padx=20, pady=10, fill='both', expand=True)
        self._populate_prestamos_treeview(self.biblioteca.get_prestamos())


    def _hacer_prestamo_action(self):
        dni_usuario = self.entry_prestamo_dni_usuario.get().strip()
        codigo_libro = self.entry_prestamo_codigo_libro.get().strip()
        id_bibliotecario = self.entry_prestamo_id_bibliotecario.get().strip()

        if not dni_usuario or not codigo_libro or not id_bibliotecario:
            self._update_status("❌ Todos los campos son obligatorios para el préstamo.")
            return

        result = self.biblioteca.hacer_prestamo_gui(dni_usuario, codigo_libro, id_bibliotecario)
        self._update_status(result)
        if "✅" in result:
            self._clear_input_fields([self.entry_prestamo_dni_usuario, self.entry_prestamo_codigo_libro, self.entry_prestamo_id_bibliotecario])
            self._populate_prestamos_treeview(self.biblioteca.get_prestamos())
            self._populate_libros_treeview(self.biblioteca.get_libros()) 

    def _devolver_prestamo_action(self):
        dni_usuario = self.entry_prestamo_dni_usuario.get().strip()
        codigo_libro = self.entry_prestamo_codigo_libro.get().strip()

        if not dni_usuario or not codigo_libro:
            self._update_status("❌ DNI de Usuario y Código de Libro son obligatorios para la devolución.")
            return

        resultado_devolucion = self.biblioteca.devolver_prestamo_gui(dni_usuario, codigo_libro)
        
        if isinstance(resultado_devolucion, str): 
            self._update_status(resultado_devolucion)
        else: 
            prestamo = resultado_devolucion
            if prestamo.get_monto_multa() > 0:
                self._update_status(f"✅ Libro devuelto. Multa generada: S/.{prestamo.get_monto_multa():.2f}")
                # Usar el diálogo personalizado para la confirmación de multa
                def confirm_multa_paid():
                    prestamo.marcar_multa_pagada()
                    self._update_status(f"✅ Libro devuelto. Multa de S/.{prestamo.get_monto_multa():.2f} marcada como PAGADA.")
                    self.biblioteca.guardar_datos()
                    self._populate_prestamos_treeview(self.biblioteca.get_prestamos())
                    self._populate_libros_treeview(self.biblioteca.get_libros())

                def cancel_multa_paid():
                    self._update_status(f"⚠️ Multa de S/.{prestamo.get_monto_multa():.2f} pendiente de pago.")
                    self.biblioteca.guardar_datos()
                    self._populate_prestamos_treeview(self.biblioteca.get_prestamos())
                    self._populate_libros_treeview(self.biblioteca.get_libros())

                self._show_custom_confirmation_dialog(
                    "Multa Pendiente",
                    f"El préstamo tiene una multa de S/.{prestamo.get_monto_multa():.2f}.\n¿Ha sido pagada la multa?",
                    confirm_multa_paid,
                    cancel_multa_paid
                )
            else:
                self._update_status("✅ Libro devuelto correctamente. Sin multa.")
                self._clear_input_fields([self.entry_prestamo_dni_usuario, self.entry_prestamo_codigo_libro])
                self._populate_prestamos_treeview(self.biblioteca.get_prestamos())
                self._populate_libros_treeview(self.biblioteca.get_libros()) 

    def _mostrar_todos_los_prestamos(self):
        prestamos = self.biblioteca.get_prestamos()
        self._populate_prestamos_treeview(prestamos)
        self._update_status("Mostrando todos los préstamos (activos y devueltos).")

    def _mostrar_prestamos_activos(self):
        prestamos_activos = [p for p in self.biblioteca.get_prestamos() if p.es_activo()]
        self._populate_prestamos_treeview(prestamos_activos)
        self._update_status("Mostrando préstamos activos.")

    def _mostrar_prestamos_vencidos(self):
        prestamos_vencidos = self.biblioteca.get_prestamos_vencidos()
        self._populate_prestamos_treeview(prestamos_vencidos)
        if prestamos_vencidos:
            self._update_status(f"⚠️ Se encontraron {len(prestamos_vencidos)} préstamo(s) vencido(s).")
        else:
            self._update_status("✅ No hay préstamos vencidos.")

    def _mostrar_prestamos_proximos_a_vencer(self):
        prestamos_proximos = self.biblioteca.get_prestamos_proximos_a_vencer()
        self._populate_prestamos_treeview(prestamos_proximos)
        if prestamos_proximos:
            self._update_status(f"🔔 Se encontraron {len(prestamos_proximos)} préstamo(s) próximo(s) a vencer.")
        else:
            self._update_status("✅ No hay préstamos próximos a vencer.")


    def _populate_prestamos_treeview(self, prestamos):
        for item in self.tree_prestamos.get_children():
            self.tree_prestamos.delete(item)
        
        if not prestamos:
            self.tree_prestamos.insert("", "end", values=("", "", "", "", "", "No hay préstamos para mostrar.", "", "", ""))
            return

        for prestamo in prestamos:
            usuario_obj = self.biblioteca.get_usuario_by_uuid(prestamo.get_usuario_uuid())
            libro_obj = self.biblioteca.get_libro_by_uuid(prestamo.get_libro_uuid())
            bibliotecario_obj = self.biblioteca.get_bibliotecario_by_uuid(prestamo.get_bibliotecario_uuid())

            usuario_info = f"{usuario_obj.get_nombre()} (DNI: {usuario_obj.get_dni()})" if usuario_obj else f"UUID: {prestamo.get_usuario_uuid()}"
            libro_info = f"'{libro_obj.get_titulo()}' (Cód: {libro_obj.get_codigo()})" if libro_obj else f"UUID: {prestamo.get_libro_uuid()}"
            bibliotecario_info = f"{bibliotecario_obj.get_nombre()} (ID: {bibliotecario_obj.get_id()})" if bibliotecario_obj else f"UUID: {prestamo.get_bibliotecario_uuid()}"
            
            fecha_real_str = prestamo.get_fecha_devolucion_real().strftime('%Y-%m-%d') if prestamo.get_fecha_devolucion_real() else "Pendiente"
            multa_str = f"S/.{prestamo.get_monto_multa():.2f}" if prestamo.get_monto_multa() > 0 else "N/A"
            pagada_str = "Sí" if prestamo.esta_multa_pagada() else "No"
            estado_str = "Activo" if prestamo.es_activo() else "Devuelto"

            self.tree_prestamos.insert("", "end", values=(
                usuario_info,
                libro_info,
                bibliotecario_info,
                prestamo.get_fecha_prestamo().strftime('%Y-%m-%d'),
                prestamo.get_fecha_devolucion_estimada().strftime('%Y-%m-%d'),
                fecha_real_str,
                multa_str,
                pagada_str,
                estado_str
            ))


if __name__ == "__main__":
    root = tk.Tk()
    app = BibliotecaGUI(root)
    root.mainloop()
