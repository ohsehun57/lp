"""from abc import ABC,abstractmethod
class animal (ABC):
    @ abstractmethod
    def hacer_sonido(self):
        pass

class perro(animal):
    def hacer_sonido(self):
        return "gau gau"
    
class gato(animal):
    def hacer_sonido(self):
        return "mia miau"

perro1 = perro()
print(perro1.hacer_sonido())
gato1=gato()
print(gato1.hacer_sonido())}


#abstracta

from abc import ABC,abstractmethod
class FORMA (ABC):
    @ abstractmethod
    def calcula_area(self):
        pass

class cuadrado(FORMA):
    def __init__(self,lado):
        self.lado=lado

    def calcula_area(self):
        return self.lado**2
        
    
class circulo(FORMA):
    def __init__(self,radio):
        self.radio=radio
    def calcula_area(self):
        return 3.1416 * self.radio**2
cuadrado1 = cuadrado(4)
print("Area del cuadrado: ",cuadrado1.calcula_area())
circulo1=circulo(3)
print("Area del circulo: ",circulo1.calcula_area())



#escepciones

class calcuadora:
    def divicion(self,a,b):
        try:
            return a/b
        except ZeroDivisionError:
            return " divicion entre cero"
        
calc=calcuadora()
print(calc.divicion(10,2))
print(calc.divicion(5,0))

"""

from abc import ABC,abstractmethod
import math

class FORMA (ABC):
    @ abstractmethod
    def calcula_area(self):
        pass

class cuadrado(FORMA):
    def __init__(self,lado):
        if lado<=0:
            raise ValueError("el lado debe ser mayor que 0")
        self.lado=lado

    def calcula_area(self):
        return self.lado**2
    
class triangulo(FORMA):
    def __init__(self,base,altura):
        if base<=0 or altura<=0:
            raise ValueError("base y altura debe ser mayor que 0")
        self.base=base
        self.altura=altura

    def calcula_area(self):
        return (self.base * self.altura)/2
        

class rectangulo(FORMA):
    def __init__(self,ancho,largo):
        if ancho<=0 or largo<=0:
            raise ValueError("ancho y largo debe ser mayor que 0")
        self.ancho=ancho
        self.largo=largo

    def calcula_area(self):
        return (self.ancho * self.largo)
    

class circulo(FORMA):
    def __init__(self,radio):
        if radio<=0:
            raise ValueError("el radio debe ser mayor que 0")
        self.radio=radio

    def calcula_area(self):
        return self.radio**2 * math.pi
    
        


def calcular_area_figura():
    try:
        FORMA =input("ingrese cuadrado , triangulo , rectangulo o circulo:").lower()
        if FORMA =='cuadrado':
            lado = float(input("lado del cuadrado: "))
            c  =cuadrado (lado)
            print("area del cuadrado: ",c.calcula_area())

        elif FORMA=='triangulo':
            base =float(input("base del triangulo: "))
            altura =float(input("altura del triangulo: "))
            t=triangulo(base,altura)
            print("area del triangulo",t.calcula_area())


        elif FORMA=='rectangulo':
            ancho =float(input("ancho del rectangulo: "))
            largo =float(input("largo del rectangulo: "))
            r=rectangulo(ancho,largo)
            print("area del triangulo",r.calcula_area())

        elif FORMA =='circulo':
            radio = float(input("radio del circulo: "))
            cir  =circulo (radio)
            print("area del circulo: ",cir.calcula_area())

        else:
            print("figura no encontrada")
    except ValueError as ve:
        print("ERROR",ve)
    except Exception as e:
        print("ocurrio un error inesperado",e)

calcular_area_figura()