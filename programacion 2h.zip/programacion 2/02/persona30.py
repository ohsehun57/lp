import sys

class persona:
    def __init__(self,nombre):
        self.nombre=nombre
p1 =persona("patricia")
tamaño=sys.getsizeof(p1)
print(f"el objrtp p1 ocupa {tamaño} bytes en memoria")