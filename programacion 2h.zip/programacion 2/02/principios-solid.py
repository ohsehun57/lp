"""from abc import ABC, abstractmethod
from math import sqrt

# Principio de Inversión de Dependencias (DIP) y Segregación de Interfaces (ISP)
class ICalculator(ABC):
    @abstractmethod
    def calculate(self, a: float, b: float) -> float:
        pass

# Principio de Responsabilidad Única (SRP)
class PythagorasCalculator(ICalculator):
    def calculate(self, a: float, b: float) -> float:
        return sqrt(a ** 2 + b ** 2)

# Clase que usa la calculadora (abierto a extensión, cerrado a modificación - OCP)
class TriangleHypotenuse:
    def __init__(self, calculator: ICalculator):
        self.calculator = calculator

    def get_hypotenuse(self, a: float, b: float) -> float:
        return self.calculator.calculate(a, b)

# Subclase que cumple con el principio de sustitución de Liskov (LSP)
class DetailedPythagorasCalculator(PythagorasCalculator):
    def calculate(self, a: float, b: float) -> float:
        print(f"Calculando hipotenusa con a={a} y b={b}...")
        return super().calculate(a, b)

# Uso del sistema
if __name__ == "__main__":
    a = float(input("Ingrese el cateto a: "))
    b = float(input("Ingrese el cateto b: "))

    calculator = DetailedPythagorasCalculator()
    triangle = TriangleHypotenuse(calculator)

    hipotenusa = triangle.get_hypotenuse(a, b)
    print(f"La hipotenusa es: {hipotenusa:.2f}")
"""
from abc import ABC, abstractmethod
from typing import List

# -------------------------------
# Interfaces (DIP + ISP)
# -------------------------------
class IProduct(ABC):
    @abstractmethod
    def get_price(self) -> float:
        pass

    @abstractmethod
    def get_description(self) -> str:
        pass

class IPrinter(ABC):
    @abstractmethod
    def print_invoice(self, items: List[IProduct]) -> None:
        pass

# -------------------------------
# Clase Producto (SRP)
# -------------------------------
class Product(IProduct):
    def __init__(self, name: str, price: float):
        self.name = name
        self.price = price

    def get_price(self) -> float:
        return self.price

    def get_description(self) -> str:
        return self.name

# -------------------------------
# Clase Factura (SRP + DIP)
# -------------------------------
class Invoice:
    def __init__(self):
        self.items: List[IProduct] = []

    def add_item(self, item: IProduct):
        self.items.append(item)

    def get_total(self) -> float:
        return sum(item.get_price() for item in self.items)

    def get_items(self) -> List[IProduct]:
        return self.items

# -------------------------------
# Impresora Simple (LSP + OCP)
# -------------------------------
class SimplePrinter(IPrinter):
    def print_invoice(self, items: List[IProduct]) -> None:
        print("----- FACTURA -----")
        for item in items:
            print(f"{item.get_description()} - S/. {item.get_price():.2f}")
        total = sum(item.get_price() for item in items)
        print("-------------------")
        print(f"TOTAL: S/. {total:.2f}")
        print("-------------------")

# -------------------------------
# Clase Sistema de Facturación
# -------------------------------
class BillingSystem:
    def __init__(self, printer: IPrinter):
        self.invoice = Invoice()
        self.printer = printer

    def add_product(self, product: IProduct):
        self.invoice.add_item(product)

    def generate_invoice(self):
        self.printer.print_invoice(self.invoice.get_items())

# -------------------------------
# Uso del sistema
# -------------------------------
if __name__ == "__main__":
    # Crear impresora
    printer = SimplePrinter()

    # Crear sistema de facturación
    system = BillingSystem(printer)

    # Agregar productos
    system.add_product(Product("Teclado", 150.00))
    system.add_product(Product("Mouse", 60.00))
    system.add_product(Product("Monitor", 720.00))

    # Generar factura
    system.generate_invoice()
