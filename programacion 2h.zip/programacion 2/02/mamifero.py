class mamifero:
    def caracteristicas(self):
        return "tiene pelo"
    
class acuatico:
    def vivir(self):
        return "viven en el agua"
class delfin(mamifero,acuatico):
    pass

d = delfin()
print("=============el delfin==============")
print(d.caracteristicas())
print(d.vivir())