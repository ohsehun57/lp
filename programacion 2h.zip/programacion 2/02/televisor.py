
from abc import ABC , abstractmethod
class dispocitivosElectornicos(ABC):
    @abstractmethod
    def encender(self):
        pass 
    @abstractmethod
    def apagar(sel):
        pass

    
class telivisor(dispocitivosElectornicos):
    def encender(self):
        print("televisor encendido")

    def apagar(self):
        print("televisor apagado")

class radio(dispocitivosElectornicos):
    def encender(self):
        print("radio encendido")

    def apagar(self):
        print("radio apagado")
        
tv = telivisor()
tv.encender()

r = radio()
r.encender()