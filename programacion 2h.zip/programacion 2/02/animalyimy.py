class animal:
    def __init__(self, Nombre, Especie,Edad):
        self.nombre = Nombre
        self.especie = Especie
        self.edad = Edad
    
    def come(self,mensaje):
        print( f"{self.nombre} el chiwawa comio {mensaje} ")

    def caminar(self,distancia):
        print( f"{self.nombre} ha caminado {distancia} kilometros")

    def dormir(self,horas):
        print( f"{self.nombre} ha dormido {horas} horas")


# Creación de  objetos
animal1 = animal("yimi",'chihuawa',5)
animal2  = animal("machaca", 'criollo',12)

#uso de metodos


print("\n----acciones de yimy---")
animal1.come("croquetas")

animal1.caminar(50)
animal1.dormir(10)


print("\n----acciones de machaca---")
animal2.come("desperdicios")

animal2.caminar(1)
animal2.dormir(20)