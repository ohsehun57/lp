"""from typing import TypeVar, Generic
import math

R = TypeVar("R", int, float)


class OperacionMatematica(Generic[R]):
    def calcular(self, a: R, b: R) -> R:
        raise NotImplementedError("Método calcular() no implementado")


class hipo(OperacionMatematica[R]):
    def calcular(self, a: R, b: R) -> R:
        return math.sqrt(a**2 + b**2)

def main():
    operacion = hipo()
    num1 = 5
    num2 = 7
    resultado = operacion.calcular(num1, num2)
    print(f"La hipotenusa de los catetos de {num1} y {num2} es {resultado: .2f}")

if __name__ == "__main__":
    main()
"""




#programacion generica factorial
#  
from typing import TypeVar,Generic
T = TypeVar("T",int,float )
class operacionmatematica (Generic[T]):
    def calcular (self,a:T) ->T:
        raise  NotImplementedError ("metodo calcular() no implementDO")
class hallarhipotenusa (operacionmatematica[T]):
    def calcular (self,a:T) ->T:
        if a < 1:
            print("ingrese un numero positivo")
        else:
            resultado = 1
            for i in range (1,a+1):
                resultado *= i
            return resultado
def main():
    operacion = hallarhipotenusa ()
    cat1 = 5
    resultado = operacion.calcular(cat1)
    print(f"el factorial de {cat1} es {resultado}")
if __name__=="__main__":
    main()





