from typing import TypeVar, Generic
import math

R = TypeVar("R", int, float)


class OperacionMatematica(Generic[R]):
    def calcular(self, a: R, b: R) -> R:
        raise NotImplementedError("Método calcular() no implementado")


class suma(OperacionMatematica[R]):
    def calcular(self, a: R, b: R) -> R:
        return a+b
    
class resta(OperacionMatematica[R]):
    def calcular(self, a: R, b: R) -> R:
        return a-b
    
class multiplicacion(OperacionMatematica[R]):
    def calcular(self, a: R, b: R) -> R:
        return a*b
    
class divicion(OperacionMatematica[R]):
    def calcular(self, a: R, b: R) -> R:
        if b<1:
            print("el numero debe ser mayor a cero")
        else:
            return a/b
"""
def main():
    operacion = suma()
    num1 = 5
    num2 = 7

    operacion1 = resta()
    num3 = 5
    num4 = 7

    operacion2 = multiplicacion()
    num5 = 5
    num6 = 7

    operacion3 = divicion()
    num7 = 5
    num8 = 0



    resultado = operacion.calcular(num1, num2)
    print(f"La suma de {num1} y {num2} es {resultado: .2f}")

    resultado1 = operacion1.calcular(num3, num4)
    print(f"La resta de {num3} y {num4} es {resultado1: .2f}")

    resultado2 = operacion2.calcular(num5, num6)
    print(f"La multiplicacion de {num5} y {num6} es {resultado2: .2f}")

    resultado3 = operacion3.calcular(num7, num8)
    print(f"La divicion de {num7} y {num8} es {resultado3: .2f}")


if __name__ == "__main__":
    main()

"""
def main():
    lista_OPER= [] 
    while True:
        print("\n---***** CALCULADORA *****---")
        print("1. SUMA")
        print("2. RESTA")
        print("3. MULTIPLICACION")
        print("4. DIVICION")
        print("5. SALIR")

        opcion = input("Ingrese una opción: ")

        if opcion == "1":
            num1 = int(input("num1 "))
            num2 = int(input("num2 "))
            try:
                suma = float(input("Salario Base del Administrativo: S/. "))
            except ValueError:
                print("❌ Salario base inválido. Por favor, ingrese un número.")
                continue
            admin = Administrativo(nombre, dni, salario_base)
            lista_empleados.append(admin)
            print("✅ Administrativo registrado con éxito.")

        elif opcion == "2":
            nombre = input("Nombre del Operario: ")
            dni = input("DNI del Operario: ")
            try:
                salario_base = float(input("Salario Base del Operario: S/. "))
                bono = float(input("Bono por Horas Extra del Operario: S/. "))
            except ValueError:
                print("❌ Entrada inválida (salario o bono). Por favor, ingrese números.")
                continue
            oper = Operario(nombre, dni, salario_base, bono)
            lista_empleados.append(oper)
            print("✅ Operario registrado con éxito.")

        elif opcion == "3":
            if not lista_empleados:
                print("⚠️ No hay empleados registrados para mostrar.")
            else:
                print("\n--- LISTA DE EMPLEADOS REGISTRADOS ---")
                for empleado in lista_empleados:
                    # Polimorfismo en acción: llama al método mostrar_info de la subclase correcta
                    empleado.mostrar_info()

        elif opcion == "4":
            print("👋 Saliendo del sistema de gestión de empleados. ¡Hasta pronto!")
            break

        else:
            print("❌ Opción no válida. Por favor, intente de nuevo con una opción del 1 al 4.")

# Asegura que main() se ejecute solo cuando el script es el programa principal
if __name__ == "__main__":
    main()