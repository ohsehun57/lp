class Persona:
    def __init__(self, Nombre, Edad,Altura):
        self.nombre = Nombre
        self.edad = Edad
        self.altura = Altura
    
    def hablar(self,mensaje):
        print( f"{self.nombre} dice: {mensaje} ")

    def caminar(self,distancia):
        print( f"{self.nombre} ha caminado {distancia} metros")

    def dormir(self,horas):
        print( f"{self.nombre} ha dormido {horas} horas")


# Creación de  objetos
persona1 = Persona("juan", 25,1.75)
persona2 = Persona("maria", 30,1.55)

#uso de metodos


print("\n----acciones de juan---")
persona1.hablar("hola.¿como estas?")
persona1.caminar(500)
persona1.dormir(8)

print("\n----acciones de maria---")
persona2.hablar("hola.buenos diads")
persona2.caminar(300)
persona2.dormir(7)