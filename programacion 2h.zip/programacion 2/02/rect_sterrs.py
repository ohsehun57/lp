class Recta:
    def __init__(self, base, altura):
        self.__base = base
        self.__altura = altura

    # Getter para base
    @property
    def base(self):
        return self.__base

    # Setter para base
    @base.setter
    def base(self, nueva_base):
        if nueva_base > 0:
            self.__base = nueva_base
        else:
            print("Base no válida")

    # Getter para altura
    @property
    def altura(self):
        return self.__altura

    # Setter para altura
    @altura.setter
    def altura(self, nueva_altura):
        if nueva_altura > 0:
            self.__altura = nueva_altura
        else:
            print("Altura no válida")

    def mostrar_datos(self):
        print(f"Base: {self.__base}, Altura: {self.__altura}")

    # Método para calcular el área
    def calcular_area(self):
        return self.__base * self.__altura

    # Método para calcular el perímetro (de un rectángulo)
    def calcular_perimetro(self):
        return 2 * (self.__base + self.__altura)
