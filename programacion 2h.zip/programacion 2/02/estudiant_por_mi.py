class Estudiante:
    def __init__(self, nombre, edad, carrera):
        self.nombre = input("ingrese tu noimbre")
        self.edad = edad
        self.carrera = carrera
        self.notas = []
    
    def agregar_notas(self, nota):
        self.notas.append(nota)
    
    
   
    
    def mostrar_informacion(self):
            promedio =  sum(self.notas) / len(self.notas) if self.notas else 0
            aprobado = 'SI' if promedio>=11 else 'NO'
            print("Nombre: ", self.nombre)
            print("Edad: ",self.edad)
            print("Carrera: ", self.carrera)
            print("Notas: ",self.notas)
            print("Promedio: ", round(promedio,2))
            print("Aprobado: " , aprobado )
        
        


estudiante1 = Estudiante("Juan Pérez", 20, "Ingeniería Estadística e Informática")
estudiante1.agregar_notas(18)
estudiante1.agregar_notas(17)
estudiante1.agregar_notas(19)
estudiante1.agregar_notas(14)

# Mostrar la información del estudiante
estudiante1.mostrar_informacion()
