import tkinter as tk
from tkinter import messagebox

class Doctor:
    def __init__(self, nombre, especialidad, experiencia, correo, telefono, hospital):
        self.nombre = nombre
        self.especialidad = especialidad
        self.experiencia = experiencia
        self.correo = correo
        self.telefono = telefono
        self.hospital = hospital

    def mostrar_informacion(self):
        return (
            f"👨‍⚕️ Nombre: {self.nombre}\n"
            f"📌 Especialidad: {self.especialidad}\n"
            f"📅 Experiencia: {self.experiencia} años\n"
            f"📧 Correo: {self.correo}\n"
            f"📞 Teléfono: {self.telefono}\n"
            f"🏥 Hospital: {self.hospital}"
        )

    def atender_paciente(self, paciente):
        return f"🩺 El Dr. {self.nombre} está atendiendo a {paciente}."

    def calcular_salario(self):
        salario_base = 2001
        bono_experiencia = self.experiencia * 150
        salario_total = salario_base + bono_experiencia
        return f"💵 El salario del Dr. {self.nombre} es ${salario_total}"

    def recetar_medicamento(self, medicamento):
        return f"💊 El Dr. {self.nombre} receta: {medicamento}"

# Lista base de doctores
doctores = {
    "Carlos": Doctor("Carlos", "Cardiología", 15, "carlos@hospital.com", "987654321", "Hospital Central"),
    "Raul": Doctor("Raul", "Dentista", 5, "raul@clinicadental.com", "945123789", "Clínica Sonrisas"),
    "Ana": Doctor("Ana", "Pediatría", 12, "ana@hospitalninos.com", "943222111", "Hospital Infantil"),
    "Javier": Doctor("Javier", "Neurología", 18, "javier@neuroclinic.com", "951334455", "NeuroClinic Perú"),
    "Lucia": Doctor("Lucia", "Dermatología", 8, "lucia@dermasalud.com", "900112233", "DermaSalud")
}

# ---------------- FUNCIONES ----------------
def buscar_doctor():
    nombre = doctor_nombre_entry.get().strip()
    if nombre in doctores:
        global doctor_actual
        doctor_actual = doctores[nombre]
        actualizar_info()
    else:
        messagebox.showerror("Error", f"No se encontró un doctor con el nombre '{nombre}'")

def actualizar_info():
    info_label.config(text=doctor_actual.mostrar_informacion())

def atender():
    paciente = paciente_entry.get()
    if paciente:
        resultado = doctor_actual.atender_paciente(paciente)
        messagebox.showinfo("Atención al Paciente", resultado)
    else:
        messagebox.showwarning("Error", "Ingrese el nombre del paciente")

def calcular_salario():
    resultado = doctor_actual.calcular_salario()
    messagebox.showinfo("Cálculo de Salario", resultado)

def recetar():
    medicamento = medicamento_entry.get()
    if medicamento:
        resultado = doctor_actual.recetar_medicamento(medicamento)
        messagebox.showinfo("Receta Médica", resultado)
    else:
        messagebox.showwarning("Error", "Ingrese el medicamento")

# ---------------- INTERFAZ GRÁFICA ----------------
ventana = tk.Tk()
ventana.title("Panel de Gestión de Doctores")
ventana.geometry("540x600")
ventana.configure(bg="#e0f7fa")

# Panel izquierdo
contenedor = tk.Frame(ventana, bg="#e0f7fa")
contenedor.pack(anchor="w", padx=20, pady=10, fill="both")

tk.Label(contenedor, text="🩺 Panel de Gestión de Doctores", font=("Helvetica", 16, "bold"),
         bg="#e0f7fa", fg="#00695c", anchor="w").pack(anchor="w", pady=5)

# Entrada de nombre de doctor
tk.Label(contenedor, text="🆔 Nombre del Doctor:", font=("Arial", 10, "bold"), bg="#e0f7fa").pack(anchor="w", pady=2)
doctor_nombre_entry = tk.Entry(contenedor)
doctor_nombre_entry.pack(anchor="w", pady=2)
tk.Button(contenedor, text="Buscar Doctor", bg="#4db6ac", fg="white", command=buscar_doctor).pack(anchor="w", pady=5)

# Información del doctor
frame_info = tk.Frame(contenedor, bg="#b2ebf2", bd=2, relief="solid")
frame_info.pack(anchor="w", pady=5, fill="x")

info_label = tk.Label(frame_info, text="", font=("Arial", 10), justify="left", bg="#b2ebf2", anchor="w")
info_label.pack(padx=10, pady=10, anchor="w")

# Sección paciente
tk.Label(contenedor, text="👤 Nombre del paciente:", bg="#e0f7fa", font=("Arial", 10, "bold")).pack(anchor="w", pady=2)
paciente_entry = tk.Entry(contenedor)
paciente_entry.pack(anchor="w", pady=2)

tk.Button(contenedor, text="Atender Paciente", bg="#00796b", fg="white", command=atender).pack(anchor="w", pady=5)

# Botón de salario
tk.Button(contenedor, text="Calcular Salario", bg="#00796b", fg="white", command=calcular_salario).pack(anchor="w", pady=5)

# Sección medicamento
tk.Label(contenedor, text="💊 Medicamento:", bg="#e0f7fa", font=("Arial", 10, "bold")).pack(anchor="w", pady=2)
medicamento_entry = tk.Entry(contenedor)
medicamento_entry.pack(anchor="w", pady=2)

tk.Button(contenedor, text="Recetar Medicamento", bg="#26a69a", fg="white", command=recetar).pack(anchor="w", pady=5)

# Inicializa con doctor Carlos
doctor_actual = doctores["Carlos"]
actualizar_info()

ventana.mainloop()
