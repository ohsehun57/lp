class personas:
    def __init__(self,nombre):
        self.nombre =nombre
        print(f"hola soy {self.nombre}")

    def __del__(self):
        print(f"{self.nombre} fue eliminado")

prsona1 =personas("raul")

del prsona1
print("fin del programa")

