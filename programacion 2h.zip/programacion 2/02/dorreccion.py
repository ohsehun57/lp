class EStudiante:
    def __init__(self,nombre,edad,notas):
        self._nombre=nombre
        self._edad=edad
        self._notas=notas
        self._promedio= sum(self._notas) /len(self._notas)

    def mostrar_info(self):
        print("Nonbre : ", self._nombre)
        print("Edad : ", self._edad)
        print(f"promedio : ,{self._promedio: .2f}")

    def agregar_notas(self):
        self._nota.append(nota)

e = EStudiante("ana",20,[20,18,17])
e.mostrar_info()
e.agregar_nota(20)
    

