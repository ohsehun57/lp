class Persona:
    def __init__(self, Nombre, Edad):
        self.__nombre = Nombre
        self.__edad = Edad
        
# getter para nombres
    def obtener_nombre(self):
        return self.__nombre 
# getter para edad
    def obtener_eddad(self):
        return self.__edad    
# setter para edad
    def establecer_edad(self,nueva_edad):
        if nueva_edad > 0:
            self.__edad=nueva_edad
        else:
            print(" edad no valida")

    def es_mayor_edad(self):
        return self.__edad>=18

    def mostrar_datos(self):
        print(f"nombre:  {self.__nombre} , edad:  {self.__edad}")

    def cumpleaños_nuevo(self):
        self.__edad+=1
        print(f"! feliz cumpleaños¡ ,{self.__nombre}, ahoratienes  {self.__edad} años")

#uso de la clase
persona1 = Persona("juan", 15)
persona1.mostrar_datos()
persona1.cumpleaños_nuevo()
persona1.mostrar_datos()
if persona1.es_mayor_edad():
    print("es mayor de edad")
else:
    print("es menor de edad")
