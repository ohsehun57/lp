import tkinter as tk
from tkinter import ttk
import math

class Producto:
    def __init__(self, nombre, precio):
        self._nombre = nombre
        self._precio = precio

    def obtener_nombre(self):
        return self._nombre

    def obtener_precio(self):
        return self._precio

    def establecer_nombre(self, nuevo_nombre):
        self._nombre = nuevo_nombre

    def establecer_precio(self, nuevo_precio):
        if nuevo_precio >= 0:
            self._precio = nuevo_precio
            return True
        return False

    def calcular_precio_imp(self):
        return self._precio * 1.18


class ProductoApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Gestor de Productos")
        self.root.geometry("600x300")
        self.root.resizable(False, False)

        self.producto = None

        # Estilo
        style = ttk.Style()
        style.configure("TButton", padding=6)
        style.configure("TLabel", padding=4)

        # --- Entrada de datos ---
        frame_datos = ttk.LabelFrame(root, text="Datos del Producto", padding=10)
        frame_datos.pack(fill=tk.X, padx=10, pady=10)

        ttk.Label(frame_datos, text="Nombre:").grid(row=0, column=0, padx=5, pady=5)
        self.nombre_var = tk.StringVar()
        ttk.Entry(frame_datos, textvariable=self.nombre_var, width=25).grid(row=0, column=1)

        ttk.Label(frame_datos, text="Precio:").grid(row=0, column=2, padx=5)
        self.precio_var = tk.StringVar()
        ttk.Entry(frame_datos, textvariable=self.precio_var, width=10).grid(row=0, column=3)

        ttk.Label(frame_datos, text="Nuevo Precio:").grid(row=1, column=0, padx=5, pady=5)
        self.nuevo_precio_var = tk.StringVar()
        ttk.Entry(frame_datos, textvariable=self.nuevo_precio_var, width=10).grid(row=1, column=1)

        # --- Área de botones ---
        frame_botones = ttk.Frame(root)
        frame_botones.pack(pady=5)

        ttk.Button(frame_botones, text="Crear Producto", command=self.crear_producto).grid(row=0, column=0, padx=6)
        ttk.Button(frame_botones, text="Mostrar Info", command=self.mostrar_info).grid(row=0, column=1, padx=6)
        ttk.Button(frame_botones, text="Actualizar Precio", command=self.actualizar_precio).grid(row=0, column=2, padx=6)
        ttk.Button(frame_botones, text="Limpiar", command=self.limpiar).grid(row=0, column=3, padx=6)
        ttk.Button(frame_botones, text="Salir", command=root.destroy).grid(row=0, column=4, padx=6)

        # --- Área de información ---
        frame_info = ttk.LabelFrame(root, text="Información", padding=10)
        frame_info.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        self.info_text = tk.Text(frame_info, height=5, width=70, wrap=tk.WORD, state=tk.DISABLED)
        self.info_text.pack(fill=tk.BOTH, expand=True)

    def crear_producto(self):
        nombre = self.nombre_var.get().strip()
        try:
            precio = float(self.precio_var.get())
        except ValueError:
            self.mostrar_mensaje("❌ Precio inválido.")
            return

        if not nombre:
            self.mostrar_mensaje("❌ Debe ingresar un nombre.")
            return
        if precio < 0:
            self.mostrar_mensaje("❌ El precio no puede ser negativo.")
            return

        self.producto = Producto(nombre, precio)
        self.mostrar_mensaje(f"✅ Producto '{nombre}' creado con precio S/ {precio:.2f}")

    def mostrar_info(self):
        if not self.producto:
            self.mostrar_mensaje("⚠️ Primero debe crear un producto.")
            return

        nombre = self.producto.obtener_nombre()
        precio = self.producto.obtener_precio()
        precio_igv = self.producto.calcular_precio_imp()

        texto = (
            f"📦 Producto: {nombre}\n"
            f"💵 Precio: S/ {precio:.2f}\n"
            f"🧾 Precio con IGV (18%): S/ {precio_igv:.2f}"
        )
        self.mostrar_mensaje(texto)

    def actualizar_precio(self):
        if not self.producto:
            self.mostrar_mensaje("⚠️ Primero debe crear un producto.")
            return

        try:
            nuevo_precio = float(self.nuevo_precio_var.get())
        except ValueError:
            self.mostrar_mensaje("❌ El nuevo precio debe ser un número.")
            return

        if self.producto.establecer_precio(nuevo_precio):
            self.mostrar_mensaje(f"🔁 Precio actualizado a S/ {nuevo_precio:.2f}")
        else:
            self.mostrar_mensaje("❌ El precio no puede ser negativo.")

    def limpiar(self):
        self.nombre_var.set("")
        self.precio_var.set("")
        self.nuevo_precio_var.set("")
        self.info_text.config(state=tk.NORMAL)
        self.info_text.delete(1.0, tk.END)
        self.info_text.config(state=tk.DISABLED)
        self.producto = None

    def mostrar_mensaje(self, mensaje):
        self.info_text.config(state=tk.NORMAL)
        self.info_text.delete(1.0, tk.END)
        self.info_text.insert(tk.END, mensaje)
        self.info_text.config(state=tk.DISABLED)


if __name__ == "__main__":
    root = tk.Tk()
    app = ProductoApp(root)
    root.mainloop()
