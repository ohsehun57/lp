class animal:
    def __init__(self,nombre):
        self.nombre=nombre

    def hablar(self):
        return f"{self.nombre} hace sonido"
    
class perro(animal):
    def hablar(self):
        return f"{self.nombre} dice ¡GAU GAU!"
    

animal = animal ("animal generico")
print(animal.hablar())

perro=perro("firulais")
print(perro.hablar())