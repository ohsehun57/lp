
import pygame
import sys
import random
import math
from pygame import mixer

pygame.init()
mixer.init()

# Configuración de pantalla
WIDTH, HEIGHT = 800, 600
SCREEN = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Heredero del Abismo")

# Fuentes
FONT = pygame.font.SysFont('Arial', 24)
BIG_FONT = pygame.font.SysFont('Arial', 36)
TITLE_FONT = pygame.font.SysFont('Arial', 48, bold=True)

# Colores
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (100, 100, 100)
BLUE = (0, 120, 215)
DARK_BLUE = (0, 80, 140)
RED = (220, 0, 0)
DARK_RED = (160, 0, 0)
PURPLE = (130, 0, 200)
DARK_PURPLE = (80, 0, 140)

# Efectos visuales
particles = []
background_effects = []

clock = pygame.time.Clock()

# Sistema de sonido
try:
    click_sound = mixer.Sound("click.wav")
    ambient_sound = mixer.Sound("ambient.wav")
    # Si no tienes estos archivos, el juego funcionará sin sonido
except:
    click_sound = None
    ambient_sound = None

# Intentar reproducir música ambiental en loop
try:
    mixer.music.load("background.mp3")
    mixer.music.set_volume(0.3)
    mixer.music.play(-1)  # -1 significa loop infinito
except:
    pass  # Si no hay archivo de música, seguimos sin ella

# Datos del juego expandidos
maps = {
    0: {  # Pantalla de título
        "title": "Heredero del Abismo",
        "description": "Un viaje hacia la oscuridad y la redención.\n\n¿Te atreves a descubrir tu destino?",
        "choices": {
            "Comenzar aventura": 1,
            "Créditos": -1,
            "Salir": -2
        },
        "background": "title",
        "music": "title"
    },
    -1: {  # Créditos
        "title": "Créditos",
        "description": "Heredero del Abismo\n\nDesarrollado como ejemplo de juego narrativo con Pygame\n\nLas decisiones que tomes cambiarán tu destino...",
        "choices": {
            "Volver al menú": 0
        },
        "background": "credits",
        "music": "title"
    },
    1: {
        "title": "Aldea del Juicio",
        "description": "Vives en una aldea donde te consideran un niño maldito debido a las marcas extrañas en tu piel y tus ojos que cambian de color con tus emociones.\n\nLas voces internas crecen cada día más fuertes, susurrando secretos prohibidos en tu mente.\n\nUna noche, los inquisidores atacan tu hogar. Debes decidir cómo enfrentarlos.",
        "choices": {
            "Defenderte usando los poderes que apenas comprendes": 2,
            "Resistir y esperar la ayuda prometida en tus sueños": 3,
            "Intentar escapar hacia el Bosque Prohibido": 4
        },
        "background": "village",
        "music": "tension"
    },
    2: {
        "title": "Poder Desatado",
        "description": "La ira hierve en tu interior. Tus manos arden con un fuego negro mientras las voces te guían.\n\nLos inquisidores retroceden aterrorizados cuando desatas poderes que ni tú mismo comprendes.\n\nCuando todo termina, la mitad de la aldea está en ruinas y los sobrevivientes huyen de ti.",
        "choices": {
            "Huir hacia el Bosque de la Sangre": 5,
            "Perseguir a los inquisidores para terminar lo que empezaste": 6
        },
        "background": "village_destroyed",
        "music": "combat"
    },
    3: {
        "title": "El Protector Oscuro",
        "description": "Mientras los inquisidores irrumpen en tu casa, una sombra gigante emerge del suelo.\n\nUna criatura de oscuridad y huesos te protege, destrozando a tus atacantes.\n\n\"El Progenitor te reclama, pequeño heredero\", te dice la criatura inclinándose. \"Sígueme al bosque.\"",
        "choices": {
            "Seguir a la criatura hacia el Bosque de la Sangre": 5,
            "Rechazar su ayuda y huir por tu cuenta": 4
        },
        "background": "shadow_protector",
        "music": "mystery"
    },
    4: {
        "title": "Escape al Bosque",
        "description": "Escapas en medio del caos, con los gritos de los aldeanos desvaneciéndose tras de ti.\n\nEl Bosque Prohibido te recibe con susurros y sombras danzantes entre los árboles.\n\nSientes que algo te observa, algo que te ha estado esperando por mucho tiempo.",
        "choices": {
            "Adentrarte más en el bosque siguiendo los susurros": 5,
            "Buscar un refugio para pasar la noche": 7
        },
        "background": "dark_forest",
        "music": "forest"
    },
    5: {
        "title": "Bosque de la Sangre",
        "description": "Los árboles del bosque lloran un líquido rojo que parece sangre. Las voces en tu cabeza son más claras aquí.\n\nUn anciano de ojos completamente negros te espera en un claro. \"Soy el Guardián de los Nombres, y he estado esperándote, Heredero.\"\n\nTe ofrece un cáliz hecho de hueso. \"Bebe, y despierta tu verdadero potencial.\"",
        "choices": {
            "Aceptar el cáliz y beber": 8,
            "Rechazar la oferta y exigir respuestas": 9
        },
        "background": "blood_forest",
        "music": "mystery"
    },
    6: {
        "title": "Cazador de Inquisidores",
        "description": "Persigues a los inquisidores que escaparon, un hambre salvaje te impulsa a cobrar venganza.\n\nLos alcanzas en el camino hacia la ciudad principal. El miedo en sus ojos alimenta tu poder.\n\nMientras los enfrentas, notas que tu piel se endurece y tus dedos se alargan formando garras.",
        "choices": {
            "Ceder al instinto depredador y masacrarlos": 10,
            "Dejarlos ir con una advertencia para los demás": 11
        },
        "background": "road_night",
        "music": "combat"
    },
    7: {
        "title": "Cueva del Reflejo",
        "description": "Encuentras una cueva para refugiarte. En su interior, un pequeño estanque refleja más que tu imagen.\n\nVes versiones futuras de ti mismo: un demonio coronado sobre un trono de huesos; un mártir sacrificándose para sellar algo terrible; un ser transformado, ni humano ni bestia.\n\nAl tocar el agua, tienes una visión de una catedral en ruinas.",
        "choices": {
            "Dirigirte hacia la catedral de tu visión": 12,
            "Buscar al Guardián del Bosque que mencionan los susurros": 5
        },
        "background": "cave",
        "music": "mystery"
    },
    8: {
        "title": "El Despertar del Poder",
        "description": "El líquido del cáliz quema como fuego líquido. Caes de rodillas mientras tu cuerpo se transforma.\n\nTu piel se endurece en algunas zonas formando placas como de armadura. Tus manos desarrollan garras afiladas.\n\nEl Guardián sonríe. \"Las Garras Demoníacas han despertado. Eres digno de entrar en la Catedral de los Perdidos.\"",
        "choices": {
            "Seguir al Guardián hacia la Catedral": 12,
            "Probar tus nuevos poderes en el bosque": 13
        },
        "background": "transformation",
        "music": "power"
    },
    9: {
        "title": "Verdades a Medias",
        "description": "\"No beberé nada hasta conocer mi destino\", declaras firmemente.\n\nEl Guardián asiente con respeto. \"Sabia precaución. Eres el último descendiente del Progenitor, un ser de gran poder que fue sellado bajo la Catedral de los Perdidos.\"\n\n\"Tu sangre puede liberarlo o condenarlo para siempre. El cáliz simplemente despertaría los dones que ya están en ti.\"",
        "choices": {
            "Aceptar finalmente beber del cáliz": 8,
            "Rechazar el cáliz y dirigirte a la Catedral por tu cuenta": 12
        },
        "background": "blood_forest",
        "music": "mystery"
    },
    10: {
        "title": "Nacimiento del Depredador",
        "description": "La matanza te transforma por completo. Tu humanidad se desvanece mientras descuartizas a los inquisidores.\n\nCuando recobras el control, estás cubierto de sangre y tus garras gotean. La transformación es irreversible.\n\nUna presencia te llama desde el este, donde se alza una catedral en ruinas contra la luna roja.",
        "choices": {
            "Seguir el llamado de la catedral": 12,
            "Buscar más presas para alimentar tu hambre": 14
        },
        "background": "massacre",
        "music": "horror"
    },
    11: {
        "title": "Dominio del Instinto",
        "description": "Contienes tu sed de sangre y dejas ir a los inquisidores aterrorizados.\n\n\"Contad lo que habéis visto. Que sepan que el Heredero ha despertado\", pronuncias con una voz que resuena con poder oscuro.\n\nTus garras se retraen parcialmente. Has dominado la bestia interior, pero ¿por cuánto tiempo?",
        "choices": {
            "Dirigirte hacia la catedral que ves en la distancia": 12,
            "Buscar al Guardián del Bosque que mencionan tus voces internas": 5
        },
        "background": "road_dawn",
        "music": "tension"
    },
    12: {
        "title": "Catedral de los Perdidos",
        "description": "La catedral se alza imponente, medio derruida y cubierta de enredaderas carmesí.\n\nAl entrar, almas atormentadas flotan como fantasmas, mostrándote visiones de un pasado olvidado.\n\nVes al Progenitor, un ser majestuoso y terrible, creando pactos con entidades del Abismo para proteger el mundo, pero pagando un precio terrible.",
        "choices": {
            "Adentrarte en la cripta bajo el altar": 15,
            "Comunicarte con las almas para aprender más": 16
        },
        "background": "cathedral",
        "music": "cathedral"
    },
    13: {
        "title": "Maestría del Poder",
        "description": "Pasas días en el bosque perfeccionando tus nuevas habilidades. Puedes cortar árboles con tus garras y tu piel endurecida resiste incluso el fuego.\n\nLas criaturas del bosque te reconocen como depredador supremo. Las voces te guían, enseñándote secretos de poderes antiguos.\n\nCuando estás listo, sabes que debes dirigirte a la Catedral.",
        "choices": {
            "Dirigirte a la Catedral de los Perdidos": 12,
            "Volver a la aldea para mostrarles tu nuevo poder": 14
        },
        "background": "training",
        "music": "power"
    },
    14: {
        "title": "Retorno del Maldito",
        "description": "Regresas a la aldea, ahora parcialmente reconstruida. Tu presencia causa pánico inmediato.\n\nEl terror en sus ojos despierta sentimientos contradictorios en ti. Parte de ti anhela protegerlos, mientras otra desea castigarlos por su rechazo.\n\nUn contingente de caballeros de la Orden Sagrada ha llegado para cazarte.",
        "choices": {
            "Enfrentar a los caballeros para demostrar tu poder": 17,
            "Abandonar la aldea y dirigirte a la catedral": 12
        },
        "background": "village_return",
        "music": "tension"
    },
    15: {
        "title": "La Prisión del Progenitor",
        "description": "Desciendes a una cámara circular con inscripciones brillantes. En el centro yace una figura momificada en un trono de hueso y metal.\n\nAl acercarte, la figura abre ojos brillantes. \"Mi sangre. Mi heredero. Has venido a liberarme o a tomar mi lugar?\"\n\nSientes un poder inmenso emanando de él, junto con un dolor eterno que ha soportado para mantener sellado algo mucho peor.",
        "choices": {
            "Ofrecer tu sangre para liberarlo": 18,
            "Reclamar su poder para ti mismo": 19
        },
        "background": "progenitor",
        "music": "climax"
    },
    16: {
        "title": "Susurros del Pasado",
        "description": "Las almas rodean tu cuerpo, susurrando verdades y mentiras mezcladas.\n\nAprendes que el Progenitor hizo un pacto con entidades del Abismo para obtener poder y proteger a la humanidad de una invasión de seres de otro plano.\n\nEl precio fue su propia humanidad y la de su linaje. Ahora su sangre —tu sangre— es lo único que mantiene cerrado el portal en las profundidades.",
        "choices": {
            "Descender a la cripta para enfrentar al Progenitor": 15,
            "Buscar otra salida que no implique sacrificio": 20
        },
        "background": "souls",
        "music": "mystery"
    },
    17: {
        "title": "Batalla en la Aldea",
        "description": "Los caballeros atacan con armas bendecidas que pueden herir incluso tu piel endurecida.\n\nLa batalla es feroz. Descubres que puedes absorber las almas de los caídos, incrementando tu poder con cada muerte.\n\nCuando el último caballero cae, has cambiado. Tu poder ha crecido, pero también la influencia del Abismo sobre ti.",
        "choices": {
            "Dirigirte finalmente a la catedral": 12,
            "Continuar el camino de poder cazando más enemigos": 21
        },
        "background": "battle",
        "music": "combat"
    },
    18: {
        "title": "La Liberación",
        "description": "Ofreces tu sangre, cortando tu palma y permitiendo que las gotas caigan sobre el Progenitor.\n\nSu cuerpo se regenera, absorbiendo tu vitalidad. Te sientes débil pero en paz.\n\n\"Mi heredero, tu sacrificio no será en vano. Tomaré nuevamente la carga del sello\", dice mientras te desplomas.",
        "choices": {
            "Final: El Nuevo Guardián": -3,
            "Final: El Sacrificio Compartido": -4
        },
        "background": "liberation",
        "music": "climax"
    },
    19: {
        "title": "Usurpación",
        "description": "Atacas al Progenitor, usando tus garras para absorber su esencia.\n\nLa batalla mental es tan intensa como la física. El Progenitor lucha, pero finalmente cede ante tu determinación.\n\nSu poder fluye hacia ti, junto con siglos de conocimiento y la responsabilidad del sello del Abismo.",
        "choices": {
            "Final: El Nuevo Monarca": -5,
            "Final: El Reformador": -6
        },
        "background": "usurpation",
        "music": "climax"
    },
    20: {
        "title": "La Herida del Mundo",
        "description": "Exploras la catedral y descubres pasajes secretos que llevan a una cámara aún más profunda.\n\nEncuentras la verdadera Herida del Mundo: un portal pulsante que conecta con el Abismo.\n\nTu sangre resuena con su energía. Comprendes que podrías sellarlo permanentemente, pero el precio sería tu propia existencia.",
        "choices": {
            "Sacrificarte para sellar el portal para siempre": -7,
            "Buscar al Progenitor para encontrar otra solución": 15
        },
        "background": "portal",
        "music": "climax"
    },
    21: {
        "title": "Cazador de Almas",
        "description": "Te conviertes en un cazador de aquellos que persiguen a los como tú. Cada alma que consumes incrementa tu poder.\n\nTu fama se extiende y te conocen como \"El Depredador del Abismo\".\n\nPero con cada alma, las voces del Abismo son más fuertes, y una hambre insaciable crece en ti.",
        "choices": {
            "Resistir el hambre y buscar la catedral": 12,
            "Ceder al hambre y convertirte en un verdadero monstruo": -8
        },
        "background": "soul_hunter",
        "music": "horror"
    },
    -3: {  # Final 1
        "title": "FINAL: El Nuevo Guardián",
        "description": "El Progenitor toma tu sacrificio pero no te deja morir.\n\n\"Tu corazón es puro a pesar de la oscuridad. Compartiremos esta carga.\"\n\nTe conviertes en su aprendiz, aprendiendo a controlar el poder del Abismo sin sucumbir a él. Juntos, fortalecéis el sello y protegéis al mundo desde las sombras.",
        "choices": {
            "Volver al menú principal": 0,
            "Salir": -2
        },
        "background": "ending1",
        "music": "ending"
    },
    -4: {  # Final 2
        "title": "FINAL: El Sacrificio Compartido",
        "description": "Tu sangre libera al Progenitor, pero ambos quedáis unidos por un vínculo eterno.\n\nJuntos, reforzáis el sello del Abismo, un sacrificio perpetuo que debe mantenerse.\n\nA través de los siglos, te conviertes en leyenda: el Heredero que eligió el sacrificio por encima del poder, manteniendo a raya la oscuridad.",
        "choices": {
            "Volver al menú principal": 0,
            "Salir": -2
        },
        "background": "ending2",
        "music": "ending"
    },
    -5: {  # Final 3
        "title": "FINAL: El Nuevo Monarca",
        "description": "Absorbes por completo el poder del Progenitor y te sientas en el trono de hueso.\n\nDesde tu catedral, gobiernas sobre un nuevo culto que te venera como dios.\n\nMantienes el sello del Abismo, pero a cambio exiges sacrificios y lealtad. El mundo aprende a temerte y respetarte como el Monarca del Abismo.",
        "choices": {
            "Volver al menú principal": 0,
            "Salir": -2
        },
        "background": "ending3",
        "music": "ending"
    },
    -6: {  # Final 4
        "title": "FINAL: El Reformador",
        "description": "Con el poder del Progenitor, rehaces el pacto con el Abismo en tus propios términos.\n\nTransformas la Catedral en un santuario donde otros como tú pueden aprender a controlar sus dones.\n\nCreas una orden de Guardianes del Sello, protectores con poderes del Abismo que usan su oscuridad para servir a la luz.",
        "choices": {
            "Volver al menú principal": 0,
            "Salir": -2
        },
        "background": "ending4",
        "music": "ending"
    },
    -7: {  # Final 5
        "title": "FINAL: El Héroe Olvidado",
        "description": "Te ofreces en sacrificio, fusionando tu ser con el portal mismo.\n\nTu sangre, tu cuerpo y tu alma se convierten en un sello viviente que cierra la Herida del Mundo para siempre.\n\nNadie conocerá jamás tu sacrificio, pero el mundo vivirá sin la amenaza del Abismo gracias a ti. En el lugar donde estaba el portal, crece una extraña flor negra con centro rojo que nunca se marchita.",
        "choices": {
            "Volver al menú principal": 0,
            "Salir": -2
        },
        "background": "ending5",
        "music": "ending"
    },
    -8: {  # Final 6
        "title": "FINAL: El Nacimiento del Abismo",
        "description": "Sucumbes por completo al hambre. Tu humanidad se desvanece mientras te conviertes en un verdadero ser del Abismo.\n\nTu poder crece hasta niveles inimaginables, pero ya no eres tú mismo.\n\nEl mundo tiembla ante tu presencia, mientras te conviertes en la nueva encarnación del horror que el Progenitor intentó contener. El ciclo se repite, pero esta vez, no hay heredero que pueda detenerte.",
        "choices": {
            "Volver al menú principal": 0,
            "Salir": -2
        },
        "background": "ending6",
        "music": "ending"
    }
}

class Button:
    def __init__(self, x, y, w, h, text, action=None, color=BLUE, hover_color=DARK_BLUE):
        self.rect = pygame.Rect(x, y, w, h)
        self.text = text
        self.action = action
        self.color = color
        self.hover_color = hover_color
        self.current_color = color
        self.alpha = 255  # Para efectos de fundido
        
    def draw(self, surface):
        # Dibujar el botón con transparencia
        s = pygame.Surface((self.rect.width, self.rect.height))
        s.set_alpha(self.alpha)
        s.fill(self.current_color)
        surface.blit(s, (self.rect.x, self.rect.y))
        
        # Dibujar borde
        pygame.draw.rect(surface, WHITE, self.rect, 2)
        
        # Dibujar texto
        text_surf = FONT.render(self.text, True, WHITE)
        text_rect = text_surf.get_rect(center=self.rect.center)
        surface.blit(text_surf, text_rect)

    def update(self, mouse_pos):
        if self.rect.collidepoint(mouse_pos):
            self.current_color = self.hover_color
            return True
        else:
            self.current_color = self.color
            return False
    
    def is_clicked(self, pos):
        return self.rect.collidepoint(pos)

class Particle:
    def __init__(self, x, y, color=WHITE):
        self.x = x
        self.y = y
        self.color = color
        self.size = random.randint(1, 3)
        self.vel_x = random.uniform(-1, 1)
        self.vel_y = random.uniform(-1, 1)
        self.lifetime = random.randint(30, 90)
        
    def update(self):
        self.x += self.vel_x
        self.y += self.vel_y
        self.lifetime -= 1
        return self.lifetime <= 0
        
    def draw(self, surface):
        pygame.draw.circle(surface, self.color, (int(self.x), int(self.y)), self.size)

class BackgroundEffect:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.points = []
        self.create_points()
        
    def create_points(self):
        for _ in range(100):
            self.points.append([
                random.randint(0, self.width),
                random.randint(0, self.height),
                random.uniform(0.5, 3)  # Tamaño
            ])
            
    def update(self):
        for point in self.points:
            # Mover el punto lentamente
            point[0] += math.sin(pygame.time.get_ticks() * 0.0001 + point[1] * 0.001) * 0.3
            point[1] += math.cos(pygame.time.get_ticks() * 0.0001 + point[0] * 0.001) * 0.3
            
            # Envolver alrededor de la pantalla
            if point[0] < 0: point[0] = self.width
            if point[0] > self.width: point[0] = 0
            if point[1] < 0: point[1] = self.height
            if point[1] > self.height: point[1] = 0
            
    def draw(self, surface):
        for point in self.points:
            alpha = 100 + math.sin(pygame.time.get_ticks() * 0.001 + point[0] * 0.01) * 50
            color = (255, 255, 255, int(alpha))
            s = pygame.Surface((point[2] * 2, point[2] * 2))
            s.set_alpha(int(alpha))
            s.fill(WHITE)
            surface.blit(s, (int(point[0] - point[2]), int(point[1] - point[2])))

def draw_text_multiline(surface, text, x, y, font, color=WHITE, max_width=760, shadow=False):
    lines = []
    paragraphs = text.split('\n')
    
    for paragraph in paragraphs:
        words = paragraph.split(' ')
        current_line = ''
        
        for word in words:
            test_line = current_line + word + ' '
            if font.size(test_line)[0] <= max_width:
                current_line = test_line
            else:
                lines.append(current_line)
                current_line = word + ' '
        
        if current_line:
            lines.append(current_line)
        lines.append('')  # Espacio entre párrafos
        
    # Eliminar el último espacio vacío si existe
    if lines and lines[-1] == '':
        lines = lines[:-1]
        
    for i, line in enumerate(lines):
        if shadow:
            shadow_surf = font.render(line, True, BLACK)
            surface.blit(shadow_surf, (x + 2, y + i * font.get_height() + 2))
        line_surf = font.render(line, True, color)
        surface.blit(line_surf, (x, y + i * font.get_height()))
        
    return y + len(lines) * font.get_height()

def create_particles(x, y, count=10, color=WHITE):
    for _ in range(count):
        particles.append(Particle(x, y, color))

def update_particles():
    to_remove = []
    for i, particle in enumerate(particles):
        if particle.update():
            to_remove.append(i)
    
    for i in sorted(to_remove, reverse=True):
        if i < len(particles):
            particles.pop(i)

def draw_particles(surface):
    for particle in particles:
        particle.draw(surface)

def transition_to(next_map):
    """Transición suave entre escenas"""
    fade_surf = pygame.Surface((WIDTH, HEIGHT))
    fade_surf.fill(BLACK)
    
    for alpha in range(0, 256, 8):
        SCREEN.fill(BLACK)
        # Dibujamos la escena actual
        
        fade_surf.set_alpha(alpha)
        SCREEN.blit(fade_surf, (0, 0))
        pygame.display.flip()
        pygame.time.delay(20)
    
    current_map = next_map
    
    for alpha in range(255, -1, -8):
        SCREEN.fill(BLACK)
        # Dibujamos la nueva escena
        
        fade_surf.set_alpha(alpha)
        SCREEN.blit(fade_surf, (0, 0))
        pygame.display.flip()
        pygame.time.delay(20)
        
    return current_map

def simulate_background(background_name):
    """Carga una imagen de fondo según el nombre especificado"""
    try:
        image = pygame.image.load(f"assets/backgrounds/{background_name}.png").convert()
        image = pygame.transform.scale(image, (WIDTH, HEIGHT))
        return image
    except:
        # Si no se encuentra la imagen, se devuelve un fondo negro
        fallback = pygame.Surface((WIDTH, HEIGHT))
        fallback.fill((0, 0, 0))
        return fallback


def draw_background_effects(surface, map_id):
    """Dibuja efectos adicionales según el escenario"""
    if map_id == 0:
        if random.random() < 0.1:
            create_particles(random.randint(0, WIDTH), random.randint(HEIGHT - 100, HEIGHT), 5, (100, 0, 150))
    elif map_id == 5:
        if random.random() < 0.05:
            create_particles(random.randint(0, WIDTH), 0, 3, (200, 0, 0))
    elif map_id == 12:
        if random.random() < 0.03:
            create_particles(random.randint(0, WIDTH), random.randint(0, HEIGHT), 7, (150, 150, 255))
    elif map_id == 20:
        if random.random() < 0.1:
            create_particles(WIDTH // 2, HEIGHT // 2, 15, (255, 0, 100))
    elif map_id < 0:
        if random.random() < 0.07:
            create_particles(random.randint(0, WIDTH), random.randint(0, HEIGHT), 3, (200, 200, 0))

def save_game(current_map):
    """Guarda la partida"""
    try:
        with open("save_game.txt", "w") as f:
            f.write(str(current_map))
        return True
    except IOError:
        return False

def load_game():
    """Carga la partida guardada"""
    try:
        with open("save_game.txt", "r") as f:
            return int(f.read().strip())
    except (IOError, ValueError):
        return 0  # Si no hay partida guardada o hay error, comienza desde el principio

def show_message(surface, message, duration=2000):
    """Muestra un mensaje temporal en la pantalla"""
    msg_surf = FONT.render(message, True, WHITE)
    msg_rect = msg_surf.get_rect(center=(WIDTH // 2, HEIGHT - 50))
    
    bg = pygame.Surface((msg_surf.get_width() + 20, msg_surf.get_height() + 10))
    bg.fill(BLACK)
    bg.set_alpha(150)
    bg_rect = bg.get_rect(center=msg_rect.center)

    surface.blit(bg, bg_rect)
    surface.blit(msg_surf, msg_rect)
    pygame.display.flip()
    pygame.time.wait(duration)

def show_intro_animation():
    """Muestra una animación introductoria"""
    title_text = "Heredero del Abismo"
    subtitle_text = "Un viaje hacia la oscuridad"
    
    bg = pygame.Surface((WIDTH, HEIGHT))
    bg.fill(BLACK)

    # Fundido de entrada del título
    for alpha in range(0, 256, 2):
        SCREEN.fill(BLACK)
        title_surf = TITLE_FONT.render(title_text, True, WHITE)
        title_surf.set_alpha(alpha)
        title_rect = title_surf.get_rect(center=(WIDTH // 2, HEIGHT // 2 - 50))

        SCREEN.blit(title_surf, title_rect)
        pygame.display.flip()
        pygame.time.delay(20)

    pygame.time.delay(500)

    # Fundido de entrada del subtítulo
    for alpha in range(0, 256, 2):
        subtitle_surf = FONT.render(subtitle_text, True, WHITE)
        subtitle_surf.set_alpha(alpha)
        subtitle_rect = subtitle_surf.get_rect(center=(WIDTH // 2, HEIGHT // 2 + 20))

        SCREEN.fill(BLACK)
        SCREEN.blit(title_surf, title_rect)
        SCREEN.blit(subtitle_surf, subtitle_rect)
        pygame.display.flip()
        pygame.time.delay(20)

    pygame.time.delay(1500)

    # Fundido de salida
    for alpha in range(255, -1, -5):
        fade_surf = pygame.Surface((WIDTH, HEIGHT))
        fade_surf.fill(BLACK)
        fade_surf.set_alpha(255 - alpha)

        SCREEN.fill(BLACK)
        SCREEN.blit(title_surf, title_rect)
        SCREEN.blit(subtitle_surf, subtitle_rect)
        SCREEN.blit(fade_surf, (0, 0))
        pygame.display.flip()
        pygame.time.delay(20)

def main():
    current_map = 0  # Comenzamos en la pantalla de título
    buttons = []
    running = True
    bg_effect = BackgroundEffect(WIDTH, HEIGHT)
    
    # Intentar cargar música de fondo
    try:
        if ambient_sound:
            ambient_sound.play(-1)  # Reproducir en loop
    except:
        pass
        
    # Mostrar animación introductoria
    show_intro_animation()
    
    while running:
        # Crear fondo
        bg_surface = simulate_background(maps[current_map].get("background", "default"))
        SCREEN.blit(bg_surface, (0, 0))
        
        # Actualizar efectos de fondo
        bg_effect.update()
        bg_effect.draw(SCREEN)
        
        # Dibujar efectos específicos del escenario
        draw_background_effects(SCREEN, current_map)
        
        # Actualizar y dibujar partículas
        update_particles()
        draw_particles(SCREEN)
        
        map_data = maps[current_map]
        
        # Mostrar título con sombra
        title_surf = BIG_FONT.render(map_data["title"], True, WHITE)
        shadow_surf = BIG_FONT.render(map_data["title"], True, BLACK)
        SCREEN.blit(shadow_surf, (22, 22))
        SCREEN.blit(title_surf, (20, 20))
        
        # Mostrar descripción con formato mejorado
        next_y = draw_text_multiline(SCREEN, map_data["description"], 40, 80, FONT, shadow=True)
        
        # Crear botones para opciones
        buttons.clear()
        btn_start_y = next_y + 30
        btn_w, btn_h = 560, 50
        gap = 20
        btn_color_map = {
            "Aceptar": (0, 150, 0),     # Verde
            "Rechazar": (150, 0, 0),    # Rojo
            "Defenderte": (200, 80, 0), # Naranja
            "Huir": (0, 100, 150),      # Azul
            "Final": PURPLE,            # Púrpura para finales
            "Volver": BLUE,             # Azul estándar
            "Salir": RED                # Rojo para salir
        }
        
        for i, choice_text in enumerate(map_data["choices"].keys()):
            # Asignar colores basados en palabras clave en el texto
            btn_color = BLUE
            hover_color = DARK_BLUE
            
            # Buscar palabras clave para asignar colores temáticos
            for key, color in btn_color_map.items():
                if key in choice_text:
                    btn_color = color
                    # Versión más oscura para hover
                    hover_color = tuple(max(0, c - 40) for c in color)
                    break
            
            btn = Button(
                120, 
                btn_start_y + i * (btn_h + gap), 
                btn_w, 
                btn_h, 
                choice_text,
                color=btn_color,
                hover_color=hover_color
            )
            buttons.append(btn)
        
        # Botones adicionales para menú
        if current_map == 0:  # Si estamos en la pantalla de título
            # Botón para cargar partida
            load_btn = Button(WIDTH - 150, HEIGHT - 70, 130, 40, "Cargar partida", color=GRAY)
            buttons.append(load_btn)
        else:  # Si estamos en el juego
            # Botón para guardar partida
            save_btn = Button(WIDTH - 150, HEIGHT - 70, 130, 40, "Guardar", color=GRAY)
            buttons.append(save_btn)
        
        # Dibujar botones con efectos hover
        mouse_pos = pygame.mouse.get_pos()
        for btn in buttons:
            if btn.update(mouse_pos) and random.random() < 0.1:
                # Crear partículas cuando el ratón está sobre el botón
                create_particles(
                    btn.rect.centerx + random.randint(-btn.rect.width//2, btn.rect.width//2),
                    btn.rect.centery + random.randint(-btn.rect.height//2, btn.rect.height//2),
                    1
                )
            btn.draw(SCREEN)
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                
            elif event.type == pygame.KEYDOWN:
                # Atajos de teclado
                if event.key == pygame.K_ESCAPE:
                    if current_map != 0:  # Si no estamos en el menú principal
                        transition_to(0)  # Volver al menú
                    else:
                        running = False  # Salir del juego
                
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                for i, btn in enumerate(buttons):
                    if btn.is_clicked(event.pos):
                        # Reproducir sonido de clic
                        try:
                            if click_sound:
                                click_sound.play()
                        except:
                            pass
                        
                        # Crear efecto de partículas en el clic
                        create_particles(event.pos[0], event.pos[1], 20)
                        
                        # Manejar los botones de guardar/cargar
                        if btn.text == "Guardar":
                            if save_game(current_map):
                                show_message(SCREEN, "Partida guardada")
                            else:
                                show_message(SCREEN, "Error al guardar")
                            continue
                        elif btn.text == "Cargar partida":
                            loaded_map = load_game()
                            current_map = transition_to(loaded_map)
                            show_message(SCREEN, "Partida cargada")
                            continue
                        
                        # Para botones normales de navegación
                        if i < len(map_data["choices"]):
                            choice = list(map_data["choices"].keys())[i]
                            next_map = map_data["choices"][choice]
                            
                            if next_map == -2:  # Código especial para salir
                                running = False
                            else:
                                current_map = transition_to(next_map)
        
        pygame.display.flip()
        clock.tick(60)
    
    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()                     
