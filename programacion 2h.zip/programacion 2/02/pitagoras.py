

class TeoremaDePitagoras:
    def __init__(self, cateto1, cateto2):
        self.__cateto1 = cateto1
        self.__cateto2 = cateto2

    # Getter para cateto1
    def obtener_cateto1(self):
        return self.__cateto1

    # Getter para cateto2
    def obtener_cateto2(self):
        return self.__cateto2

    # Setter para cateto1
    def establecer_cateto1(self, nuevo_cateto1):
        if nuevo_cateto1 > 0:
            self.__cateto1 = nuevo_cateto1
        else:
            print("Cateto no válido")

    # Setter para cateto2
    def establecer_cateto2(self, nuevo_cateto2):
        if nuevo_cateto2 > 0:
            self.__cateto2 = nuevo_cateto2
        else:
            print("Cateto no válido")


    def calcular_hipotenusa(self):
        return (self.__cateto1**2 + self.__cateto2**2)**(1/2)

  


   
    def mostrar_datos(self):
        print(f"Cateto 1: {self.__cateto1}, Cateto 2: {self.__cateto2}")
        print(f"Hipotenusa: {self.calcular_hipotenusa()}")


triangulo = TeoremaDePitagoras(3, 4)
triangulo.mostrar_datos()




triangulo.establecer_cateto1(5)
triangulo.establecer_cateto2(12)
triangulo.mostrar_datos()
