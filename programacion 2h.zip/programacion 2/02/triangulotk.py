import tkinter as tk
from tkinter import ttk

class Triangulo:
    def __init__(self, base, altura, lado1, lado2):
        self.base = base
        self.altura = altura
        self.lado1 = lado1
        self.lado2 = lado2
        self.area = (self.base * self.altura) / 2
        self.perimetro = self.base + self.lado1 + self.lado2

    def obtener_area(self):
        return self.area

    def obtener_perimetro(self):
        return self.perimetro

def calcular():
    try:
        base = float(entry_base.get())
        altura = float(entry_altura.get())
        lado1 = float(entry_lado1.get())
        lado2 = float(entry_lado2.get())

        tri = Triangulo(base, altura, lado1, lado2)

        resultado = f"Área: {tri.obtener_area():.2f} | Perímetro: {tri.obtener_perimetro():.2f}"
        resultado_var.set(resultado)
        historial.insert(tk.END, f"B:{base}, H:{altura}, L1:{lado1}, L2:{lado2} → {resultado}")

    except ValueError:
        resultado_var.set("⚠️ Ingrese valores numéricos válidos.")

def limpiar():
    entry_base.delete(0, tk.END)
    entry_altura.delete(0, tk.END)
    entry_lado1.delete(0, tk.END)
    entry_lado2.delete(0, tk.END)
    resultado_var.set("")

# Configurar ventana
ventana = tk.Tk()
ventana.title("Calculadora de Triángulos")
ventana.geometry("860x300")
ventana.configure(bg="#f7f9fc")

# Estilos visuales
style = ttk.Style()
style.theme_use("clam")
style.configure("TLabel", background="#f7f9fc", font=("Segoe UI", 11))
style.configure("TEntry", font=("Segoe UI", 11))
style.configure("TButton", font=("Segoe UI", 11, "bold"), padding=6)

# Frame horizontal principal
frame_principal = tk.Frame(ventana, bg="#f7f9fc")
frame_principal.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

# Panel de entrada
panel_izq = tk.Frame(frame_principal, bg="#d6eaf8", bd=2, relief="groove")
panel_izq.pack(side=tk.LEFT, fill=tk.Y, padx=10, pady=5)

tk.Label(panel_izq, text="🔷 Datos del Triángulo", bg="#d6eaf8", font=("Segoe UI", 12, "bold")).pack(pady=10)

def campo_input(frame, texto):
    lbl = tk.Label(frame, text=texto + ":", bg="#d6eaf8")
    lbl.pack()
    entrada = ttk.Entry(frame, width=20)
    entrada.pack(pady=3)
    return entrada

entry_base = campo_input(panel_izq, "Base")
entry_altura = campo_input(panel_izq, "Altura")
entry_lado1 = campo_input(panel_izq, "Lado 1")
entry_lado2 = campo_input(panel_izq, "Lado 2")

# Botones
frame_botones = tk.Frame(panel_izq, bg="#d6eaf8")
frame_botones.pack(pady=10)
ttk.Button(frame_botones, text="Calcular", command=calcular).pack(side=tk.LEFT, padx=5)
ttk.Button(frame_botones, text="Limpiar", command=limpiar).pack(side=tk.LEFT, padx=5)

# Panel derecho de resultados
panel_der = tk.Frame(frame_principal, bg="#e8f8f5", bd=2, relief="groove")
panel_der.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=10, pady=5)

tk.Label(panel_der, text="📊 Resultados", bg="#e8f8f5", font=("Segoe UI", 12, "bold")).pack(pady=10)

resultado_var = tk.StringVar()
label_resultado = tk.Label(panel_der, textvariable=resultado_var, bg="#e8f8f5", fg="#1a5276", font=("Segoe UI", 12, "bold"))
label_resultado.pack(pady=10)

tk.Label(panel_der, text="📋 Historial de Cálculos", bg="#e8f8f5", font=("Segoe UI", 11, "bold")).pack(pady=(15, 5))
historial = tk.Listbox(panel_der, font=("Consolas", 10), height=6)
historial.pack(padx=10, pady=5, fill=tk.BOTH, expand=True)

ventana.mainloop()
