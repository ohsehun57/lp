class persona:
    def __init__(self,nombre):
        self.nombre =nombre

p1 = persona("maria")
p2=p1
p2.nombre="carla"

print(p1.nombre)