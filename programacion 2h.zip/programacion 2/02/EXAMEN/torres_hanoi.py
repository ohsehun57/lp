import tkinter as tk
from tkinter import ttk
import time
import threading
from abc import ABC, abstractmethod
from typing import List, Tuple, Protocol


# =============================================================================
# PRINCIPIOS I y D: Interfaces y Abstracciones
# =============================================================================

class GameObserver(Protocol):
    """Protocolo para observadores del juego (ISP - Interface Segregation)"""
    def on_move(self, from_rod: int, to_rod: int, disk: int) -> None:
        """Notifica cuando se realiza un movimiento"""
        ...

    def on_game_complete(self, moves: int) -> None:
        """Notifica cuando el juego se completa"""
        ...


class Visualizer(ABC):
    """Abstracción base para visualizadores (DIP - Dependency Inversion)"""
    
    @abstractmethod
    def initialize(self, num_disks: int, current_rods_state: List[List[int]]) -> None:
        """Inicializa la visualización con el número de discos y el estado inicial"""
        pass
    
    @abstractmethod
    def show_move(self, from_rod: int, to_rod: int, disk: int) -> None:
        """Muestra un movimiento específico"""
        pass
    
    @abstractmethod
    def show_completion(self, moves: int) -> None:
        """Muestra el mensaje de finalización"""
        pass

    @abstractmethod
    def update_display(self) -> None:
        """Actualiza la visualización"""
        pass
    
    @abstractmethod
    def redraw_state(self, rods_state: List[List[int]], moves_count: int) -> None:
        """Redibuja el estado completo del juego"""
        pass


# =============================================================================
# PRINCIPIO S: Single Responsibility Principle
# =============================================================================

class HanoiState:
    """Responsabilidad: Mantener el estado actual del juego"""
    
    def __init__(self, num_disks: int):
        self.num_disks = num_disks
        self.rods: List[List[int]] = [[], [], []]
        self.rods[0] = list(range(num_disks, 0, -1))  # Discos en orden descendente
        self.moves_count = 0
    
    def move_disk(self, from_rod: int, to_rod: int) -> int:
        """Mueve un disco de una vara a otra y retorna el disco movido"""
        if not (0 <= from_rod < 3 and 0 <= to_rod < 3):
            raise ValueError("Las varas deben ser 0, 1 o 2.")
        
        if not self.rods[from_rod]:
            raise ValueError(f"No hay discos en la vara {from_rod}")
        
        disk = self.rods[from_rod][-1] # Peek at the top disk
        
        if self.rods[to_rod] and self.rods[to_rod][-1] < disk:
            raise ValueError(f"No se puede colocar disco {disk} sobre disco {self.rods[to_rod][-1]}")
        
        disk_to_move = self.rods[from_rod].pop()
        self.rods[to_rod].append(disk_to_move)
        self.moves_count += 1
        return disk_to_move
    
    def is_solved(self) -> bool:
        """Verifica si el juego está resuelto"""
        return len(self.rods[2]) == self.num_disks
    
    def get_state_copy(self) -> List[List[int]]:
        """Retorna una copia del estado actual"""
        return [rod.copy() for rod in self.rods]

    def reset(self, num_disks: int = None):
        """Reinicia el estado del juego"""
        if num_disks is not None:
            self.num_disks = num_disks
        self.rods = [[], [], []]
        self.rods[0] = list(range(self.num_disks, 0, -1))
        self.moves_count = 0


class HanoiSolver:
    """Responsabilidad: Resolver el algoritmo de Torres de Hanoi"""
    
    def __init__(self):
        self.moves: List[Tuple[int, int, int]] = []  # (from, to, disk)
    
    def solve(self, num_disks: int, from_rod: int = 0, to_rod: int = 2, aux_rod: int = 1) -> List[Tuple[int, int, int]]:
        """
        Resuelve las Torres de Hanoi y retorna la secuencia de movimientos
        Retorna: Lista de tuplas (from_rod, to_rod, disk_size)
        """
        self.moves = []
        self._hanoi_recursive(num_disks, from_rod, to_rod, aux_rod)
        return self.moves.copy()
    
    def _hanoi_recursive(self, n: int, from_rod: int, to_rod: int, aux_rod: int) -> None:
        """Algoritmo recursivo para resolver las Torres de Hanoi"""
        if n == 1:
            self.moves.append((from_rod, to_rod, 1))
        else:
            # Mover n-1 discos de origen a auxiliar
            self._hanoi_recursive(n - 1, from_rod, aux_rod, to_rod)
            # Mover el disco más grande al destino
            self.moves.append((from_rod, to_rod, n))
            # Mover n-1 discos de auxiliar a destino
            self._hanoi_recursive(n - 1, aux_rod, to_rod, from_rod)


class GameController:
    """Responsabilidad: Controlar el flujo del juego y coordinar componentes"""
    
    def __init__(self, num_disks: int, visualizer: Visualizer):
        self.state = HanoiState(num_disks)
        self.solver = HanoiSolver()
        self.visualizer = visualizer
        self.observers: List[GameObserver] = []
        self.is_running = False  # Indicates if an animation is in progress
        self.animation_thread = None
    
    def add_observer(self, observer: GameObserver) -> None:
        """Añade un observador al juego"""
        self.observers.append(observer)
    
    def _notify_move_observers(self, from_rod: int, to_rod: int, disk: int) -> None:
        """Notifica a todos los observadores sobre un movimiento"""
        for observer in self.observers:
            observer.on_move(from_rod, to_rod, disk)

    def _notify_completion_observers(self, moves: int) -> None:
        """Notifica a todos los observadores sobre la finalización"""
        for observer in self.observers:
            observer.on_game_complete(moves)
    
    def solve_animated(self, delay: float = 1.0) -> None:
        """Resuelve el juego con animación paso a paso"""
        if self.is_running:
            print("Advertencia: Ya hay una animación en curso.")
            return
        
        self.is_running = True
        
        # Obtener la secuencia de movimientos
        moves = self.solver.solve(self.state.num_disks)
        
        def animate_moves():
            try:
                for from_rod, to_rod, expected_disk in moves:
                    if not self.is_running: # Check if stop was requested
                        break
                    
                    try:
                        # Realizar el movimiento en el estado
                        actual_disk = self.state.move_disk(from_rod, to_rod)
                        
                        # Mostrar el movimiento (el visualizador actualizará su estado y lo dibujará)
                        self.visualizer.show_move(from_rod, to_rod, actual_disk)
                        self._notify_move_observers(from_rod, to_rod, actual_disk)
                    except ValueError as e:
                        # This should ideally not happen with the solver, but good for robustness
                        print(f"Error interno del solver al intentar mover disco {expected_disk} de {from_rod} a {to_rod}: {e}")
                        self.is_running = False
                        break
                    
                    time.sleep(delay)
                
                if self.is_running and self.state.is_solved():
                    self.visualizer.show_completion(self.state.moves_count)
                    self._notify_completion_observers(self.state.moves_count)
                
            except Exception as e:
                print(f"Error inesperado durante la animación: {e}")
            finally:
                self.is_running = False
        
        # Ejecutar en un hilo separado para no bloquear la UI
        self.animation_thread = threading.Thread(target=animate_moves)
        self.animation_thread.daemon = True # Allow the thread to exit with the main program
        self.animation_thread.start()
    
    def make_user_move(self, from_rod: int, to_rod: int) -> bool:
        """
        Intenta realizar un movimiento iniciado por el usuario.
        Retorna True si el movimiento fue exitoso, False en caso contrario.
        """
        if self.is_running: # Prevent user moves during auto-solve animation
            print("Advertencia: No puedes mover discos durante la resolución automática.")
            return False
        
        try:
            # The HanoiState class already performs the necessary validations
            moved_disk = self.state.move_disk(from_rod, to_rod)
            
            # If valid, perform the move and update visualizer
            self.visualizer.show_move(from_rod, to_rod, moved_disk)
            self._notify_move_observers(from_rod, to_rod, moved_disk)
            
            if self.state.is_solved():
                self.visualizer.show_completion(self.state.moves_count)
                self._notify_completion_observers(self.state.moves_count)
            
            return True
        except ValueError as e:
            # Print error to console
            print(f"Movimiento Inválido: {e}") 
            return False

    def stop(self) -> None:
        """Detiene la animación en curso"""
        if self.is_running:
            self.is_running = False
            if self.animation_thread and self.animation_thread.is_alive():
                # Give the thread a short time to clean up
                self.animation_thread.join(timeout=0.1) 
                print("Animación detenida.")
        else:
            print("No hay animación en curso para detener.")
    
    def reset(self, num_disks: int = None) -> None:
        """Reinicia el juego al estado inicial"""
        self.stop() # Ensure any ongoing animation is stopped gracefully
        if num_disks is not None:
            self.state = HanoiState(num_disks)
        else:
            # If num_disks is None, reset with current num_disks
            self.state.reset(self.state.num_disks) 
        # Ensure the visualizer redraws with the new initial state and 0 moves
        self.visualizer.initialize(self.state.num_disks, self.state.get_state_copy())
        print(f"Juego reiniciado con {self.state.num_disks} discos.")


# =============================================================================
# PRINCIPIOS O y L: Open/Closed y Liskov Substitution
# =============================================================================

class TkinterVisualizer(Visualizer):
    """
    Implementación concreta del visualizador usando Tkinter
    (OCP - Open/Closed: Extensible sin modificar código existente)
    (LSP - Liskov: Puede sustituir a Visualizer sin romper funcionalidad)
    """
    
    def __init__(self, controller: 'GameController' = None):
        self.root = None
        self.canvas = None
        self.controller = controller # Controller reference for user moves
        self.rods_state = [[], [], []] # Internal state for drawing (synced with controller's state)
        # Proporciones relativas al tamaño del canvas
        self.rod_x_ratio = [0.25, 0.5, 0.75] # % del ancho del canvas
        self.base_y_ratio = 0.85 # % del alto del canvas
        self.disk_height_ratio = 0.05 # % del alto del canvas
        self.rod_height_ratio = 0.6 # % del alto del canvas
        self.max_disk_width_ratio = 0.2 # % del ancho del canvas para el disco más grande
        
        self.colors = ['#E74C3C', '#2ECC71', '#3498DB', '#F1C40F', '#9B59B6', '#1ABC9C', '#E67E22', '#BDC3C7'] # Colores más vibrantes
        self.move_counter_text = None
        self.completion_text = None
        
        # For drag and drop
        self._drag_data = {"disk_id": None, "disk_num": None, "start_x": 0, "start_y": 0, "from_rod": -1}
        self.active_disk_outline = None # To highlight the disk being dragged

    def initialize(self, num_disks: int, current_rods_state: List[List[int]]) -> None:
        """Inicializa la ventana y dibuja el estado inicial"""
        self.rods_state = [rod.copy() for rod in current_rods_state] # Update internal state
        if self.canvas:
            self.redraw_state(self.rods_state, 0) # Redraw from scratch
    
    def show_move(self, from_rod: int, to_rod: int, disk: int) -> None:
        """
        Muestra un movimiento animado.
        Simply redraw the entire state, as the controller has already updated its state.
        This ensures visual consistency with the actual game state.
        """
        if not self.canvas or not self.controller:
            return
        
        self.redraw_state(self.controller.state.get_state_copy(), self.controller.state.moves_count)
        self.update_display()
    
    def show_completion(self, moves: int) -> None:
        """Muestra mensaje de finalización"""
        if self.canvas and self.root:
            if self.completion_text:
                self.canvas.delete(self.completion_text)
            
            self.completion_text = self.canvas.create_text(
                self.canvas.winfo_width() / 2, self.canvas.winfo_height() * 0.1, # Centered at top
                text=f"🎉 ¡Completado en {moves} movimientos! 🎉", 
                font=('Arial', 24, 'bold'), 
                fill='green',
                tags="completion_msg"
            )
            self.update_display()
    
    def update_display(self) -> None:
        """Actualiza la visualización"""
        if self.root:
            self.root.update_idletasks()

    def redraw_state(self, rods_state: List[List[int]], moves_count: int) -> None:
        """Dibuja toda la escena del juego basado en un estado dado"""
        if not self.canvas:
            return
        
        # Update internal state used for drag/drop logic
        self.rods_state = [rod.copy() for rod in rods_state] 

        canvas_width = self.canvas.winfo_width()
        canvas_height = self.canvas.winfo_height()
        
        rod_positions = [int(w * canvas_width) for w in self.rod_x_ratio]
        base_y = int(self.base_y_ratio * canvas_height)
        disk_height = int(self.disk_height_ratio * canvas_height)
        rod_height = int(self.rod_height_ratio * canvas_height)
        max_disk_width = int(self.max_disk_width_ratio * canvas_width)

        self.canvas.delete("all") # Clear previous drawings
        
        # Draw decorative background
        self.canvas.create_rectangle(0, 0, canvas_width, canvas_height, fill='#ADD8E6', outline='') # Light Blue
        
        # Draw main base
        self.canvas.create_rectangle(canvas_width * 0.1, base_y, canvas_width * 0.9, base_y + (disk_height // 2), 
                                     fill='#5C4033', outline='black', width=3) # Dark Brown
        
        # Draw rods
        for i, x in enumerate(rod_positions):
            # Rod
            self.canvas.create_rectangle(x - 10, base_y - rod_height, 
                                         x + 10, base_y, 
                                         fill='#A0522D', outline='black', width=3) # Sienna
            
            # Base of each rod (oval)
            self.canvas.create_oval(x - (max_disk_width * 0.4), base_y - (disk_height // 2), 
                                     x + (max_disk_width * 0.4), base_y + (disk_height),
                                     fill='#8B4513', outline='black', width=3) # SaddleBrown
            
            # Rod labels
            self.canvas.create_text(x, base_y + (disk_height * 1.5), text=f"Torre {chr(65 + i)}", 
                                     font=('Arial', 20, 'bold'), fill='#2C3E50') # Dark Grey
        
        # Draw disks
        # Get total number of disks for scaling disk widths correctly
        total_num_disks = self.controller.state.num_disks if self.controller else 3 

        for rod_idx, rod in enumerate(rods_state):
            x = rod_positions[rod_idx]
            for disk_idx, disk_size in enumerate(rod):
                y = base_y - (disk_idx + 1) * disk_height - (disk_height // 4) # Adjust y for disk height
                
                # Calculate disk width based on size ratio, ensuring it scales
                width = int(max_disk_width * (disk_size / total_num_disks))
                if width < 30: # Minimum width for smallest disk to be visible
                    width = 30 
                
                color = self.colors[(disk_size - 1) % len(self.colors)]
                
                # Disk oval for rounded appearance
                disk_id = self.canvas.create_oval(x - width // 2, y - disk_height // 2,
                                                x + width // 2, y + disk_height // 2,
                                                fill=color, outline='black', width=2,
                                                tags=f"disk_{disk_size}") # Tag for identification
                
                # Disk number
                self.canvas.create_text(x, y, text=str(disk_size), 
                                         font=('Arial', 18, 'bold'), fill='white',
                                         tags=f"disk_{disk_size}_text") # Tag for identification

        # Update move counter
        if self.move_counter_text:
            self.canvas.delete(self.move_counter_text)
        self.move_counter_text = self.canvas.create_text(
            canvas_width / 2, canvas_height * 0.05, # Position at top center
            text=f"Movimientos: {moves_count}",
            font=('Arial', 22, 'bold'), 
            fill='#C0392B', 
            tags="move_counter"
        )
        
        # Remove completion message if present
        self.canvas.delete("completion_msg")
        
        self.update_display()

    def create_window(self):
        """Crea la ventana principal"""
        self.root = tk.Tk()
        self.root.title("Torres de Hanoi - Implementación SOLID")
        # Establecemos un tamaño inicial razonable y permitimos redimensionar
        self.root.geometry("1200x800") 
        self.root.minsize(800, 600) # Establece un tamaño mínimo para la ventana
        
        # Canvas principal, se expandirá para llenar el espacio disponible
        self.canvas = tk.Canvas(self.root, bg='#ADD8E6') 
        self.canvas.pack(expand=True, fill='both', pady=10, padx=10) # Permite que el canvas se expanda

        # Bind mouse events for drag and drop
        self.canvas.bind("<ButtonPress-1>", self._on_disk_press)
        self.canvas.bind("<B1-Motion>", self._on_disk_drag)
        self.canvas.bind("<ButtonRelease-1>", self._on_disk_release)

        # Configurar evento de redimensionamiento para el canvas
        self.canvas.bind("<Configure>", self._on_canvas_resize)
        
        return self.root

    def _on_disk_press(self, event):
        if self.controller and self.controller.is_running:
            print("Advertencia: No puedes mover discos durante la resolución automática.")
            return

        # Find the disk clicked: look for any item tagged "disk_"
        # We need to find the specific disk that was clicked, not just any item
        clicked_items = self.canvas.find_closest(event.x, event.y)
        clicked_disk_id = None
        disk_num = None

        for item_id in clicked_items:
            tags = self.canvas.gettags(item_id)
            for tag in tags:
                if tag.startswith("disk_"):
                    try:
                        disk_num = int(tag.split('_')[1])
                        clicked_disk_id = item_id
                        break
                    except ValueError:
                        continue
            if clicked_disk_id:
                break
        
        if clicked_disk_id:
            # Determine which rod the disk belongs to based on current rods_state
            from_rod = -1
            for rod_idx, rod_disks in enumerate(self.rods_state):
                if rod_disks and disk_num == rod_disks[-1]: # Check if it's the top disk on any rod
                    from_rod = rod_idx
                    break
            
            if from_rod != -1:
                # Check if it's actually the top disk on ITS rod
                if self.rods_state[from_rod] and self.rods_state[from_rod][-1] == disk_num:
                    self._drag_data["disk_id"] = clicked_disk_id
                    self._drag_data["disk_num"] = disk_num
                    self._drag_data["start_x"] = event.x
                    self._drag_data["start_y"] = event.y
                    self._drag_data["from_rod"] = from_rod

                    # Move the disk and its text to the top of the stacking order (visual only)
                    self.canvas.tag_raise(clicked_disk_id)
                    text_id = self.canvas.find_withtag(f"disk_{disk_num}_text")
                    if text_id:
                        # tag_raise returns a tuple, we need the actual ID
                        self.canvas.tag_raise(text_id[0]) 

                    # Add a highlight outline
                    coords = self.canvas.coords(clicked_disk_id)
                    # Check if coords are valid (sometimes items might be deleted before event fires)
                    if coords:
                        self.active_disk_outline = self.canvas.create_oval(
                            coords[0] - 5, coords[1] - 5, coords[2] + 5, coords[3] + 5, 
                            outline='blue', width=5, tags="active_disk_outline"
                        )
                        self.canvas.tag_raise(self.active_disk_outline, clicked_disk_id)
                else:
                    print("Advertencia: Solo puedes mover el disco superior de cada torre.")
                    self._drag_data = {"disk_id": None, "disk_num": None, "start_x": 0, "start_y": 0, "from_rod": -1}
            else:
                # Should not happen if a disk was actually clicked and has a number
                print("Error interno: Disco no encontrado en ninguna torre.")
                self._drag_data = {"disk_id": None, "disk_num": None, "start_x": 0, "start_y": 0, "from_rod": -1}
        else:
            self._drag_data = {"disk_id": None, "disk_num": None, "start_x": 0, "start_y": 0, "from_rod": -1}


    def _on_disk_drag(self, event):
        if self._drag_data["disk_id"] is not None:
            delta_x = event.x - self._drag_data["start_x"]
            delta_y = event.y - self._drag_data["start_y"]
            
            self.canvas.move(self._drag_data["disk_id"], delta_x, delta_y)
            
            # Move the text along with the disk
            text_id = self.canvas.find_withtag(f"disk_{self._drag_data['disk_num']}_text")
            if text_id:
                self.canvas.move(text_id[0], delta_x, delta_y)

            # Move the outline along with the disk
            if self.active_disk_outline:
                self.canvas.move(self.active_disk_outline, delta_x, delta_y)

            self._drag_data["start_x"] = event.x
            self._drag_data["start_y"] = event.y

    def _on_disk_release(self, event):
        if self._drag_data["disk_id"] is not None and self.controller:
            from_rod = self._drag_data["from_rod"]
            
            # Determine the target rod based on X coordinate
            target_rod = -1
            
            canvas_width = self.canvas.winfo_width()
            rod_positions = [int(w * canvas_width) for w in self.rod_x_ratio]

            # Check if the release point is close to any rod's center within a certain tolerance
            # The tolerance is half the distance between two rod centers
            rod_spacing = (rod_positions[1] - rod_positions[0]) if len(rod_positions) > 1 else (canvas_width * self.rod_x_ratio[0]) 
            tolerance = rod_spacing * 0.4 # About 40% of the spacing on either side

            for i, rod_x in enumerate(rod_positions):
                if abs(event.x - rod_x) < tolerance: 
                    target_rod = i
                    break

            if target_rod != -1 and from_rod != target_rod:
                # Attempt to make the move via the controller
                success = self.controller.make_user_move(from_rod, target_rod)
                if not success:
                    # If the move was invalid, redraw to revert disk's visual position
                    self.redraw_state(self.controller.state.get_state_copy(), self.controller.state.moves_count)
            else:
                # If released on the same rod, or an invalid area, revert
                self.redraw_state(self.controller.state.get_state_copy(), self.controller.state.moves_count)

            # Clean up drag data and outline
            self._drag_data = {"disk_id": None, "disk_num": None, "start_x": 0, "start_y": 0, "from_rod": -1}
            if self.active_disk_outline:
                self.canvas.delete(self.active_disk_outline)
                self.active_disk_outline = None
            
            self.update_display() # Ensure display is updated
        else:
            # If no disk was being dragged or controller is missing, just clear drag data
            self._drag_data = {"disk_id": None, "disk_num": None, "start_x": 0, "start_y": 0, "from_rod": -1}
            if self.active_disk_outline:
                self.canvas.delete(self.active_disk_outline)
                self.active_disk_outline = None


    def _on_canvas_resize(self, event):
        """Maneja el evento de redimensionamiento del canvas."""
        # Redibujar el estado actual con las nuevas dimensiones del canvas
        if self.controller:
            self.redraw_state(self.controller.state.get_state_copy(), self.controller.state.moves_count)


class ConsoleVisualizer(Visualizer):
    """
    Implementación alternativa para consola
    (OCP - Open/Closed: Nueva implementación sin modificar código existente)
    (LSP - Liskov: Sustitución perfecta de Visualizer)
    """
    
    def __init__(self):
        self.rods_state = [[], [], []]
        self.current_moves_count = 0 
    
    def initialize(self, num_disks: int, current_rods_state: List[List[int]]) -> None:
        """Inicializa el estado para la consola"""
        self.rods_state = [rod.copy() for rod in current_rods_state]
        self.current_moves_count = 0
        print(f"\n=== Torres de Hanoi ({num_disks} discos) ===")
        self._print_state(self.current_moves_count) # Initial state, 0 moves
    
    def show_move(self, from_rod: int, to_rod: int, disk: int) -> None:
        """Muestra un movimiento en la consola y actualiza el estado interno"""
        # This method is called after the controller has logically moved the disk.
        # We need to reflect that in our internal rods_state for accurate printing.
        
        # Remove disk from source rod. It should be the top disk.
        if self.rods_state[from_rod] and self.rods_state[from_rod][-1] == disk:
            self.rods_state[from_rod].pop()
        else:
            # This case should ideally not happen if GameController and HanoiState are correct
            # but as a fallback, remove if found anywhere (less efficient, but robust)
            if disk in self.rods_state[from_rod]:
                self.rods_state[from_rod].remove(disk)

        # Add disk to destination rod and keep it sorted for proper display (largest at bottom)
        self.rods_state[to_rod].append(disk)
        self.rods_state[to_rod].sort(reverse=True) 

        self.current_moves_count += 1 
        
        print(f"\nMovimiento: Disco {disk} de Torre {chr(65 + from_rod)} a Torre {chr(65 + to_rod)}")
        self._print_state(self.current_moves_count) 
    
    def show_completion(self, moves: int) -> None:
        """Muestra mensaje de finalización en consola"""
        print(f"\n🎉 ¡Juego completado en {moves} movimientos! 🎉")
    
    def update_display(self) -> None:
        """No hace nada en consola, ya que la salida es inmediata"""
        pass
    
    def redraw_state(self, rods_state: List[List[int]], moves_count: int) -> None:
        """Redibuja el estado completo del juego en la consola"""
        self.rods_state = [rod.copy() for rod in rods_state]
        self.current_moves_count = moves_count 
        self._print_state(self.current_moves_count)
    
    def _print_state(self, moves_count: int) -> None:
        """Imprime el estado actual de las torres"""
        print(f"\nEstado actual (Movimientos: {moves_count}):")
        
        all_disks = [d for sublist in self.rods_state for d in sublist]
        max_disk_val = max(all_disks) if all_disks else 0
        
        # Determine the maximum height (number of disks) for consistent printing
        # This should ideally come from the num_disks property of the game state
        max_height = self.controller.state.num_disks if hasattr(self, 'controller') and self.controller else 8 # Fallback
        
        # Calculate max_disk_repr_width for centering, ensure it's at least 1 for disk 1
        max_disk_repr_width = (max_disk_val * 2 + 1) if max_disk_val > 0 else 3 # Width for largest disk '###'

        # Print from top down (empty slots first)
        for h in range(max_height - 1, -1, -1): 
            line = ""
            for i in range(3): # For each rod
                # Check if there's a disk at this height (from bottom)
                if len(self.rods_state[i]) > h:
                    disk = self.rods_state[i][max_height - 1 - h] # Access from top of logical stack (end of list)
                    disk_str = '=' * (disk * 2 + 1) # Use '=' for disks for better visual
                else:
                    disk_str = "|" # Represents empty space on the rod
                
                # Center the disk/rod representation
                line += f"{disk_str.center(max_disk_repr_width + 4)} " 
            print(line.rstrip()) 

        # Print the bases
        base_line = ""
        for i in range(3):
            base_line += f"{'=' * (max_disk_repr_width + 4)} "
        print(base_line.rstrip())

        # Print rod labels
        label_line = ""
        for i in range(3):
            label_line += f"Torre {chr(65 + i)}".center(max_disk_repr_width + 4) + " "
        print(label_line.rstrip())
        print("-" * 40)


# =============================================================================
# CLASE PRINCIPAL Y DEMO
# =============================================================================

class HanoiApp(GameObserver):
    """
    Aplicación principal que demuestra todos los principios SOLID
    También implementa GameObserver para mostrar el patrón Observer
    """
    
    def __init__(self, num_disks: int = 3, interactive_gui: bool = True):
        self.num_disks = num_disks
        self.interactive_gui = interactive_gui
        
        # DIP: Dependemos de la abstracción Visualizer, no de implementaciones concretas
        if interactive_gui:
            self.visualizer = TkinterVisualizer()
        else:
            self.visualizer = ConsoleVisualizer()
        
        self.controller = GameController(num_disks, self.visualizer)
        # Pass the controller to the visualizer for access to state and make_user_move
        self.visualizer.controller = self.controller 

        self.controller.add_observer(self)  # Añadirse como observador
        
        if interactive_gui:
            self.setup_gui()
    
    def setup_gui(self) -> None:
        """Configura la interfaz gráfica completa"""
        if not isinstance(self.visualizer, TkinterVisualizer):
            return
        
        # Crear ventana principal
        root = self.visualizer.create_window()
        self.root = root # Store root for callbacks
        
        # Inicializar visualización con el estado actual del controlador
        self.visualizer.initialize(self.num_disks, self.controller.state.get_state_copy())
        
        # Panel de control
        control_frame = ttk.Frame(root)
        control_frame.pack(fill='x', padx=20, pady=10)
        
        # Botones principales
        button_frame = ttk.Frame(control_frame)
        button_frame.pack(fill='x', pady=5)
        
        ttk.Button(button_frame, text="🚀 Resolver (Auto)", 
                   command=lambda: self.controller.solve_animated(0.3)).pack(side='left', padx=5)
        
        ttk.Button(button_frame, text="⏹ Parar", 
                   command=self.controller.stop).pack(side='left', padx=5)
        
        ttk.Button(button_frame, text="🔄 Reiniciar", 
                   command=self.reset_game).pack(side='left', padx=5)

        # Botón de Salir
        ttk.Button(button_frame, text="❌ Salir", 
                   command=self.exit_app).pack(side='right', padx=5)
        
        # Configuración de discos
        config_frame = ttk.Frame(control_frame)
        config_frame.pack(fill='x', pady=5)
        
        ttk.Label(config_frame, text="Número de discos:").pack(side='left', padx=5)
        
        self.disk_var = tk.StringVar(value=str(self.num_disks))
        disk_combo = ttk.Combobox(config_frame, textvariable=self.disk_var, 
                                 values=['3', '4', '5', '6', '7', '8'], width=8, state="readonly") # Make it readonly
        disk_combo.pack(side='left', padx=5)
        
        ttk.Button(config_frame, text="✅ Aplicar", 
                   command=self.change_disks).pack(side='left', padx=5)
        
        # Información
        info_frame = ttk.Frame(control_frame)
        info_frame.pack(fill='x', pady=5)
        
        info_text = "Objetivo: Mover todos los discos de Torre A a Torre C siguiendo las reglas\n" \
                    "Reglas: Solo un disco a la vez; disco más grande no puede ir sobre disco más pequeño.\n" \
                    "Modo Interactivo: ¡Arrastra y suelta los discos para jugar!"
        ttk.Label(info_frame, text=info_text, font=('Arial', 10)).pack()
        
    def change_disks(self) -> None:
        """Cambia el número de discos"""
        try:
            new_num = int(self.disk_var.get())
            if 3 <= new_num <= 8:
                if new_num != self.num_disks: # Only reset if disk number actually changed
                    self.num_disks = new_num
                    self.controller.reset(new_num)
                    # The reset method calls initialize, which calls redraw_state
            else:
                print("Advertencia: El número de discos debe estar entre 3 y 8")
        except ValueError:
            print("Error: Por favor ingresa un número válido")
    
    def reset_game(self) -> None:
        """Reinicia el juego"""
        self.controller.reset()
    
    def exit_app(self) -> None:
        """Cierra la aplicación de forma segura"""
        self.controller.stop() # Detener cualquier animación en curso
        if self.root:
            self.root.destroy()
    
    # Implementación de GameObserver
    def on_move(self, from_rod: int, to_rod: int, disk: int) -> None:
        """Callback cuando se realiza un movimiento"""
        if self.interactive_gui and hasattr(self, 'root') and self.root.winfo_exists():
            self.root.title(f"Torres de Hanoi - Movimiento: Disco {disk} de {chr(65 + from_rod)} a {chr(65 + to_rod)} | Movimientos: {self.controller.state.moves_count}")
        # Console visualizer handles its own printing
    
    def on_game_complete(self, moves: int) -> None:
        """Callback cuando el juego se completa"""
        print(f"¡Felicitaciones! Juego completado en {moves} movimientos. Movimientos mínimos teóricos: {2**self.num_disks - 1}")
    
    def run(self) -> None:
        """Ejecuta la aplicación"""
        if self.interactive_gui and hasattr(self, 'root'):
            # This handles the closing via the X button as well
            self.root.protocol("WM_DELETE_WINDOW", self.exit_app) 
            self.root.mainloop()
        else:
            # For console, execute automatically
            print("Ejecutando resolución automática...")
            self.controller.solve_animated(0.5) 
            # Keep the main thread alive for the console animation to finish
            if self.controller.animation_thread:
                self.controller.animation_thread.join()
            input("\nPresiona Enter para finalizar la simulación de consola...")


# =============================================================================
# DEMOSTRACIÓN Y PUNTO DE ENTRADA
# =============================================================================

def demo_solid_principles():
    """Demuestra cómo se aplican los principios SOLID"""
    print("=" * 60)
    print("DEMOSTRACIÓN DE PRINCIPIOS SOLID EN TORRES DE HANOI")
    print("=" * 60)
    
    print("\n🔹 **S - Single Responsibility Principle (SRP):**")
    print("   • **HanoiState**: Solo maneja el estado del juego (discos en varas, conteo de movimientos).")
    print("   • **HanoiSolver**: Solo resuelve el algoritmo de Hanoi, generando la secuencia de movimientos óptima.")
    print("   • **GameController**: Coordina la lógica del juego, maneja movimientos (manuales o automáticos) y notifica a observadores.")
    print("   • **TkinterVisualizer/ConsoleVisualizer**: Solo manejan la representación visual del juego, cada uno en su respectivo medio.")
    
    print("\n🔹 **O - Open/Closed Principle (OCP):")
    print("   • El sistema es abierto para **extensión** de nuevos visualizadores (ej., PygameVisualizer, WebVisualizer).")
    print("   • Es cerrado para **modificación** del código base del `GameController` o `HanoiState` al añadir nuevos visualizadores.")
    print("   • `TkinterVisualizer` y `ConsoleVisualizer` son ejemplos de cómo se pueden añadir nuevas implementaciones de `Visualizer` sin alterar las clases centrales.")
    
    print("\n🔹 **L - Liskov Substitution Principle (LSP):**")
    print("   • Cualquier subclase de `Visualizer` (`TkinterVisualizer` o `ConsoleVisualizer`) puede sustituir a su tipo base (`Visualizer`) en el `GameController` sin alterar la corrección del programa.")
    print("   • El `GameController` interactúa con el `Visualizer` a través de su interfaz abstracta, garantizando que el comportamiento esperado (inicializar, mostrar movimiento, mostrar finalización) se mantenga, independientemente de la implementación concreta.")
    
    print("\n🔹 **I - Interface Segregation Principle (ISP):**")
    print("   • **GameObserver**: es un protocolo que define una interfaz mínima y específica para objetos interesados en eventos del juego (movimientos, finalización).")
    print("   • **Visualizer**: es otra abstracción que define solo los métodos estrictamente necesarios para la visualización.")
    ("   • Esto evita que las clases implementen métodos que no necesitan, lo que lleva a interfaces más cohesivas y evita dependencias innecesarias.")
    
    print("\n🔹 **D - Dependency Inversion Principle (DIP):**")
    print("   • **GameController** (módulo de alto nivel) depende de abstracciones (`Visualizer`, `GameObserver`), no de implementaciones concretas (`TkinterVisualizer`, `ConsoleVisualizer`).")
    print("   • Las implementaciones concretas se inyectan en el `GameController` (ej., a través del constructor), invirtiendo la dependencia tradicional.")
    
    print("\n" + "=" * 60)
    print("INSTRUCCIONES DE EJECUCIÓN:")
    print("  1. Para iniciar el juego interactivo con **interfaz gráfica (GUI)**:")
    print("     Asegúrate de que la línea `app = HanoiApp(num_disks=4, interactive_gui=True)` esté descomentada.")
    print("     Podrás arrastrar y soltar discos con el ratón. Los mensajes de estado y error aparecerán en esta consola.")
    print("  2. Para iniciar la **simulación automática en la consola** (sin GUI):")
    print("     Asegúrate de que la línea `app = HanoiApp(num_disks=3, interactive_gui=False)` esté descomentada.")
    print("     Observarás los pasos de la resolución del algoritmo directamente aquí en la consola.")
    print("\n" + "=" * 60)

if __name__ == "__main__":
    demo_solid_principles()
    
    # --- Descomenta UNA de las siguientes líneas para ejecutar ---
    
    # Versión con interfaz gráfica (Tkinter) - ¡Jugable!
    app = HanoiApp(num_disks=4, interactive_gui=True)
    app.run()
    
    # Versión de consola (sin GUI) - Simulación automática
    # app = HanoiApp(num_disks=3, interactive_gui=False)
    # app.run()