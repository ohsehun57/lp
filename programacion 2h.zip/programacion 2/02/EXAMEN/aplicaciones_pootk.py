import tkinter as tk
from tkinter import ttk, messagebox
import math

# Clases base
class Figura:
    def __init__(self, nombre):
        self.__nombre = nombre

    def get_nombre(self):
        return self.__nombre

    def calcular_area(self):
        pass

    def calcular_perimetro(self):
        pass

    def mostrar_info(self):
        return f"Figura: {self.__nombre}\nÁrea: {self.calcular_area():.2f}\nPerímetro: {self.calcular_perimetro()}"

class Circulo(Figura):
    def __init__(self, radio):
        super().__init__("Círculo")
        self.__radio = radio

    def calcular_area(self):
        return math.pi * self.__radio ** 2

    def calcular_perimetro(self):
        return round(2 * math.pi * self.__radio, 2)

class Rectangulo(Figura):
    def __init__(self, base, altura):
        super().__init__("Rectángulo")
        self.__base = base
        self.__altura = altura

    def calcular_area(self):
        return self.__base * self.__altura

    def calcular_perimetro(self):
        return 2 * (self.__base + self.__altura)

class Triangulo(Figura):
    def __init__(self, base, altura, lado2, lado3):
        super().__init__("Triángulo")
        self.__base = base
        self.__altura = altura
        self.__lado2 = lado2
        self.__lado3 = lado3

    def calcular_area(self):
        return (self.__base * self.__altura) / 2

    def calcular_perimetro(self):
        return self.__base + self.__lado2 + self.__lado3

class Cuadrado(Figura):
    def __init__(self, lado):
        super().__init__("Cuadrado")
        self.__lado = lado

    def calcular_area(self):
        return self.__lado ** 2

    def calcular_perimetro(self):
        return 4 * self.__lado

class Trapecio(Figura):
    def __init__(self, base_mayor, base_menor, altura, lado1, lado2):
        super().__init__("Trapecio")
        self.__base_mayor = base_mayor
        self.__base_menor = base_menor
        self.__altura = altura
        self.__lado1 = lado1
        self.__lado2 = lado2

    def calcular_area(self):
        return ((self.__base_mayor + self.__base_menor) * self.__altura) / 2

    def calcular_perimetro(self):
        return self.__base_mayor + self.__base_menor + self.__lado1 + self.__lado2

# Lista global
figuras_registradas = []

# Registro de figura
def registrar_figura(tipo):
    try:
        if tipo == "Círculo":
            radio = float(entries["radio"].get())
            figura = Circulo(radio)
        elif tipo == "Rectángulo":
            base = float(entries["base"].get())
            altura = float(entries["altura"].get())
            figura = Rectangulo(base, altura)
        elif tipo == "Triángulo":
            base = float(entries["base"].get())
            altura = float(entries["altura"].get())
            lado2 = float(entries["lado2"].get())
            lado3 = float(entries["lado3"].get())
            figura = Triangulo(base, altura, lado2, lado3)
        elif tipo == "Cuadrado":
            lado = float(entries["lado"].get())
            figura = Cuadrado(lado)
        elif tipo == "Trapecio":
            base_mayor = float(entries["base_mayor"].get())
            base_menor = float(entries["base_menor"].get())
            altura = float(entries["altura"].get())
            lado1 = float(entries["lado1"].get())
            lado2 = float(entries["lado2"].get())
            figura = Trapecio(base_mayor, base_menor, altura, lado1, lado2)

        figuras_registradas.append(figura)
        messagebox.showinfo("Registrado", f"{tipo} registrado correctamente.")
        actualizar_lista()
        for entry in entries.values():
            entry.delete(0, tk.END)
    except ValueError:
        messagebox.showerror("Error", "Ingrese valores numéricos válidos.")

# Cambia dinámicamente los campos
def actualizar_campos(event):
    tipo = figura_combo.get()
    for widget in campos_frame.winfo_children():
        widget.destroy()
    entries.clear()
    campos = {
        "Círculo": ["radio"],
        "Rectángulo": ["base", "altura"],
        "Triángulo": ["base", "altura", "lado2", "lado3"],
        "Cuadrado": ["lado"],
        "Trapecio": ["base_mayor", "base_menor", "altura", "lado1", "lado2"]
    }
    for campo in campos[tipo]:
        lbl = ttk.Label(campos_frame, text=f"{campo.capitalize()}:")
        lbl.pack()
        entry = ttk.Entry(campos_frame)
        entry.pack()
        entries[campo] = entry

def actualizar_lista():
    salida_text.config(state="normal")
    salida_text.delete(1.0, tk.END)
    for i, figura in enumerate(figuras_registradas, 1):
        salida_text.insert(tk.END, f"Figura #{i}\n{figura.mostrar_info()}\n\n")
    salida_text.config(state="disabled")

# Interfaz
root = tk.Tk()
root.title("Sistema de Figuras Geométricas")
root.state("zoomed")  # Pantalla casi completa
root.configure(bg="#e6f2ff")

main_frame = ttk.Frame(root, padding=20)
main_frame.pack(fill=tk.BOTH, expand=True)

ttk.Label(main_frame, text="Seleccione una figura:", font=("Arial", 14)).pack()
figura_combo = ttk.Combobox(main_frame, values=["Círculo", "Rectángulo", "Triángulo", "Cuadrado", "Trapecio"], state="readonly")
figura_combo.pack()
figura_combo.bind("<<ComboboxSelected>>", actualizar_campos)

campos_frame = ttk.Frame(main_frame)
campos_frame.pack(pady=10)

entries = {}

ttk.Button(main_frame, text="Registrar Figura", command=lambda: registrar_figura(figura_combo.get())).pack(pady=5)

ttk.Label(main_frame, text="Figuras Registradas:", font=("Arial", 14)).pack(pady=5)
salida_text = tk.Text(main_frame, height=12, state="disabled", wrap="word", font=("Courier", 11))
salida_text.pack(fill=tk.BOTH, expand=True)

root.mainloop()
