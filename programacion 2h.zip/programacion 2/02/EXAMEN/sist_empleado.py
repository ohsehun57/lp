# Sistema de Gestión de Empleados
# Aplicando: Encapsulamiento, Herencia, Polimorfismo

class Empleado:
    def __init__(self, nombre, dni, salario_base):
        # Encapsulamiento: Atributos privados para proteger los datos
        self.__nombre = nombre
        self.__dni = dni
        self.__salario_base = salario_base

    # Getters para acceder a los atributos encapsulados
    def get_nombre(self):
        return self.__nombre

    def get_dni(self):
        return self.__dni

    def get_salario_base(self):
        return self.__salario_base

    # Polimorfismo: Método para calcular el salario con el descuento base
    def calcular_salario(self):
        # Recordando: El salario base se descuenta el 10%
        descuento = self.__salario_base * 0.10
        return self.__salario_base - descuento

    # Polimorfismo: Método para mostrar la información básica del empleado
    def mostrar_info(self):
        # Este método se sobrescribirá en las subclases para añadir detalles específicos
        pass

# Subclase Administrativo - Hereda de Empleado
class Administrativo(Empleado):
    def __init__(self, nombre, dni, salario_base):
        super().__init__(nombre, dni, salario_base) # Llama al constructor de la clase base

    # Polimorfismo: Calcula el salario final del Administrativo
    def calcular_salario_final(self):
        # Para el administrativo, el salario final es simplemente el salario base con el descuento
        return self.calcular_salario()

    # Polimorfismo: Sobrescribe mostrar_info para Administrativo
    def mostrar_info(self):
        print(f"\n👨‍💼 ADMINISTRATIVO")
        print(f"Nombre: {self.get_nombre()}")
        print(f"DNI: {self.get_dni()}")
        print(f"Salario Base: S/. {self.get_salario_base():.2f}")
        print(f"Salario Neto (con 10% de descuento): S/. {self.calcular_salario_final():.2f}")

# Subclase Operario - Hereda de Empleado
class Operario(Empleado):
    def __init__(self, nombre, dni, salario_base, bono_horas_extra):
        super().__init__(nombre, dni, salario_base) # Llama al constructor de la clase base
        self.__bono_horas_extra = bono_horas_extra # Atributo específico de Operario

    def get_bono_horas_extra(self):
        return self.__bono_horas_extra

    # Polimorfismo: Calcula el salario final del Operario
    def calcular_salario_final(self):
        salario_con_descuento = self.calcular_salario() # Obtiene el salario base con el 10% de descuento
        return salario_con_descuento + self.__bono_horas_extra # Suma el bono de horas extra

    # Polimorfismo: Sobrescribe mostrar_info para Operario
    def mostrar_info(self):
        print(f"\n👷 OPERARIO")
        print(f"Nombre: {self.get_nombre()}")
        print(f"DNI: {self.get_dni()}")
        print(f"Salario Base: S/. {self.get_salario_base():.2f}")
        print(f"Bono por Horas Extra: S/. {self.get_bono_horas_extra():.2f}")
        print(f"Salario Neto (incluyendo descuento y bono): S/. {self.calcular_salario_final():.2f}")

# Menú principal y lógica de la aplicación
def main():
    lista_empleados = [] # Lista para almacenar objetos Empleado (o sus subclases)
    while True:
        print("\n---***** SISTEMA DE GESTIÓN DE EMPLEADOS *****---")
        print("1. Registrar Administrativo")
        print("2. Registrar Operario")
        print("3. Mostrar todos los empleados")
        print("4. Salir")

        opcion = input("Ingrese una opción: ")

        if opcion == "1":
            nombre = input("Nombre del Administrativo: ")
            dni = input("DNI del Administrativo: ")
            try:
                salario_base = float(input("Salario Base del Administrativo: S/. "))
            except ValueError:
                print("❌ Salario base inválido. Por favor, ingrese un número.")
                continue
            admin = Administrativo(nombre, dni, salario_base)
            lista_empleados.append(admin)
            print("✅ Administrativo registrado con éxito.")

        elif opcion == "2":
            nombre = input("Nombre del Operario: ")
            dni = input("DNI del Operario: ")
            try:
                salario_base = float(input("Salario Base del Operario: S/. "))
                bono = float(input("Bono por Horas Extra del Operario: S/. "))
            except ValueError:
                print("❌ Entrada inválida (salario o bono). Por favor, ingrese números.")
                continue
            oper = Operario(nombre, dni, salario_base, bono)
            lista_empleados.append(oper)
            print("✅ Operario registrado con éxito.")

        elif opcion == "3":
            if not lista_empleados:
                print("⚠️ No hay empleados registrados para mostrar.")
            else:
                print("\n--- LISTA DE EMPLEADOS REGISTRADOS ---")
                for empleado in lista_empleados:
                    # Polimorfismo en acción: llama al método mostrar_info de la subclase correcta
                    empleado.mostrar_info()

        elif opcion == "4":
            print("👋 Saliendo del sistema de gestión de empleados. ¡Hasta pronto!")
            break

        else:
            print("❌ Opción no válida. Por favor, intente de nuevo con una opción del 1 al 4.")

# Asegura que main() se ejecute solo cuando el script es el programa principal
if __name__ == "__main__":
    main()