import tkinter as tk
from tkinter import ttk, messagebox

# --- Clases de Empleados (sin cambios, reutilizamos las definidas anteriormente) ---

class Empleado:
    def __init__(self, nombre, dni, salario_base):
        self.__nombre = nombre
        self.__dni = dni
        self.__salario_base = salario_base

    def get_nombre(self):
        return self.__nombre

    def get_dni(self):
        return self.__dni

    def get_salario_base(self):
        return self.__salario_base

    def calcular_salario(self):
        # Recordando: El salario base se descuenta el 10%
        descuento = self.__salario_base * 0.10
        return self.__salario_base - descuento

    def mostrar_info(self):
        # Este método será sobrescrito por las subclases
        pass

class Administrativo(Empleado):
    def __init__(self, nombre, dni, salario_base):
        super().__init__(nombre, dni, salario_base)

    def calcular_salario_final(self):
        return self.calcular_salario()

    def mostrar_info(self):
        # Devuelve una tupla de datos para el Treeview
        return ("Administrativo", self.get_nombre(), self.get_dni(),
                f"S/. {self.get_salario_base():.2f}",
                "N/A",
                f"S/. {self.calcular_salario_final():.2f}")

class Operario(Empleado):
    def __init__(self, nombre, dni, salario_base, bono_horas_extra):
        super().__init__(nombre, dni, salario_base)
        self.__bono_horas_extra = bono_horas_extra

    def get_bono_horas_extra(self):
        return self.__bono_horas_extra

    def calcular_salario_final(self):
        salario_con_descuento = self.calcular_salario()
        return salario_con_descuento + self.__bono_horas_extra

    def mostrar_info(self):
        # Devuelve una tupla de datos para el Treeview
        return ("Operario", self.get_nombre(), self.get_dni(),
                f"S/. {self.get_salario_base():.2f}",
                f"S/. {self.get_bono_horas_extra():.2f}",
                f"S/. {self.calcular_salario_final():.2f}")

# --- Aplicación Tkinter ---

class EmpleadoApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Sistema de Gestión de Empleados")
        self.root.geometry("1000x600") # Tamaño inicial de la ventana
        self.root.resizable(False, False) # No permitir redimensionar la ventana

        # Lista global para almacenar los empleados
        self.lista_empleados = []

        # --- Colores Cálidos ---
        self.bg_color = "#F8F4E3"  # Crema suave
        self.header_color = "#A0522D" # Terracota/Siena
        self.text_color = "#4A3F33"  # Marrón oscuro
        self.button_color = "#CD853F" # Marrón claro/Tan
        self.button_text_color = "white"
        self.border_color = "#D2B48C" # Tan claro para bordes

        self.root.configure(bg=self.bg_color) # Fondo de la ventana principal

        # --- Estilos para los widgets ---
        self.style = ttk.Style()
        self.style.theme_use('clam') # Un tema más moderno para ttk

        self.style.configure("TFrame", background=self.bg_color)
        self.style.configure("TLabel", background=self.bg_color, foreground=self.text_color, font=('Arial', 10))
        self.style.configure("TEntry", fieldbackground="white", foreground=self.text_color, font=('Arial', 10))
        self.style.configure("TButton", background=self.button_color, foreground=self.button_text_color, font=('Arial', 10, 'bold'), borderwidth=0)
        self.style.map("TButton",
                       background=[('active', self.header_color)], # Color al pasar el ratón
                       foreground=[('active', self.button_text_color)])

        self.style.configure("Treeview.Heading", font=('Arial', 10, 'bold'), background=self.header_color, foreground="white")
        self.style.configure("Treeview", background="white", foreground=self.text_color, rowheight=25, fieldbackground="white")
        self.style.map('Treeview', background=[('selected', self.button_color)])

        # --- Frames principales ---
        self.input_frame = ttk.Frame(root, padding="20", relief="groove", borderwidth=2, style="TFrame")
        self.input_frame.pack(side="left", fill="y", padx=15, pady=15)

        self.display_frame = ttk.Frame(root, padding="20", relief="groove", borderwidth=2, style="TFrame")
        self.display_frame.pack(side="right", fill="both", expand=True, padx=15, pady=15)

        # --- Widgets de Entrada (Input Frame) ---
        ttk.Label(self.input_frame, text="REGISTRO DE EMPLEADOS", font=('Arial', 14, 'bold'), foreground=self.header_color).grid(row=0, column=0, columnspan=2, pady=10)

        # Tipo de Empleado (Radio Buttons)
        self.tipo_empleado_var = tk.StringVar(value="Administrativo")
        ttk.Radiobutton(self.input_frame, text="Administrativo", variable=self.tipo_empleado_var, value="Administrativo", command=self.toggle_operario_fields, style="TRadiobutton").grid(row=1, column=0, pady=5, sticky="w")
        ttk.Radiobutton(self.input_frame, text="Operario", variable=self.tipo_empleado_var, value="Operario", command=self.toggle_operario_fields, style="TRadiobutton").grid(row=1, column=1, pady=5, sticky="w")
        self.style.configure("TRadiobutton", background=self.bg_color, foreground=self.text_color, font=('Arial', 10))

        # Campos de entrada
        ttk.Label(self.input_frame, text="Nombre:").grid(row=2, column=0, sticky="w", pady=5)
        self.entry_nombre = ttk.Entry(self.input_frame, width=30)
        self.entry_nombre.grid(row=2, column=1, pady=5, padx=5)

        ttk.Label(self.input_frame, text="DNI:").grid(row=3, column=0, sticky="w", pady=5)
        self.entry_dni = ttk.Entry(self.input_frame, width=30)
        self.entry_dni.grid(row=3, column=1, pady=5, padx=5)

        ttk.Label(self.input_frame, text="Salario Base (S/.):").grid(row=4, column=0, sticky="w", pady=5)
        self.entry_salario_base = ttk.Entry(self.input_frame, width=30)
        self.entry_salario_base.grid(row=4, column=1, pady=5, padx=5)

        self.label_bono = ttk.Label(self.input_frame, text="Bono Horas Extra (S/.):")
        self.label_bono.grid(row=5, column=0, sticky="w", pady=5)
        self.entry_bono = ttk.Entry(self.input_frame, width=30)
        self.entry_bono.grid(row=5, column=1, pady=5, padx=5)

        # Ocultar campo de bono por defecto (para Administrativo)
        self.toggle_operario_fields()

        # Botón de Registrar
        self.btn_registrar = ttk.Button(self.input_frame, text="Registrar Empleado", command=self.register_employee)
        self.btn_registrar.grid(row=6, column=0, columnspan=2, pady=20)

        # --- Widgets de Visualización (Display Frame) ---
        ttk.Label(self.display_frame, text="LISTA DE EMPLEADOS", font=('Arial', 14, 'bold'), foreground=self.header_color).pack(pady=10)

        # Treeview para mostrar la tabla de empleados
        self.tree = ttk.Treeview(self.display_frame, columns=("Tipo", "Nombre", "DNI", "Salario Base", "Bono Horas Extra", "Salario Neto"), show="headings")
        self.tree.pack(fill="both", expand=True)

        # Definir encabezados de columna
        self.tree.heading("Tipo", text="Tipo")
        self.tree.heading("Nombre", text="Nombre")
        self.tree.heading("DNI", text="DNI")
        self.tree.heading("Salario Base", text="Salario Base")
        self.tree.heading("Bono Horas Extra", text="Bono H. Extra")
        self.tree.heading("Salario Neto", text="Salario Neto")

        # Ajustar ancho de columnas
        self.tree.column("Tipo", width=100, anchor="center")
        self.tree.column("Nombre", width=150, anchor="w")
        self.tree.column("DNI", width=100, anchor="center")
        self.tree.column("Salario Base", width=100, anchor="e")
        self.tree.column("Bono Horas Extra", width=100, anchor="e")
        self.tree.column("Salario Neto", width=100, anchor="e")

        # Scrollbar para el Treeview
        scrollbar = ttk.Scrollbar(self.tree, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")

        # Botones de acción (debajo del Treeview)
        self.btn_mostrar_todos = ttk.Button(self.display_frame, text="Actualizar Lista", command=self.update_display)
        self.btn_mostrar_todos.pack(pady=10)

        self.btn_salir = ttk.Button(self.root, text="Salir del Sistema", command=root.quit, style="TButton")
        self.btn_salir.pack(pady=10)

    def toggle_operario_fields(self):
        """Habilita o deshabilita el campo de bono según el tipo de empleado seleccionado."""
        if self.tipo_empleado_var.get() == "Operario":
            self.label_bono.grid() # Muestra la etiqueta
            self.entry_bono.grid() # Muestra el campo de entrada
            self.entry_bono.configure(state="normal") # Habilita el campo
        else:
            self.label_bono.grid_remove() # Oculta la etiqueta
            self.entry_bono.grid_remove() # Oculta el campo de entrada
            self.entry_bono.delete(0, tk.END) # Limpia el campo por si acaso
            self.entry_bono.configure(state="disabled") # Deshabilita el campo

    def register_employee(self):
        """Registra un nuevo empleado basado en la entrada del usuario."""
        nombre = self.entry_nombre.get().strip()
        dni = self.entry_dni.get().strip()
        salario_base_str = self.entry_salario_base.get().strip()
        bono_str = self.entry_bono.get().strip()

        # Validación básica de entradas
        if not nombre or not dni or not salario_base_str:
            messagebox.showerror("Error de Entrada", "Por favor, complete todos los campos obligatorios (Nombre, DNI, Salario Base).")
            return

        try:
            salario_base = float(salario_base_str)
            if salario_base < 0:
                messagebox.showerror("Error de Entrada", "El salario base no puede ser negativo.")
                return
        except ValueError:
            messagebox.showerror("Error de Entrada", "Salario Base debe ser un número válido.")
            return

        if self.tipo_empleado_var.get() == "Administrativo":
            empleado = Administrativo(nombre, dni, salario_base)
            self.lista_empleados.append(empleado)
            messagebox.showinfo("Registro Exitoso", "Administrativo registrado correctamente.")
        else: # Es Operario
            try:
                bono_horas_extra = float(bono_str)
                if bono_horas_extra < 0:
                    messagebox.showerror("Error de Entrada", "El bono por horas extra no puede ser negativo.")
                    return
            except ValueError:
                messagebox.showerror("Error de Entrada", "Bono por Horas Extra debe ser un número válido.")
                return
            empleado = Operario(nombre, dni, salario_base, bono_horas_extra)
            self.lista_empleados.append(empleado)
            messagebox.showinfo("Registro Exitoso", "Operario registrado correctamente.")

        self.clear_inputs() # Limpia los campos de entrada
        self.update_display() # Actualiza la tabla de empleados

    def clear_inputs(self):
        """Limpia todos los campos de entrada."""
        self.entry_nombre.delete(0, tk.END)
        self.entry_dni.delete(0, tk.END)
        self.entry_salario_base.delete(0, tk.END)
        self.entry_bono.delete(0, tk.END) # Siempre limpiar, incluso si está deshabilitado

    def update_display(self):
        """Actualiza el Treeview con la lista actual de empleados."""
        # Limpiar Treeview existente
        for item in self.tree.get_children():
            self.tree.delete(item)

        # Insertar nuevos datos
        if not self.lista_empleados:
            # Si no hay empleados, insertar un mensaje
            self.tree.insert("", "end", values=("", "", "", "No hay empleados registrados", "", ""), tags=('no_data',))
            self.tree.tag_configure('no_data', foreground=self.text_color, font=('Arial', 10, 'italic'), background=self.bg_color)
        else:
            for empleado in self.lista_empleados:
                # El método mostrar_info en las clases de empleado devuelve una tupla de datos
                self.tree.insert("", "end", values=empleado.mostrar_info())

# --- Ejecución de la Aplicación ---
if __name__ == "__main__":
    root = tk.Tk()
    app = EmpleadoApp(root)
    root.mainloop()