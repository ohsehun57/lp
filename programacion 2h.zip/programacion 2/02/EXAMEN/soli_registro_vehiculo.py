from abc import ABC, abstractmethod
from typing import List
import os


# === INTERFAZ GENERADOR DE REPORTE ===
class GeneradorReporte(ABC):
    @abstractmethod
    def generar(self, vehiculo: 'Vehiculo'):
        pass


class ReporteConsola:
    def mostrar(self, vehiculo: 'Vehiculo'):
        print("\n=== REPORTE POR CONSOLA ===")
        print(vehiculo.obtener_datos())
        print("-" * 40)


class ReporteTexto(GeneradorReporte):
    def __init__(self, archivo: str = "reportes_vehiculos.txt"):
        self.archivo = archivo
        if not os.path.exists(self.archivo):
            with open(self.archivo, 'w', encoding='utf-8') as f:
                f.write("=== REPORTE UNIFICADO DE VEHÍCULOS ===\n\n")

    def generar(self, vehiculo: 'Vehiculo'):
        with open(self.archivo, 'a', encoding='utf-8') as f:
            f.write(vehiculo.obtener_datos())
            f.write("\n" + "-" * 40 + "\n")
        print(f"[✔] Reporte añadido a {self.archivo}")


# === CLASE BASE VEHÍCULO ===
class Vehiculo(ABC):
    def __init__(self, marca: str, modelo: str, anio: int):
        self.marca = marca
        self.modelo = modelo
        self.anio = anio

    @abstractmethod
    def obtener_datos(self) -> str:
        pass


class Auto(Vehiculo):
    def __init__(self, marca, modelo, anio, pasajeros):
        super().__init__(marca, modelo, anio)
        self.pasajeros = pasajeros

    def obtener_datos(self):
        return f"""Tipo: Auto
Marca: {self.marca}
Modelo: {self.modelo}
Año: {self.anio}
Pasajeros: {self.pasajeros}"""


class Camion(Vehiculo):
    def __init__(self, marca, modelo, anio, peso_maximo, tipo_carga):
        super().__init__(marca, modelo, anio)
        self.peso_maximo = peso_maximo
        self.tipo_carga = tipo_carga

    def obtener_datos(self):
        return f"""Tipo: Camión
Marca: {self.marca}
Modelo: {self.modelo}
Año: {self.anio}
Peso máximo: {self.peso_maximo} kg
Tipo de carga: {self.tipo_carga}"""


class Moto(Vehiculo):
    def __init__(self, marca, modelo, anio, cilindrada):
        super().__init__(marca, modelo, anio)
        self.cilindrada = cilindrada

    def obtener_datos(self):
        return f"""Tipo: Moto
Marca: {self.marca}
Modelo: {self.modelo}
Año: {self.anio}
Cilindrada: {self.cilindrada} cc"""


# === FUNCIONES INTERACTIVAS ===

def menu():
    print("\n===== SISTEMA DE REPORTES DE VEHÍCULOS =====")
    print("1. Mostrar reportes predefinidos")
    print("2. Agregar nuevo vehículo")
    print("3. Salir")


def pedir_vehiculo() -> Vehiculo:
    tipo = input("¿Qué tipo de vehículo quieres agregar? (auto/camion/moto): ").strip().lower()
    marca = input("Marca: ")
    modelo = input("Modelo: ")
    anio = int(input("Año: "))

    if tipo == "auto":
        pasajeros = int(input("Cantidad de pasajeros: "))
        return Auto(marca, modelo, anio, pasajeros)
    elif tipo == "camion":
        peso = float(input("Peso máximo (kg): "))
        carga = input("Tipo de carga: ")
        return Camion(marca, modelo, anio, peso, carga)
    elif tipo == "moto":
        cilindrada = int(input("Cilindrada (cc): "))
        return Moto(marca, modelo, anio, cilindrada)
    else:
        print("❌ Tipo inválido. Intenta nuevamente.")
        return pedir_vehiculo()


# === PROGRAMA PRINCIPAL ===

def main():
    consola = ReporteConsola()
    texto = ReporteTexto()

    vehiculos: List[Vehiculo] = [
        Auto("Toyota", "Corolla", 2020, 5),
        Camion("Volvo", "FH16", 2018, 18000, "Carga general"),
        Moto("Honda", "CBR500R", 2022, 500)
    ]

    while True:
        menu()
        opcion = input("Elige una opción: ").strip()

        if opcion == "1":
            for vehiculo in vehiculos:
                consola.mostrar(vehiculo)
                guardar = input("¿Guardar en archivo TXT? (s/n): ").lower()
                if guardar == 's':
                    texto.generar(vehiculo)

        elif opcion == "2":
            nuevo = pedir_vehiculo()
            vehiculos.append(nuevo)
            consola.mostrar(nuevo)
            guardar = input("¿Guardar en archivo TXT? (s/n): ").lower()
            if guardar == 's':
                texto.generar(nuevo)

        elif opcion == "3":
            print("✅ Programa finalizado.")
            break
        else:
            print("❌ Opción inválida. Intenta otra vez.")


if __name__ == "__main__":
    main()
