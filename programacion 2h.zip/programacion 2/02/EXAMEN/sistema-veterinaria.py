#Sistema de animales
#Aplicando: Encapsulamiento, Herencia, Polimorfismo

class Animal:
    def __init__(self, nombre, especie, edad):
        # Encapsulamiento
        self.__nombre = nombre
        self.__especie = especie
        self.__edad = edad

    # Getters
    def get_nombre(self):
        return self.__nombre

    def get_especie(self):
        return self.__especie

    def get_edad(self):
        return self.__edad

    # Polimorfismo
    def mostrar_info(self):
        pass

# Subclase Felino
class Felino(Animal):
    def __init__(self, nombre, especie, edad, color):
        super().__init__(nombre, especie, edad)
        self.__color = color

    def get_color(self):
        return self.__color

    # Polimorfismo
    def mostrar_info(self):
        print(f"\n🐱 FELINO")
        print(f"Nombre: {self.get_nombre()}")
        print(f"Especie: {self.get_especie()}")
        print(f"Edad: {self.get_edad()} años")
        print(f"Color: {self.get_color()}")

# Subclase Ave
class Ave(Animal):
    def __init__(self, nombre, especie, edad, tipo_de_pico):
        super().__init__(nombre, especie, edad)
        self.__tipo_de_pico = tipo_de_pico

    def get_tipo_de_pico(self):
        return self.__tipo_de_pico

    # Polimorfismo
    def mostrar_info(self):
        print(f"\n🐦 AVE")
        print(f"Nombre: {self.get_nombre()}")
        print(f"Especie: {self.get_especie()}")
        print(f"Edad: {self.get_edad()} años")
        print(f"Tipo de pico: {self.get_tipo_de_pico()}")

# Menú principal
def main():
    lista_animales = []
    while True:
        print("\n***** SISTEMA DE ANIMALES *****")
        print("1. Registrar Felino")
        print("2. Registrar Ave")
        print("3. Mostrar todos los animales")
        print("4. Salir")

        opcion = input("Ingrese una opción: ")

        if opcion == "1":
            nombre = input("Nombre: ")
            especie = input("Especie: ")
            edad = int(input("Edad: "))
            color = input("Color: ")
            f = Felino(nombre, especie, edad, color)
            lista_animales.append(f)
            print("✅ Felino registrado.")

        elif opcion == "2":
            nombre = input("Nombre: ")
            especie = input("Especie: ")
            edad = int(input("Edad: "))
            pico = input("Tipo de pico: ")
            a = Ave(nombre, especie, edad, pico)
            lista_animales.append(a)
            print("✅ Ave registrada.")

        elif opcion == "3":
            if len(lista_animales) == 0:
                print("⚠️ No hay animales registrados.")
            else:
                for animal in lista_animales:
                    animal.mostrar_info()

        elif opcion == "4":
            print("👋 Saliendo del sistema...")
            break

        else:
            print("❌ Opción no válida. Intente nuevamente.")

if __name__ == "__main__":
    main()
