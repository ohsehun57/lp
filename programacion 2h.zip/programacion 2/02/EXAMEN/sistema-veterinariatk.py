import tkinter as tk
from tkinter import ttk

# ----- Lógica de Clases -----
class Animal:
    def __init__(self, nombre, especie, edad):
        self.__nombre = nombre
        self.__especie = especie
        self.__edad = edad

    def get_nombre(self): return self.__nombre
    def get_especie(self): return self.__especie
    def get_edad(self): return self.__edad
    def mostrar_info(self): pass

class Felino(Animal):
    def __init__(self, nombre, especie, edad, color):
        super().__init__(nombre, especie, edad)
        self.__color = color

    def get_color(self): return self.__color

    def mostrar_info(self):
        return (f"🐱 FELINO\n"
                f"Nombre: {self.get_nombre()}\n"
                f"Especie: {self.get_especie()}\n"
                f"Edad: {self.get_edad()} años\n"
                f"Color: {self.get_color()}\n")

class Ave(Animal):
    def __init__(self, nombre, especie, edad, tipo_de_pico):
        super().__init__(nombre, especie, edad)
        self.__tipo_de_pico = tipo_de_pico

    def get_tipo_de_pico(self): return self.__tipo_de_pico

    def mostrar_info(self):
        return (f"🐦 AVE\n"
                f"Nombre: {self.get_nombre()}\n"
                f"Especie: {self.get_especie()}\n"
                f"Edad: {self.get_edad()} años\n"
                f"Tipo de pico: {self.get_tipo_de_pico()}\n")

# ----- Interfaz Gráfica -----
lista_animales = []

class SistemaAnimalesApp:
    def __init__(self, root):
        self.root = root
        self.root.title("🐾 Sistema de Registro de Animales")
        self.root.geometry("700x500")
        self.root.configure(bg="#e6f2ff")

        style = ttk.Style()
        style.theme_use("clam")
        style.configure("TNotebook", background="#cce6ff", tabmargins= [2, 5, 2, 0])
        style.configure("TNotebook.Tab", background="#99ccff", padding=10, font=('Segoe UI', 11, 'bold'))
        style.map("TNotebook.Tab", background=[("selected", "#3399ff")])
        style.configure("TButton", background="#4da6ff", foreground="white", font=('Segoe UI', 10, 'bold'))
        style.configure("TLabel", background="#e6f2ff", font=('Segoe UI', 10))

        self.tabs = ttk.Notebook(self.root)
        self.tab_felino = ttk.Frame(self.tabs)
        self.tab_ave = ttk.Frame(self.tabs)
        self.tab_mostrar = ttk.Frame(self.tabs)

        self.tabs.add(self.tab_felino, text="Registrar Felino")
        self.tabs.add(self.tab_ave, text="Registrar Ave")
        self.tabs.add(self.tab_mostrar, text="Mostrar Animales")
        self.tabs.pack(expand=1, fill="both", pady=10)

        self.felino_widgets()
        self.ave_widgets()
        self.mostrar_widgets()

    def felino_widgets(self):
        self.f_nombre = self.crear_entrada(self.tab_felino, "Nombre:")
        self.f_especie = self.crear_entrada(self.tab_felino, "Especie:")
        self.f_edad = self.crear_entrada(self.tab_felino, "Edad:")
        self.f_color = self.crear_entrada(self.tab_felino, "Color:")

        self.lbl_felino_estado = ttk.Label(self.tab_felino, text="")
        self.lbl_felino_estado.pack(pady=10)

        ttk.Button(self.tab_felino, text="Registrar Felino", command=self.registrar_felino).pack(pady=10)

    def ave_widgets(self):
        self.a_nombre = self.crear_entrada(self.tab_ave, "Nombre:")
        self.a_especie = self.crear_entrada(self.tab_ave, "Especie:")
        self.a_edad = self.crear_entrada(self.tab_ave, "Edad:")
        self.a_pico = self.crear_entrada(self.tab_ave, "Tipo de Pico:")

        self.lbl_ave_estado = ttk.Label(self.tab_ave, text="")
        self.lbl_ave_estado.pack(pady=10)

        ttk.Button(self.tab_ave, text="Registrar Ave", command=self.registrar_ave).pack(pady=10)

    def mostrar_widgets(self):
        self.text_area = tk.Text(self.tab_mostrar, font=("Consolas", 10), bg="#f9f9f9", width=80, height=22, bd=2, relief="groove")
        self.text_area.pack(pady=10)

        ttk.Button(self.tab_mostrar, text="🔄 Mostrar Animales", command=self.mostrar_todos).pack()

    def crear_entrada(self, parent, texto):
        frame = ttk.Frame(parent)
        frame.pack(pady=5)
        ttk.Label(frame, text=texto, width=20).pack(side=tk.LEFT, padx=5)
        entrada = ttk.Entry(frame, width=40)
        entrada.pack(side=tk.LEFT)
        return entrada

    def registrar_felino(self):
        try:
            nombre = self.f_nombre.get()
            especie = self.f_especie.get()
            edad = int(self.f_edad.get())
            color = self.f_color.get()
            lista_animales.append(Felino(nombre, especie, edad, color))
            self.lbl_felino_estado.config(text="✅ Felino registrado con éxito", foreground="green")
            self.limpiar([self.f_nombre, self.f_especie, self.f_edad, self.f_color])
        except:
            self.lbl_felino_estado.config(text="❌ Error en los datos ingresados", foreground="red")

    def registrar_ave(self):
        try:
            nombre = self.a_nombre.get()
            especie = self.a_especie.get()
            edad = int(self.a_edad.get())
            pico = self.a_pico.get()
            lista_animales.append(Ave(nombre, especie, edad, pico))
            self.lbl_ave_estado.config(text="✅ Ave registrada con éxito", foreground="green")
            self.limpiar([self.a_nombre, self.a_especie, self.a_edad, self.a_pico])
        except:
            self.lbl_ave_estado.config(text="❌ Error en los datos ingresados", foreground="red")

    def mostrar_todos(self):
        self.text_area.delete("1.0", tk.END)
        if not lista_animales:
            self.text_area.insert(tk.END, "⚠️ No hay animales registrados.\n")
        else:
            for animal in lista_animales:
                self.text_area.insert(tk.END, animal.mostrar_info() + "\n")

    def limpiar(self, campos):
        for campo in campos:
            campo.delete(0, tk.END)

# ----- Ejecutar el programa -----
if __name__ == "__main__":
    root = tk.Tk()
    app = SistemaAnimalesApp(root)
    root.mainloop()
