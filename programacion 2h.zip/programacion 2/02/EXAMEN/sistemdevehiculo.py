"""#Sistema de figuras geométricas
#Aplicando: Encapsulamiento, Herencia, Polimorfismo

#clase base(superclase)
import math
class Vehiculo:
    def __init__(self, marca, modelo, anio):
        #encapsulamiento
        self.__marca = marca
        self.__modelo = modelo
        self.__anio = anio
    #encapsulamiento: getter
    def get_marca(self):
        return self.__marca
    
    def get_modelo(self):
        return self.__modelo
    
    def get_anio(self):
        return self.__anio
    
    #Polimorfismo
    def calcular_impuesto(self):
        pass

    def mostrar_info(self):
        print(f"Vehiculo: {self.__marca} {self.__modelo} {self.__anio}")
        print(f"Impuesto anual: {self.calcular_impuesto()}")

#Sub clase
#Herencia: Hereda de Vehiculo
class Auto(Vehiculo):
    def __init__(self, marca, modelo, anio, impuesto_base):
        super().__init__(marca, modelo, anio)
        #encapsulamiento
        self.__impuesto_base = impuesto_base
    #encapsulamiento: getter
    def get_impuesto_base(self):
        return self.__impuesto_base
                
    
    #Polimorfismo
    def calcular_impuesto(self):
        if self.get_anio()<2010:
            recargo = 50
        else:
            recargo = 100
        return self.__impuesto_base + recargo

class Moto(Vehiculo):
    def __init__(self, marca, modelo, anio, impuesto_base):
        super().__init__(marca, modelo, anio)
        #encapsulamiento
        self.__impuesto_base = impuesto_base
    #encapsulamiento: getter
    def get_impuesto_base(self):
        return self.__impuesto_base
    
    #Polimorfismo
    def calcular_impuesto(self):
        return self.__impuesto_base

#menu principal
def main():
    lista_vehiculos = []
    while True:
        print("\n *****SISTEMA DE VEHICULOS*****")
        print("1. Registrar Auto")
        print("2. Registrar Moto")
        print("3. Mostrar todos los vehiculos")
        print("4. Salir")

        opcion = input("ingrese una opcion: ")
        if opcion == "1":
            marca = input("Marca: ")
            modelo = input("Modelo: ")
            anio = int(input("Anio: "))
            imp_base = float(input("Impuesto Base: "))
            a = Auto(marca, modelo, anio, imp_base)
            lista_vehiculos.append(a)
            print("Auto registrado")

        elif opcion == "2":
            marca = input("Marca: ")
            modelo = input("Modelo: ")
            anio = int(input("Anio: "))
            imp_base = float(input("Impuesto Base: "))
            m = Moto(marca, modelo, anio, imp_base)
            lista_vehiculos.append(m)
            print("Moto registrada")

        elif opcion == "3":
            if len(lista_vehiculos) == 0:
                print ("No hay vehiculos registradas")
            else:
                for f in lista_vehiculos:
                    f.mostrar_info()

        elif opcion == "4":
            print("saliendo del sistema")
            break
        else:
            print("opcion no valida. Intente nuevamente")

if __name__ == "__main__":
    main()"""

import tkinter as tk
from tkinter import ttk

# Tu código original
import math

class Vehiculo:
    def __init__(self, marca, modelo, anio):
        self.__marca = marca
        self.__modelo = modelo
        self.__anio = anio

    def get_marca(self):
        return self.__marca

    def get_modelo(self):
        return self.__modelo

    def get_anio(self):
        return self.__anio

    def calcular_impuesto(self):
        pass

    def mostrar_info(self):
        return f"Vehiculo: {self.__marca} {self.__modelo} {self.__anio}\nImpuesto anual: {self.calcular_impuesto()}"

class Auto(Vehiculo):
    def __init__(self, marca, modelo, anio, impuesto_base):
        super().__init__(marca, modelo, anio)
        self.__impuesto_base = impuesto_base

    def get_impuesto_base(self):
        return self.__impuesto_base

    def calcular_impuesto(self):
        recargo = 50 if self.get_anio() < 2010 else 100
        return self.__impuesto_base + recargo

class Moto(Vehiculo):
    def __init__(self, marca, modelo, anio, impuesto_base):
        super().__init__(marca, modelo, anio)
        self.__impuesto_base = impuesto_base

    def get_impuesto_base(self):
        return self.__impuesto_base

    def calcular_impuesto(self):
        return self.__impuesto_base

# Interfaz gráfica
class AppVehiculos:
    def __init__(self, root):
        self.root = root
        self.root.title("Sistema de Vehículos")
        self.root.geometry("720x500")
        self.root.configure(bg="#f0f4f7")

        self.lista_vehiculos = []

        self.frame_form = tk.Frame(root, bg="#ffffff", bd=2, relief=tk.GROOVE)
        self.frame_form.pack(pady=10, padx=20, fill=tk.X)

        self.tipo_var = tk.StringVar(value="Auto")

        # Tipo
        tk.Label(self.frame_form, text="Tipo:", bg="white").grid(row=0, column=0, padx=5, pady=5)
        ttk.Combobox(self.frame_form, textvariable=self.tipo_var, values=["Auto", "Moto"], width=10).grid(row=0, column=1)

        # Marca
        tk.Label(self.frame_form, text="Marca:", bg="white").grid(row=0, column=2, padx=5)
        self.entry_marca = tk.Entry(self.frame_form)
        self.entry_marca.grid(row=0, column=3, padx=5)

        # Modelo
        tk.Label(self.frame_form, text="Modelo:", bg="white").grid(row=1, column=0, padx=5)
        self.entry_modelo = tk.Entry(self.frame_form)
        self.entry_modelo.grid(row=1, column=1, padx=5)

        # Año
        tk.Label(self.frame_form, text="Año:", bg="white").grid(row=1, column=2, padx=5)
        self.entry_anio = tk.Entry(self.frame_form)
        self.entry_anio.grid(row=1, column=3, padx=5)

        # Impuesto base
        tk.Label(self.frame_form, text="Impuesto Base:", bg="white").grid(row=2, column=0, padx=5)
        self.entry_impuesto = tk.Entry(self.frame_form)
        self.entry_impuesto.grid(row=2, column=1, padx=5)

        # Botones
        tk.Button(self.frame_form, text="Registrar Vehículo", command=self.registrar_vehiculo, bg="#2196f3", fg="white").grid(row=2, column=3, padx=5, pady=5)
        tk.Button(self.frame_form, text="Mostrar Vehículos", command=self.mostrar_vehiculos, bg="#4caf50", fg="white").grid(row=2, column=2, padx=5)

        # Lista
        self.frame_lista = tk.Frame(root, bg="#f0f4f7")
        self.frame_lista.pack(fill=tk.BOTH, expand=True, padx=20)

        self.scrollbar = tk.Scrollbar(self.frame_lista)
        self.scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        self.lista = tk.Listbox(self.frame_lista, font=("Courier", 10), yscrollcommand=self.scrollbar.set, bg="white")
        self.lista.pack(fill=tk.BOTH, expand=True)
        self.scrollbar.config(command=self.lista.yview)

    def registrar_vehiculo(self):
        tipo = self.tipo_var.get()
        marca = self.entry_marca.get()
        modelo = self.entry_modelo.get()
        try:
            anio = int(self.entry_anio.get())
            impuesto_base = float(self.entry_impuesto.get())
        except ValueError:
            self.lista.insert(tk.END, "❌ Año o impuesto no válido")
            return

        if tipo == "Auto":
            vehiculo = Auto(marca, modelo, anio, impuesto_base)
        else:
            vehiculo = Moto(marca, modelo, anio, impuesto_base)

        self.lista_vehiculos.append(vehiculo)
        self.lista.insert(tk.END, f"✔ {tipo} registrado: {marca} {modelo} ({anio})")

        self.entry_marca.delete(0, tk.END)
        self.entry_modelo.delete(0, tk.END)
        self.entry_anio.delete(0, tk.END)
        self.entry_impuesto.delete(0, tk.END)

    def mostrar_vehiculos(self):
        self.lista.insert(tk.END, "==== LISTA DE VEHÍCULOS ====")
        if not self.lista_vehiculos:
            self.lista.insert(tk.END, "No hay vehículos registrados.")
        else:
            for v in self.lista_vehiculos:
                self.lista.insert(tk.END, v.mostrar_info())
                self.lista.insert(tk.END, "---------------------------")

# Ejecutar interfaz
if __name__ == "__main__":
    root = tk.Tk()
    app = AppVehiculos(root)
    root.mainloop()
