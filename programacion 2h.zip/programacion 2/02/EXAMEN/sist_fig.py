from abc import ABC, abstractmethod
import math

# Interfaz base
class FiguraGeometrica(ABC):
    @abstractmethod
    def area(self) -> float:
        pass

    @abstractmethod
    def perimetro(self) -> float:
        pass

    @abstractmethod
    def descripcion(self) -> str:
        pass

# Figuras concretas
class Circulo(FiguraGeometrica):
    def __init__(self, radio: float):
        self.radio = radio

    def area(self) -> float:
        return math.pi * self.radio ** 2

    def perimetro(self) -> float:
        return 2 * math.pi * self.radio

    def descripcion(self) -> str:
        return f"Círculo de radio {self.radio}"

class Cuadrado(FiguraGeometrica):
    def __init__(self, lado: float):
        self.lado = lado

    def area(self) -> float:
        return self.lado ** 2

    def perimetro(self) -> float:
        return 4 * self.lado

    def descripcion(self) -> str:
        return f"Cuadrado de lado {self.lado}"

class Rectangulo(FiguraGeometrica):
    def __init__(self, base: float, altura: float):
        self.base = base
        self.altura = altura

    def area(self) -> float:
        return self.base * self.altura

    def perimetro(self) -> float:
        return 2 * (self.base + self.altura)

    def descripcion(self) -> str:
        return f"Rectángulo de base {self.base} y altura {self.altura}"

# ✅ Triángulo rectángulo específico
class TrianguloRectangulo(FiguraGeometrica):
    def __init__(self, cateto1: float, cateto2: float):
        self.cateto1 = cateto1
        self.cateto2 = cateto2
        self.hipotenusa = math.sqrt(cateto1**2 + cateto2**2)

    def area(self) -> float:
        return (self.cateto1 * self.cateto2) / 2

    def perimetro(self) -> float:
        return self.cateto1 + self.cateto2 + self.hipotenusa

    def descripcion(self) -> str:
        return (f"Triángulo rectángulo con catetos {self.cateto1} y {self.cateto2}, "
                f"hipotenusa calculada {self.hipotenusa:.2f}")

# Visualizador
class VisualizadorFiguras:
    def __init__(self, figuras: list[FiguraGeometrica]):
        self.figuras = figuras

    def mostrar(self):
        for figura in self.figuras:
            print("-" * 40)
            print(f"Figura: {figura.descripcion()}")
            print(f"Área: {figura.area():.2f}")
            print(f"Perímetro: {figura.perimetro():.2f}")

# Prueba del sistema
if __name__ == "__main__":
    figuras = [
        Circulo(5),
        Cuadrado(4),
        Rectangulo(3, 6),
        TrianguloRectangulo(3, 4)  # Hipotenusa será 5
    ]

    visualizador = VisualizadorFiguras(figuras)
    visualizador.mostrar()
