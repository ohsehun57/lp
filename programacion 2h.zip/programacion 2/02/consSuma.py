class suma:
    def __init__(self,a,b):
        self.a=a
        self.b=b
        self.resul=self.a+self.b
        print(f"constructor: se creo la suma de {self.a} + {self.b} = {self.resul}")

    def mostrar_resultado(self):
        print(f"es resultado de la suma es : {self.resul}")
        

    def __del__(self):
        print(f"destructor:   se elimino la suma de {self.a} + {self.b}")
a=int(input("ingrese el valor de a"))
b=int(input("ingrese el valor de b"))
sss = suma(a,b) 
suma.mostrar_resultado()