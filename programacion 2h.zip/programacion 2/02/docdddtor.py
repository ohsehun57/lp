import tkinter as tk
from tkinter import messagebox

class Doctor:
    def __init__(self, nombre, especialidad, experiencia, correo, telefono, hospital):
        self.nombre = nombre
        self.especialidad = especialidad
        self.experiencia = experiencia
        self.correo = correo
        self.telefono = telefono
        self.hospital = hospital

    def mostrar_informacion(self):
        return (
            f"👨‍⚕️ Nombre: {self.nombre}\n"
            f"📌 Especialidad: {self.especialidad}\n"
            f"📅 Experiencia: {self.experiencia} años\n"
            f"📧 Correo: {self.correo}\n"
            f"📞 Teléfono: {self.telefono}\n"
            f"🏥 Hospital: {self.hospital}"
        )

    def atender_paciente(self, paciente):
        return f"🩺 El Dr. {self.nombre} está atendiendo a {paciente}."

    def calcular_salario(self):
        salario_base = 2001
        bono_experiencia = self.experiencia * 150
        salario_total = salario_base + bono_experiencia
        return f"💵 El salario del Dr. {self.nombre} es ${salario_total}"

    def recetar_medicamento(self, medicamento):
        return f"💊 El Dr. {self.nombre} receta: {medicamento}"

# Base de datos en memoria
doctores = {}

# Funciones de la interfaz
def guardar_doctor():
    nombre = entry_nombre.get()
    especialidad = entry_especialidad.get()
    experiencia = entry_experiencia.get()
    correo = entry_correo.get()
    telefono = entry_telefono.get()
    hospital = entry_hospital.get()

    if not (nombre and especialidad and experiencia.isdigit() and correo and telefono and hospital):
        messagebox.showwarning("Error", "Complete todos los campos correctamente.")
        return

    experiencia = int(experiencia)
    doctores[nombre] = Doctor(nombre, especialidad, experiencia, correo, telefono, hospital)
    messagebox.showinfo("Guardado", f"Doctor {nombre} guardado exitosamente.")
    limpiar_campos()

def limpiar_campos():
    entry_nombre.delete(0, tk.END)
    entry_especialidad.delete(0, tk.END)
    entry_experiencia.delete(0, tk.END)
    entry_correo.delete(0, tk.END)
    entry_telefono.delete(0, tk.END)
    entry_hospital.delete(0, tk.END)

def buscar_doctor():
    nombre = entry_busqueda.get()
    if nombre in doctores:
        global doctor_actual
        doctor_actual = doctores[nombre]
        label_info.config(text=doctor_actual.mostrar_informacion())
    else:
        label_info.config(text="❌ Doctor no encontrado.")
        doctor_actual = None

def atender():
    if doctor_actual:
        paciente = entry_paciente.get()
        if paciente:
            label_info.config(text=doctor_actual.atender_paciente(paciente))
        else:
            messagebox.showwarning("Paciente", "Ingresa el nombre del paciente.")

def calcular_salario():
    if doctor_actual:
        label_info.config(text=doctor_actual.calcular_salario())

def recetar():
    if doctor_actual:
        medicamento = entry_medicamento.get()
        if medicamento:
            label_info.config(text=doctor_actual.recetar_medicamento(medicamento))
        else:
            messagebox.showwarning("Medicamento", "Ingresa un medicamento.")

# Interfaz
ventana = tk.Tk()
ventana.title("Gestión de Doctores")
ventana.geometry("600x600")
ventana.configure(bg="#f0faff")

frame = tk.Frame(ventana, bg="#f0faff")
frame.pack(padx=10, pady=10, anchor="w")

# Registro
tk.Label(frame, text="📝 Registrar Doctor", bg="#f0faff", font=("Arial", 12, "bold")).pack(anchor="w")

def crear_campo(label):
    tk.Label(frame, text=label, bg="#f0faff").pack(anchor="w")
    e = tk.Entry(frame, width=30)
    e.pack(anchor="w", pady=2)
    return e

entry_nombre = crear_campo("Nombre:")
entry_especialidad = crear_campo("Especialidad:")
entry_experiencia = crear_campo("Experiencia (años):")
entry_correo = crear_campo("Correo:")
entry_telefono = crear_campo("Teléfono:")
entry_hospital = crear_campo("Hospital:")

tk.Button(frame, text="Guardar Doctor", bg="#007acc", fg="white", command=guardar_doctor).pack(anchor="w", pady=5)

# Búsqueda
tk.Label(frame, text="🔍 Buscar Doctor:", bg="#f0faff", font=("Arial", 10, "bold")).pack(anchor="w", pady=(10, 0))
entry_busqueda = tk.Entry(frame, width=30)
entry_busqueda.pack(anchor="w", pady=2)
tk.Button(frame, text="Buscar", bg="#00796b", fg="white", command=buscar_doctor).pack(anchor="w", pady=5)

# Información
label_info = tk.Label(frame, text="Aquí aparecerá la información del doctor.", bg="#e0f7fa", width=60, height=6, anchor="nw", justify="left", font=("Arial", 9))
label_info.pack(anchor="w", pady=5)

# Acciones
tk.Label(frame, text="👤 Paciente:", bg="#f0faff").pack(anchor="w")
entry_paciente = tk.Entry(frame, width=30)
entry_paciente.pack(anchor="w", pady=2)
tk.Button(frame, text="Atender", bg="#009688", fg="white", command=atender).pack(anchor="w", pady=5)

tk.Button(frame, text="Calcular Salario", bg="#009688", fg="white", command=calcular_salario).pack(anchor="w", pady=5)

tk.Label(frame, text="💊 Medicamento:", bg="#f0faff").pack(anchor="w")
entry_medicamento = tk.Entry(frame, width=30)
entry_medicamento.pack(anchor="w", pady=2)
tk.Button(frame, text="Recetar", bg="#26a69a", fg="white", command=recetar).pack(anchor="w", pady=5)

doctor_actual = None
ventana.mainloop()
