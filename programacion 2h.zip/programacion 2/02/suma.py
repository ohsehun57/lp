class suma:
    def __init__(self,longitud,ancho):
        self.longitud=longitud
        self.ancho=ancho
        self.resul=self.longitud+self.ancho
        print(f"constructor: rectangulo creado con longitud {longitud} y ancho {ancho}

    def mostrar_resultado(self):
        print(f"es resultado de la suma es : {self.resul}")
        

    def __del__(self):
        print(f"destructor:   se elimino la suma de {self.a} + {self.b}")


a=int(input("ingrese la longitud:"))
b=int(input("ingrese el ancho:"))
sss = suma(a,b) 
sss.mostrar_resultado()

rectangulo__del__()