class cuentabancaria:
    def __init__(self,titular,saldo):
        self._titular=titular
        self._saldo=saldo
        
    def consultar_saldo(self):
        print(f"saldo actual de {self._titular}: s/. {self._saldo: .2f}")

    def agregar_mas_platita(self,monto):
        if monto>0:
            self._saldo+=monto
            print(f"Deposito de s/ . {monto: .2f} realizado con exito")
        else:
            print("El monto a depositar debe ser positivo")

    def retirar(self,monto):
        if 0<monto<=self._saldo:
            self._saldo-=monto
            print(f"retiro de S/. {monto: .2f} realizado con exito.")
        else:
            print("fondos insuficientes o mont invalida .")

cuenta =cuentabancaria("Raul",500.00)
cuenta.consultar_saldo()
cuenta.agregar_mas_platita(150)
cuenta.consultar_saldo()
cuenta.retirar(100)
cuenta.consultar_saldo