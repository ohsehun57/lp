class Recta:
    def __init__(self, base, altura):
        self.__base = base
        self.__altura = altura

    # Getter para base
    def obtener_base(self):
        return self.__base

    # Getter para altura
    def obtener_altura(self):
        return self.__altura 

    # Setter para base
    def establecer_base(self, nueva_base):
        if nueva_base > 0:
            self.__base = nueva_base
        else:
            print("Base no válida")

    # Setter para altura
    def establecer_altura(self, nueva_altura):
        if nueva_altura > 0:
            self.__altura = nueva_altura
        else:
            print("Altura no válida")

    # Método para verificar si la base es positiva
    def es_men(self):
        return self.__base > 0

    # Método para mostrar los datos
    def mostrar_datos(self):
        print(f"Base: {self.__base}, Altura: {self.__altura}")

    # Método para calcular el área
    def calcular_area(self):
        return self.__base * self.__altura

    # Método para calcular el perímetro
    def calcular_perimetro(self):
        return 2 * (self.__base + self.__altura)


# Crear un objeto de la clase Recta
recta1 = Recta(2, 3)

# Mostrar datos
recta1.mostrar_datos()

# Calcular y mostrar área y perímetro
print("Área:", recta1.calcular_area())
print("Perímetro:", recta1.calcular_perimetro())

# Cambiar valores con setters
recta1.establecer_base(5)
recta1.establecer_altura(4)
recta1.mostrar_datos()

# Verificar si la base es válida
print("Es base positiva?", recta1.es_men())
