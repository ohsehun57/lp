                         
import os
from PIL import Image, UnidentifiedImageError, ImageTk
from fpdf import FPDF
import tkinter as tk
from tkinter import filedialog, messagebox, ttk, simpledialog
import shutil
from io import BytesIO
import tempfile

class ImageToPDFConverterApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Convertidor Avanzado de Imágenes a PDF")
        self.geometry("800x600")
        self.minsize(700, 500)
        self.configure(bg="#f0f0f0")

        self.ruta_carpeta = ""
        self.imagenes = []
        self.thumbnails = {}  # Almacenamiento de miniaturas
        self.selected_images = []  # Para almacenar las imágenes seleccionadas
        self.preview_image = None  # Para mantener referencia a la imagen previsualizada

        # Variables de configuración
        self.calidad_pdf = tk.IntVar(value=90)  # Calidad por defecto: 90%
        self.modo_pdf = tk.StringVar(value="individual")  # individual o combinado
        
        self.create_widgets()
        self.create_menu()

    def create_menu(self):
        # Crear menú principal
        menu_principal = tk.Menu(self)
        self.config(menu=menu_principal)
        
        # Menú Archivo
        menu_archivo = tk.Menu(menu_principal, tearoff=0)
        menu_principal.add_cascade(label="Archivo", menu=menu_archivo)
        menu_archivo.add_command(label="Seleccionar carpeta", command=self.seleccionar_carpeta)
        menu_archivo.add_command(label="Seleccionar imágenes", command=self.seleccionar_imagenes)
        menu_archivo.add_separator()
        menu_archivo.add_command(label="Salir", command=self.quit)
        
        # Menú Opciones
        menu_opciones = tk.Menu(menu_principal, tearoff=0)
        menu_principal.add_cascade(label="Opciones", menu=menu_opciones)
        menu_opciones.add_command(label="Configurar calidad", command=self.configurar_calidad)
        menu_opciones.add_command(label="Añadir contraseña al PDF", command=self.configurar_password)
        
        # Menú Ayuda
        menu_ayuda = tk.Menu(menu_principal, tearoff=0)
        menu_principal.add_cascade(label="Ayuda", menu=menu_ayuda)
        menu_ayuda.add_command(label="Acerca de", command=self.mostrar_acerca_de)

    def create_widgets(self):
        # Frame principal que contiene todo
        main_frame = tk.Frame(self, bg="#f0f0f0")
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Título
        titulo = tk.Label(main_frame, text="Convertidor Avanzado de Imágenes a PDF", 
                        font=("Helvetica", 16, "bold"), bg="#f0f0f0", fg="#333")
        titulo.pack(pady=10)

        # Frame para botones superiores
        btn_frame = tk.Frame(main_frame, bg="#f0f0f0")
        btn_frame.pack(fill=tk.X, pady=5)
        
        # Botones de acción
        btn_seleccionar = tk.Button(btn_frame, text="Seleccionar Carpeta", 
                                   command=self.seleccionar_carpeta, 
                                   bg="#4CAF50", fg="white", font=("Arial", 11),
                                   padx=10, pady=5)
        btn_seleccionar.pack(side=tk.LEFT, padx=5)
        
        btn_sel_archivos = tk.Button(btn_frame, text="Seleccionar Imágenes", 
                                   command=self.seleccionar_imagenes, 
                                   bg="#3F51B5", fg="white", font=("Arial", 11),
                                   padx=10, pady=5)
        btn_sel_archivos.pack(side=tk.LEFT, padx=5)
        
        btn_limpiar = tk.Button(btn_frame, text="Limpiar Lista", 
                               command=self.limpiar_lista, 
                               bg="#f44336", fg="white", font=("Arial", 11),
                               padx=10, pady=5)
        btn_limpiar.pack(side=tk.RIGHT, padx=5)

        # Frame para contenido principal (lista y previsualización)
        content_frame = tk.Frame(main_frame, bg="#f0f0f0")
        content_frame.pack(fill=tk.BOTH, expand=True, pady=10)
        
        # Frame izquierdo para lista de imágenes
        list_frame = tk.Frame(content_frame, bg="#f0f0f0", width=350)
        list_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 5))
        
        # Label para la lista
        tk.Label(list_frame, text="Imágenes disponibles:", bg="#f0f0f0", 
                font=("Arial", 11, "bold")).pack(anchor=tk.W, pady=(0, 5))
        
        # Frame para la lista y su scrollbar
        listbox_frame = tk.Frame(list_frame, bg="#f0f0f0")
        listbox_frame.pack(fill=tk.BOTH, expand=True)
        
        # Lista de archivos encontrados
        self.lista_imagenes = tk.Listbox(listbox_frame, width=50, height=15, 
                                        font=("Arial", 10), selectmode=tk.EXTENDED)
        self.lista_imagenes.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self.lista_imagenes.bind("<<ListboxSelect>>", self.mostrar_preview)
        self.lista_imagenes.bind("<Button-3>", self.mostrar_menu_contextual)
        
        # Scroll para la lista
        scrollbar_y = tk.Scrollbar(listbox_frame, orient=tk.VERTICAL)
        scrollbar_y.config(command=self.lista_imagenes.yview)
        self.lista_imagenes.config(yscrollcommand=scrollbar_y.set)
        scrollbar_y.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Frame para botones de reordenamiento
        orden_frame = tk.Frame(list_frame, bg="#f0f0f0")
        orden_frame.pack(fill=tk.X, pady=5)
        
        # Botones para reordenar imágenes
        btn_subir = tk.Button(orden_frame, text="↑", command=self.mover_arriba,
                            bg="#607D8B", fg="white", font=("Arial", 11), width=3)
        btn_subir.pack(side=tk.LEFT, padx=5)
        
        btn_bajar = tk.Button(orden_frame, text="↓", command=self.mover_abajo,
                            bg="#607D8B", fg="white", font=("Arial", 11), width=3)
        btn_bajar.pack(side=tk.LEFT, padx=5)
        
        # Frame derecho para previsualización
        preview_frame = tk.Frame(content_frame, bg="#e0e0e0", width=350)
        preview_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=(5, 0))
        
        # Label para la previsualización
        tk.Label(preview_frame, text="Vista previa:", bg="#e0e0e0", 
                font=("Arial", 11, "bold")).pack(anchor=tk.W, pady=(0, 5), padx=5)
        
        # Canvas para la previsualización de imagen
        self.preview_canvas = tk.Canvas(preview_frame, bg="white", relief=tk.SUNKEN, bd=1)
        self.preview_canvas.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Frame inferior para las opciones de conversión
        options_frame = tk.Frame(main_frame, bg="#f0f0f0")
        options_frame.pack(fill=tk.X, pady=10)
        
        # Opciones de modo de conversión
        tk.Label(options_frame, text="Modo de conversión:", 
                bg="#f0f0f0", font=("Arial", 11)).pack(side=tk.LEFT, padx=(0, 10))
        
        # Radiobuttons para seleccionar modo
        rb_individual = tk.Radiobutton(options_frame, text="Un PDF por imagen", 
                                    variable=self.modo_pdf, value="individual",
                                    bg="#f0f0f0", font=("Arial", 10))
        rb_individual.pack(side=tk.LEFT, padx=5)
        
        rb_combinado = tk.Radiobutton(options_frame, text="Todas en un solo PDF", 
                                    variable=self.modo_pdf, value="combinado",
                                    bg="#f0f0f0", font=("Arial", 10))
        rb_combinado.pack(side=tk.LEFT, padx=5)
        
        # Frame para botones inferiores
        bottom_frame = tk.Frame(main_frame, bg="#f0f0f0")
        bottom_frame.pack(fill=tk.X, pady=5)
        
        # Botón convertir
        self.btn_convertir = tk.Button(bottom_frame, text="Convertir Imágenes a PDF", 
                                    command=self.convertir_imagenes, state=tk.DISABLED, 
                                    bg="#2196F3", fg="white", font=("Arial", 12), 
                                    padx=15, pady=8)
        self.btn_convertir.pack(pady=5)
        
        # Barra de progreso
        self.progress_bar = ttk.Progressbar(bottom_frame, orient="horizontal", 
                                          length=300, mode="determinate")
        self.progress_bar.pack(pady=5, fill=tk.X)
        
        # Etiqueta de estado
        self.etiqueta_estado = tk.Label(bottom_frame, text="", 
                                      bg="#f0f0f0", fg="#555", font=("Arial", 10))
        self.etiqueta_estado.pack(pady=5)

        # Crear el menú contextual para la lista
        self.menu_contextual = tk.Menu(self, tearoff=0)
        self.menu_contextual.add_command(label="Eliminar seleccionados", command=self.eliminar_seleccionados)
        self.menu_contextual.add_command(label="Ver imagen", command=self.ver_imagen_completa)

        # Inicialmente deshabilitar algunos botones
        self.password = None  # Inicialmente sin contraseña

    def seleccionar_carpeta(self):
        carpeta = filedialog.askdirectory(title="Selecciona la carpeta con imágenes")
        if carpeta:
            self.ruta_carpeta = carpeta
            self.cargar_imagenes_carpeta()

    def seleccionar_imagenes(self):
        archivos = filedialog.askopenfilenames(
            title="Selecciona imágenes",
            filetypes=[("Imágenes", "*.jpg *.jpeg *.png *.bmp *.gif *.tiff")]
        )
        if archivos:
            for archivo in archivos:
                nombre_archivo = os.path.basename(archivo)
                # Evitar duplicados
                if nombre_archivo not in self.imagenes:
                    self.imagenes.append(archivo)  # Guardamos la ruta completa
                    self.lista_imagenes.insert(tk.END, nombre_archivo)
            
            if self.imagenes:
                self.etiqueta_estado.config(text=f"{len(self.imagenes)} imágenes seleccionadas.")
                self.btn_convertir.config(state=tk.NORMAL)
                self.generar_thumbnails()

    def cargar_imagenes_carpeta(self):
        self.limpiar_lista()  # Limpiar lista primero
        archivos = os.listdir(self.ruta_carpeta)
        for archivo in archivos:
            if archivo.lower().endswith(('.jpg', '.jpeg', '.png', '.bmp', '.gif', '.tiff')):
                ruta_completa = os.path.join(self.ruta_carpeta, archivo)
                self.imagenes.append(ruta_completa)
                self.lista_imagenes.insert(tk.END, archivo)
        
        if self.imagenes:
            self.etiqueta_estado.config(text=f"{len(self.imagenes)} imágenes encontradas.")
            self.btn_convertir.config(state=tk.NORMAL)
            self.generar_thumbnails()
        else:
            self.etiqueta_estado.config(text="No se encontraron imágenes en la carpeta seleccionada.")
            self.btn_convertir.config(state=tk.DISABLED)

    def generar_thumbnails(self):
        # Generar miniaturas para previsualización rápida
        self.thumbnails = {}
        for ruta_imagen in self.imagenes:
            try:
                with Image.open(ruta_imagen) as img:
                    img.thumbnail((300, 300))  # Tamaño de miniatura
                    # Guardar la miniatura en memoria
                    self.thumbnails[ruta_imagen] = ImageTk.PhotoImage(img)
            except Exception as e:
                print(f"Error al generar miniatura para {ruta_imagen}: {e}")

    def mostrar_preview(self, event=None):
        indices = self.lista_imagenes.curselection()
        if indices:
            # Mostrar solo la primera imagen seleccionada
            indice = indices[0]
            if indice < len(self.imagenes):
                ruta_imagen = self.imagenes[indice]
                self.mostrar_imagen_en_canvas(ruta_imagen)

    def mostrar_imagen_en_canvas(self, ruta_imagen):
        # Limpiar canvas
        self.preview_canvas.delete("all")
        
        # Cargar miniatura o generarla si no existe
        if ruta_imagen not in self.thumbnails:
            try:
                with Image.open(ruta_imagen) as img:
                    img.thumbnail((300, 300))
                    self.thumbnails[ruta_imagen] = ImageTk.PhotoImage(img)
            except Exception as e:
                self.preview_canvas.create_text(150, 150, text=f"Error al cargar imagen: {e}", 
                                              width=280, anchor=tk.CENTER)
                return
        
        # Obtener dimensiones del canvas
        canvas_width = self.preview_canvas.winfo_width()
        canvas_height = self.preview_canvas.winfo_height()
        
        # Si el canvas no tiene tamaño aún, usar un valor por defecto
        if canvas_width <= 1:
            canvas_width = 300
        if canvas_height <= 1:
            canvas_height = 300
        
        # Mostrar la imagen en el centro del canvas
        img = self.thumbnails[ruta_imagen]
        self.preview_image = img  # Mantener referencia
        x = (canvas_width - img.width())/2
        y = (canvas_height - img.height())/2
        self.preview_canvas.create_image(x, y, image=img, anchor=tk.NW)
        
        # Mostrar nombre del archivo
        nombre = os.path.basename(ruta_imagen)
        self.preview_canvas.create_text(canvas_width/2, 20, text=nombre, anchor=tk.N,
                                      font=("Arial", 9), fill="blue")

    def mostrar_menu_contextual(self, event):
        # Mostrar menú contextual al hacer clic derecho en la lista
        try:
            self.menu_contextual.tk_popup(event.x_root, event.y_root)
        finally:
            self.menu_contextual.grab_release()

    def eliminar_seleccionados(self):
        indices = list(self.lista_imagenes.curselection())
        if not indices:
            return
        
        # Eliminar elementos en orden inverso para evitar problemas con los índices
        indices.sort(reverse=True)
        for i in indices:
            del self.imagenes[i]
            self.lista_imagenes.delete(i)
        
        self.etiqueta_estado.config(text=f"{len(self.imagenes)} imágenes restantes.")
        if not self.imagenes:
            self.btn_convertir.config(state=tk.DISABLED)

    def ver_imagen_completa(self):
        indices = self.lista_imagenes.curselection()
        if not indices:
            return
            
        ruta_imagen = self.imagenes[indices[0]]
        
        # Crear una ventana emergente para ver la imagen
        ventana = tk.Toplevel(self)
        ventana.title(os.path.basename(ruta_imagen))
        
        # Crear un canvas scrollable para la imagen
        frame = tk.Frame(ventana)
        frame.pack(fill=tk.BOTH, expand=True)
        
        # Scrollbars
        h_scrollbar = tk.Scrollbar(frame, orient=tk.HORIZONTAL)
        h_scrollbar.pack(side=tk.BOTTOM, fill=tk.X)
        
        v_scrollbar = tk.Scrollbar(frame)
        v_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Canvas
        canvas = tk.Canvas(frame, xscrollcommand=h_scrollbar.set, yscrollcommand=v_scrollbar.set)
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        # Configurar scrollbars
        h_scrollbar.config(command=canvas.xview)
        v_scrollbar.config(command=canvas.yview)
        
        # Cargar imagen
        try:
            with Image.open(ruta_imagen) as img:
                # Limitar el tamaño máximo para que no sea demasiado grande
                max_size = (1200, 800)
                img.thumbnail(max_size)
                photo = ImageTk.PhotoImage(img)
                
                # Añadir imagen al canvas
                canvas.create_image(0, 0, image=photo, anchor=tk.NW)
                
                # Configurar región de scroll
                canvas.config(scrollregion=canvas.bbox(tk.ALL))
                
                # Mantener referencia a la imagen
                ventana.photo = photo
                
                # Ajustar tamaño de ventana
                ventana.geometry(f"{min(img.width+30, 1200)}x{min(img.height+30, 800)}")
                
        except Exception as e:
            tk.Label(ventana, text=f"Error al abrir la imagen: {e}").pack(padx=20, pady=20)

    def mover_arriba(self):
        indices = list(self.lista_imagenes.curselection())
        if not indices or 0 in indices:
            return
            
        for i in sorted(indices):
            # Intercambiar en la lista de imágenes
            self.imagenes[i], self.imagenes[i-1] = self.imagenes[i-1], self.imagenes[i]
            
            # Intercambiar en el listbox
            texto = self.lista_imagenes.get(i)
            self.lista_imagenes.delete(i)
            self.lista_imagenes.insert(i-1, texto)
            self.lista_imagenes.selection_clear(0, tk.END)
            self.lista_imagenes.selection_set(i-1)

    def mover_abajo(self):
        indices = list(self.lista_imagenes.curselection())
        if not indices or len(self.imagenes)-1 in indices:
            return
            
        # Ordenar en reversa para evitar problemas al mover hacia abajo
        for i in sorted(indices, reverse=True):
            if i < len(self.imagenes) - 1:
                # Intercambiar en la lista de imágenes
                self.imagenes[i], self.imagenes[i+1] = self.imagenes[i+1], self.imagenes[i]
                
                # Intercambiar en el listbox
                texto = self.lista_imagenes.get(i)
                self.lista_imagenes.delete(i)
                self.lista_imagenes.insert(i+1, texto)
                self.lista_imagenes.selection_clear(0, tk.END)
                self.lista_imagenes.selection_set(i+1)

    def configurar_calidad(self):
        calidad = simpledialog.askinteger("Configurar calidad", 
                                         "Ingresa la calidad de imagen (1-100):", 
                                         minvalue=1, maxvalue=100, 
                                         initialvalue=self.calidad_pdf.get())
        if calidad is not None:
            self.calidad_pdf.set(calidad)
            self.etiqueta_estado.config(text=f"Calidad configurada: {calidad}%")

    def configurar_password(self):
        password = simpledialog.askstring("Protección PDF", 
                                        "Ingresa una contraseña para proteger el PDF\n(Deja en blanco para no usar contraseña):", 
                                        show='*')
        if password is not None:  # Si el usuario no cancela el diálogo
            self.password = password if password.strip() else None
            if self.password:
                self.etiqueta_estado.config(text="Se añadirá protección por contraseña al PDF")
            else:
                self.etiqueta_estado.config(text="PDF sin protección por contraseña")

    def mostrar_acerca_de(self):
        messagebox.showinfo("Acerca de", 
                          "Convertidor Avanzado de Imágenes a PDF\n"
                          "Versión 2.0\n\n"
                          "Esta aplicación permite convertir imágenes a formato PDF con opciones avanzadas.\n\n"
                          "Características:\n"
                          "• Conversión individual o combinada\n"
                          "• Reordenamiento de imágenes\n"
                          "• Vista previa\n"
                          "• Protección por contraseña\n"
                          "• Ajuste de calidad")

    def convertir_imagenes(self):
        if not self.imagenes:
            messagebox.showwarning("Advertencia", "No hay imágenes para convertir.")
            return
            
        # Deshabilitar botón durante la conversión
        self.btn_convertir.config(state=tk.DISABLED)
        self.etiqueta_estado.config(text="Procesando...")
        self.progress_bar["value"] = 0
        self.update_idletasks()
        
        # Comprobar el modo de conversión
        if self.modo_pdf.get() == "combinado":
            self.convertir_a_pdf_combinado()
        else:
            self.convertir_a_pdf_individual()

    def convertir_a_pdf_individual(self):
        errores = []
        total = len(self.imagenes)
        
        for i, ruta_imagen in enumerate(self.imagenes):
            # Actualizar barra de progreso
            self.progress_bar["value"] = (i / total) * 100
            self.etiqueta_estado.config(text=f"Convirtiendo imagen {i+1} de {total}...")
            self.update_idletasks()
            
            try:
                # Verificar si la ruta está completa o es relativa
                if os.path.isfile(ruta_imagen):
                    imagen_path = ruta_imagen
                else:
                    # Si es un nombre de archivo, buscar en la carpeta seleccionada
                    imagen_path = os.path.join(self.ruta_carpeta, ruta_imagen)
                
                nombre_base = os.path.splitext(os.path.basename(ruta_imagen))[0]
                # Crear un diálogo para seleccionar dónde guardar el PDF
                if i == 0:  # Solo preguntar para la primera imagen
                    carpeta_destino = filedialog.askdirectory(
                        title="Selecciona dónde guardar los PDFs"
                    )
                    if not carpeta_destino:  # Si el usuario cancela
                        self.btn_convertir.config(state=tk.NORMAL)
                        self.etiqueta_estado.config(text="Conversión cancelada.")
                        return
                
                nombre_pdf = os.path.join(carpeta_destino, f"{nombre_base}.pdf")
                
                # Abrir y procesar la imagen
                with Image.open(imagen_path) as imagen:
                    # Convertir la imagen a RGB si es necesario
                    if imagen.mode != "RGB":
                        imagen = imagen.convert("RGB")
                    
                    ancho, alto = imagen.size
                    
                    # Crear PDF
                    pdf = FPDF(unit="pt", format=[ancho, alto])
                    pdf.add_page()
                    pdf.image(imagen_path, 0, 0, ancho, alto)
                    
                    # Si hay contraseña, proteger el PDF
                    if self.password:
                        # Nota: FPDF no soporta directamente protección con contraseña
                        # Esta es una implementación ficticia, en la realidad
                        # necesitarías usar otra biblioteca como PyPDF2
                        pass
                    
                    pdf.output(nombre_pdf, "F")
                
            except FileNotFoundError:
                errores.append(f"No se encontró la imagen '{os.path.basename(ruta_imagen)}'.")
            except UnidentifiedImageError:
                errores.append(f"No se pudo abrir la imagen '{os.path.basename(ruta_imagen)}'.")
            except Exception as e:
                errores.append(f"Error con '{os.path.basename(ruta_imagen)}': {str(e)}")
        
        # Completar la barra de progreso
        self.progress_bar["value"] = 100
        self.update_idletasks()
        
        # Mostrar resultados
        if errores:
            mensaje_error = "Se produjeron algunos errores:\n" + "\n".join(errores)
            messagebox.showerror("Errores durante la conversión", mensaje_error)
        else:
            messagebox.showinfo("Éxito", f"Se han convertido {total} imágenes a PDF correctamente.")
        
        self.etiqueta_estado.config(text="Proceso completado.")
        self.btn_convertir.config(state=tk.NORMAL)

    def convertir_a_pdf_combinado(self):
        if not self.imagenes:
            return
            
        # Solicitar al usuario el nombre y ubicación para guardar el PDF combinado
        archivo_pdf = filedialog.asksaveasfilename(
            title="Guardar PDF combinado como",
            defaultextension=".pdf",
            filetypes=[("Archivos PDF", "*.pdf")]
        )
        
        if not archivo_pdf:  # Si el usuario cancela
            self.btn_convertir.config(state=tk.NORMAL)
            self.etiqueta_estado.config(text="Conversión cancelada.")
            return
            
        errores = []
        total = len(self.imagenes)
        
        try:
            # Crear PDF con páginas de tamaño variable según cada imagen
            pdf = FPDF()
            
            for i, ruta_imagen in enumerate(self.imagenes):
                # Actualizar barra de progreso
                self.progress_bar["value"] = (i / total) * 100
                self.etiqueta_estado.config(text=f"Añadiendo imagen {i+1} de {total} al PDF...")
                self.update_idletasks()
                
                try:
                    # Cargar imagen
                    with Image.open(ruta_imagen) as imagen:
                        # Convertir a RGB si es necesario
                        if imagen.mode != "RGB":
                            imagen = imagen.convert("RGB")
                            
                        ancho, alto = imagen.size
                        # Definir formato de página según el tamaño de la imagen
                        pdf.add_page(format=(ancho, alto))
                        pdf.image(ruta_imagen, 0, 0, ancho, alto)
                        
                except Exception as e:
                    errores.append(f"Error con '{os.path.basename(ruta_imagen)}': {str(e)}")
            
            # Guardar el PDF
            pdf.output(archivo_pdf, "F")
            
        except Exception as e:
            errores.append(f"Error general: {str(e)}")
        
        # Completar la barra de progreso
        self.progress_bar["value"] = 100
        self.update_idletasks()
        
        # Mostrar resultados
        if errores:
            mensaje_error = "Se produjeron algunos errores:\n" + "\n".join(errores)
            messagebox.showerror("Errores durante la conversión", mensaje_error)
        else:
            messagebox.showinfo("Éxito", f"Se ha creado el PDF combinado correctamente con {total} imágenes.")
        
        self.etiqueta_estado.config(text="Proceso completado.")
        self.btn_convertir.config(state=tk.NORMAL)

    def limpiar_lista(self):
        self.lista_imagenes.delete(0, tk.END)
        self.imagenes = []
        self.thumbnails = {}
        self.etiqueta_estado.config(text="")
        self.btn_convertir.config(state=tk.DISABLED)
        # Limpiar el canvas de previsualización
        self.preview_canvas.delete("all")

    def rotar_imagen(self):
        """Rota la imagen seleccionada 90 grados en sentido horario"""
        indices = self.lista_imagenes.curselection()
        if not indices:
            return
            
        # Obtener índice de la imagen seleccionada
        indice = indices[0]
        if indice >= len(self.imagenes):
            return
            
        ruta_imagen = self.imagenes[indice]
        try:
            # Crear un archivo temporal para la imagen rotada
            with tempfile.NamedTemporaryFile(delete=False, suffix=os.path.splitext(ruta_imagen)[1]) as tmp_file:
                temp_path = tmp_file.name
                
            # Abrir la imagen, rotarla y guardarla en el archivo temporal
            with Image.open(ruta_imagen) as img:
                img_rotada = img.rotate(-90, expand=True)  # -90 para rotación horaria
                img_rotada.save(temp_path)
                
            # Reemplazar la imagen original en la lista
            self.imagenes[indice] = temp_path
            
            # Actualizar la miniatura
            img_rotada.thumbnail((300, 300))
            self.thumbnails[temp_path] = ImageTk.PhotoImage(img_rotada)
            
            # Mostrar la imagen rotada
            self.mostrar_imagen_en_canvas(temp_path)
            
            self.etiqueta_estado.config(text="Imagen rotada 90° en sentido horario.")
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo rotar la imagen: {str(e)}")

    def comprimir_imagenes(self):
        """Comprime las imágenes antes de convertirlas a PDF"""
        if not self.imagenes:
            messagebox.showwarning("Advertencia", "No hay imágenes para comprimir.")
            return
            
        # Pedir al usuario el nivel de compresión
        nivel = simpledialog.askinteger("Nivel de compresión", 
                                      "Ingresa el nivel de compresión (1-100, menor = más compresión):", 
                                      minvalue=1, maxvalue=100, initialvalue=80)
        if nivel is None:  # Si el usuario cancela
            return
            
        # Deshabilitar botones durante la compresión
        self.btn_convertir.config(state=tk.DISABLED)
        self.etiqueta_estado.config(text="Comprimiendo imágenes...")
        self.progress_bar["value"] = 0
        self.update_idletasks()
        
        total = len(self.imagenes)
        nuevas_rutas = []
        
        # Crear directorio temporal para las imágenes comprimidas
        temp_dir = tempfile.mkdtemp()
        
        for i, ruta_imagen in enumerate(self.imagenes):
            # Actualizar progreso
            self.progress_bar["value"] = (i / total) * 100
            self.etiqueta_estado.config(text=f"Comprimiendo imagen {i+1} de {total}...")
            self.update_idletasks()
            
            try:
                # Abrir la imagen
                with Image.open(ruta_imagen) as img:
                    # Convertir a RGB si es necesario
                    if img.mode != "RGB":
                        img = img.convert("RGB")
                    
                    # Crear ruta para la imagen comprimida
                    nombre_base = os.path.splitext(os.path.basename(ruta_imagen))[0]
                    ruta_comprimida = os.path.join(temp_dir, f"{nombre_base}_comp.jpg")
                    
                    # Guardar con compresión JPEG
                    img.save(ruta_comprimida, "JPEG", quality=nivel)
                    nuevas_rutas.append(ruta_comprimida)
                    
                    # Actualizar la miniatura
                    img.thumbnail((300, 300))
                    self.thumbnails[ruta_comprimida] = ImageTk.PhotoImage(img)
                    
            except Exception as e:
                messagebox.showerror("Error", f"Error al comprimir {os.path.basename(ruta_imagen)}: {str(e)}")
        
        # Actualizar la lista de imágenes
        self.imagenes = nuevas_rutas
        
        # Actualizar el listbox
        self.lista_imagenes.delete(0, tk.END)
        for ruta in nuevas_rutas:
            self.lista_imagenes.insert(tk.END, os.path.basename(ruta))
        
        self.progress_bar["value"] = 100
        self.etiqueta_estado.config(text=f"Compresión completada. {total} imágenes comprimidas.")
        self.btn_convertir.config(state=tk.NORMAL)

    def agregar_marca_agua(self):
        """Agrega texto como marca de agua a las imágenes"""
        if not self.imagenes:
            messagebox.showwarning("Advertencia", "No hay imágenes para añadir marca de agua.")
            return
            
        # Pedir texto para la marca de agua
        texto = simpledialog.askstring("Marca de agua", "Ingresa el texto para la marca de agua:")
        if not texto:  # Si el usuario cancela o no ingresa texto
            return
            
        # Opciones para la marca de agua
        opciones = {
            "posición": tk.StringVar(value="centro"),
            "opacidad": tk.IntVar(value=30),  # 0-100%
            "color": "#ffffff",  # Blanco por defecto
            "tamaño": tk.IntVar(value=36)
        }
        
        # Ventana de configuración de marca de agua
        ventana = tk.Toplevel(self)
        ventana.title("Configurar marca de agua")
        ventana.geometry("400x300")
        ventana.resizable(False, False)
        
        tk.Label(ventana, text="Posición:").grid(row=0, column=0, padx=10, pady=10, sticky=tk.W)
        
        pos_frame = tk.Frame(ventana)
        pos_frame.grid(row=0, column=1, padx=10, pady=10)
        
        posiciones = [("Superior izquierda", "superior-izquierda"), 
                     ("Superior derecha", "superior-derecha"),
                     ("Centro", "centro"),
                     ("Inferior izquierda", "inferior-izquierda"),
                     ("Inferior derecha", "inferior-derecha")]
                     
        for i, (text, valor) in enumerate(posiciones):
            tk.Radiobutton(pos_frame, text=text, variable=opciones["posición"], 
                          value=valor).grid(row=i//2, column=i%2, sticky=tk.W)
        
        tk.Label(ventana, text="Opacidad:").grid(row=1, column=0, padx=10, pady=10, sticky=tk.W)
        tk.Scale(ventana, from_=10, to=90, orient=tk.HORIZONTAL, variable=opciones["opacidad"], 
                length=200).grid(row=1, column=1, padx=10, pady=10)
        
        tk.Label(ventana, text="Tamaño de fuente:").grid(row=2, column=0, padx=10, pady=10, sticky=tk.W)
        tk.Scale(ventana, from_=12, to=72, orient=tk.HORIZONTAL, variable=opciones["tamaño"], 
                length=200).grid(row=2, column=1, padx=10, pady=10)
        
        # Botón para aplicar marca de agua
        def aplicar():
            ventana.destroy()
            self.aplicar_marca_agua(texto, opciones)
            
        tk.Button(ventana, text="Aplicar", command=aplicar).grid(row=3, column=0, columnspan=2, pady=20)
        
        # Esperar a que se cierre la ventana
        self.wait_window(ventana)

    def aplicar_marca_agua(self, texto, opciones):
        """Aplica la marca de agua a las imágenes seleccionadas"""
        # Deshabilitar botones durante el proceso
        self.btn_convertir.config(state=tk.DISABLED)
        self.etiqueta_estado.config(text="Aplicando marca de agua...")
        self.progress_bar["value"] = 0
        self.update_idletasks()
        
        total = len(self.imagenes)
        nuevas_rutas = []
        temp_dir = tempfile.mkdtemp()
        
        for i, ruta_imagen in enumerate(self.imagenes):
            # Actualizar progreso
            self.progress_bar["value"] = (i / total) * 100
            self.etiqueta_estado.config(text=f"Procesando imagen {i+1} de {total}...")
            self.update_idletasks()
            
            try:
                # Abrir la imagen
                with Image.open(ruta_imagen) as img:
                    # Crear una copia para no modificar la original
                    img_marca = img.copy()
                    
                    # Crear capa para la marca de agua (transparente)
                    marca = Image.new('RGBA', img.size, (0, 0, 0, 0))
                    
                    # Preparar para dibujar en la capa
                    from PIL import ImageDraw, ImageFont
                    dibujo = ImageDraw.Draw(marca)
                    
                    # Intentar cargar una fuente, o usar la predeterminada
                    try:
                        fuente = ImageFont.truetype("arial.ttf", opciones["tamaño"].get())
                    except:
                        fuente = ImageFont.load_default()
                    
                    # Tamaño del texto
                    ancho_texto, alto_texto = dibujo.textsize(texto, font=fuente)
                    
                    # Posición según la opción seleccionada
                    posicion = opciones["posición"].get()
                    if posicion == "superior-izquierda":
                        pos = (20, 20)
                    elif posicion == "superior-derecha":
                        pos = (img.width - ancho_texto - 20, 20)
                    elif posicion == "inferior-izquierda":
                        pos = (20, img.height - alto_texto - 20)
                    elif posicion == "inferior-derecha":
                        pos = (img.width - ancho_texto - 20, img.height - alto_texto - 20)
                    else:  # centro
                        pos = ((img.width - ancho_texto) // 2, (img.height - alto_texto) // 2)
                    
                    # Dibujar texto en la capa (con transparencia)
                    opacidad = int(255 * opciones["opacidad"].get() / 100)
                    dibujo.text(pos, texto, fill=(255, 255, 255, opacidad), font=fuente)
                    
                    # Combinar las imágenes
                    if img_marca.mode != 'RGBA':
                        img_marca = img_marca.convert('RGBA')
                    
                    img_final = Image.alpha_composite(img_marca, marca)
                    
                    # Guardar con la marca de agua
                    nombre_base = os.path.splitext(os.path.basename(ruta_imagen))[0]
                    ruta_marcada = os.path.join(temp_dir, f"{nombre_base}_wm.png")
                    
                    img_final.convert('RGB').save(ruta_marcada)
                    nuevas_rutas.append(ruta_marcada)
                    
                    # Actualizar miniatura
                    img_temp = img_final.copy()
                    img_temp.thumbnail((300, 300))
                    self.thumbnails[ruta_marcada] = ImageTk.PhotoImage(img_temp)
                    
            except Exception as e:
                messagebox.showerror("Error", f"Error al añadir marca de agua a {os.path.basename(ruta_imagen)}: {str(e)}")
        
        # Actualizar la lista de imágenes
        self.imagenes = nuevas_rutas
        
        # Actualizar el listbox
        self.lista_imagenes.delete(0, tk.END)
        for ruta in nuevas_rutas:
            self.lista_imagenes.insert(tk.END, os.path.basename(ruta))
        
        self.progress_bar["value"] = 100
        self.etiqueta_estado.config(text=f"Marca de agua aplicada a {total} imágenes.")
        self.btn_convertir.config(state=tk.NORMAL)

    def ajustar_tamanho(self):
        """Ajusta el tamaño de las imágenes"""
        if not self.imagenes:
            messagebox.showwarning("Advertencia", "No hay imágenes para redimensionar.")
            return
            
        # Ventana para configurar el tamaño
        ventana = tk.Toplevel(self)
        ventana.title("Redimensionar imágenes")
        ventana.geometry("400x300")
        ventana.resizable(False, False)
        
        # Variables
        modo = tk.StringVar(value="porcentaje")
        porcentaje = tk.IntVar(value=50)
        ancho = tk.IntVar(value=800)
        alto = tk.IntVar(value=600)
        mantener_proporcion = tk.BooleanVar(value=True)
        
        # Widgets
        tk.Label(ventana, text="Modo de redimensionamiento:", font=("Arial", 11, "bold")).grid(
            row=0, column=0, columnspan=2, pady=(15,5), padx=10, sticky=tk.W)
        
        tk.Radiobutton(ventana, text="Por porcentaje", variable=modo, value="porcentaje").grid(
            row=1, column=0, padx=20, sticky=tk.W)
        
        tk.Radiobutton(ventana, text="Por dimensiones", variable=modo, value="dimensiones").grid(
            row=1, column=1, padx=20, sticky=tk.W)
        
        # Frame para opciones de porcentaje
        frame_porcentaje = tk.Frame(ventana)
        frame_porcentaje.grid(row=2, column=0, columnspan=2, pady=10, padx=20, sticky=tk.W+tk.E)
        
        tk.Label(frame_porcentaje, text="Escala (%):").pack(side=tk.LEFT)
        tk.Scale(frame_porcentaje, from_=10, to=200, orient=tk.HORIZONTAL, 
                variable=porcentaje, length=250).pack(side=tk.LEFT, padx=10)
        
        # Frame para opciones de dimensiones
        frame_dimension = tk.Frame(ventana)
        frame_dimension.grid(row=3, column=0, columnspan=2, pady=10, padx=20, sticky=tk.W+tk.E)
        
        tk.Label(frame_dimension, text="Ancho:").grid(row=0, column=0, padx=5, sticky=tk.W)
        tk.Entry(frame_dimension, textvariable=ancho, width=8).grid(row=0, column=1, padx=5, sticky=tk.W)
        
        tk.Label(frame_dimension, text="Alto:").grid(row=1, column=0, padx=5, pady=5, sticky=tk.W)
        tk.Entry(frame_dimension, textvariable=alto, width=8).grid(row=1, column=1, padx=5, pady=5, sticky=tk.W)
        
        tk.Checkbutton(frame_dimension, text="Mantener proporción", variable=mantener_proporcion).grid(
            row=2, column=0, columnspan=2, padx=5, pady=5, sticky=tk.W)
        
        # Botón para aplicar
        def aplicar():
            ventana.destroy()
            self.aplicar_redimension(modo.get(), porcentaje.get(), ancho.get(), alto.get(), mantener_proporcion.get())
            
        tk.Button(ventana, text="Aplicar", command=aplicar, bg="#4CAF50", fg="white", 
                 font=("Arial", 11), padx=20, pady=5).grid(
            row=4, column=0, columnspan=2, pady=20)
        
        # Esperar a que se cierre la ventana
        self.wait_window(ventana)

    def aplicar_redimension(self, modo, porcentaje, ancho, alto, mantener_proporcion):
        """Aplica el redimensionamiento a las imágenes"""
        # Deshabilitar botones durante el proceso
        self.btn_convertir.config(state=tk.DISABLED)
        self.etiqueta_estado.config(text="Redimensionando imágenes...")
        self.progress_bar["value"] = 0
        self.update_idletasks()
        
        total = len(self.imagenes)
        nuevas_rutas = []
        temp_dir = tempfile.mkdtemp()
        
        for i, ruta_imagen in enumerate(self.imagenes):
            # Actualizar progreso
            self.progress_bar["value"] = (i / total) * 100
            self.etiqueta_estado.config(text=f"Procesando imagen {i+1} de {total}...")
            self.update_idletasks()
            
            try:
                # Abrir la imagen
                with Image.open(ruta_imagen) as img:
                    # Calcular nuevas dimensiones
                    if modo == "porcentaje":
                        nuevo_ancho = int(img.width * porcentaje / 100)
                        nuevo_alto = int(img.height * porcentaje / 100)
                    else:  # dimensiones
                        if mantener_proporcion:
                            # Mantener relación de aspecto
                            ratio = min(ancho/img.width, alto/img.height)
                            nuevo_ancho = int(img.width * ratio)
                            nuevo_alto = int(img.height * ratio)
                        else:
                            nuevo_ancho = ancho
                            nuevo_alto = alto
                    
                    # Redimensionar
                    img_redim = img.resize((nuevo_ancho, nuevo_alto), Image.LANCZOS)
                    
                    # Guardar imagen redimensionada
                    nombre_base = os.path.splitext(os.path.basename(ruta_imagen))[0]
                    extension = os.path.splitext(ruta_imagen)[1]
                    if not extension:
                        extension = ".jpg"  # Predeterminado si no hay extensión
                        
                    ruta_redim = os.path.join(temp_dir, f"{nombre_base}_resized{extension}")
                    
                    # Convertir a RGB si es necesario
                    if img_redim.mode != "RGB" and extension.lower() in ('.jpg', '.jpeg'):
                        img_redim = img_redim.convert("RGB")
                        
                    img_redim.save(ruta_redim)
                    nuevas_rutas.append(ruta_redim)
                    
                    # Actualizar miniatura
                    img_temp = img_redim.copy()
                    img_temp.thumbnail((300, 300))
                    self.thumbnails[ruta_redim] = ImageTk.PhotoImage(img_temp)
                    
            except Exception as e:
                messagebox.showerror("Error", f"Error al redimensionar {os.path.basename(ruta_imagen)}: {str(e)}")
        
        # Actualizar la lista de imágenes
        self.imagenes = nuevas_rutas
        
        # Actualizar el listbox
        self.lista_imagenes.delete(0, tk.END)
        for ruta in nuevas_rutas:
            self.lista_imagenes.insert(tk.END, os.path.basename(ruta))
        
        self.progress_bar["value"] = 100
        self.etiqueta_estado.config(text=f"Redimensionamiento completado en {total} imágenes.")
        self.btn_convertir.config(state=tk.NORMAL)
        
if __name__ == "__main__":
    app = ImageToPDFConverterApp()
    app.mainloop()