import tkinter as tk
from tkinter import ttk, messagebox
import statistics

class Estudiante:
    def __init__(self, nombre, edad, carrera):
        self.nombre = nombre
        self.edad = edad
        self.carrera = carrera
        self.notas = []

    def agregar_nota(self, nota):
        self.notas.append(nota)

    def obtener_promedio(self):
        return sum(self.notas) / len(self.notas) if self.notas else 0

    def esta_aprobado(self):
        return self.obtener_promedio() >= 11

    def obtener_estadisticas(self):
        if not self.notas:
            return (0, 0, 0, 0)
        return (
            round(statistics.mean(self.notas), 2),
            round(statistics.median(self.notas), 2),
            round(min(self.notas), 2),
            round(max(self.notas), 2)
        )

class AppEstudiantes:
    def __init__(self, root):
        self.root = root
        self.root.title("Sistema Profesional de Registro de Estudiantes")
        self.root.geometry("1000x700")
        self.root.configure(bg="#f2f6fa")

        self.estudiantes = []

        self.estilo = ttk.Style()
        self.estilo.theme_use("clam")
        self.estilo.configure("Treeview",
            background="#ffffff",
            foreground="black",
            rowheight=30,
            fieldbackground="#ffffff"
        )
        self.estilo.configure("TLabel", font=("Segoe UI", 11))
        self.estilo.configure("TEntry", font=("Segoe UI", 11))
        self.estilo.configure("TButton", font=("Segoe UI", 11, "bold"))

        self.crear_widgets()

    def crear_widgets(self):
        titulo = ttk.Label(self.root, text="Registro de Estudiantes", font=("Segoe UI", 22, "bold"), background="#f2f6fa", foreground="#003366")
        titulo.pack(pady=20)

        marco_formulario = ttk.LabelFrame(self.root, text="Datos del Estudiante", padding=20)
        marco_formulario.pack(pady=10, padx=20, fill="x")

        ttk.Label(marco_formulario, text="Nombre:").grid(row=0, column=0, sticky="e", padx=5, pady=5)
        self.entry_nombre = ttk.Entry(marco_formulario, width=40)
        self.entry_nombre.grid(row=0, column=1, pady=5)

        ttk.Label(marco_formulario, text="Edad:").grid(row=1, column=0, sticky="e", padx=5, pady=5)
        self.entry_edad = ttk.Entry(marco_formulario, width=40)
        self.entry_edad.grid(row=1, column=1, pady=5)

        ttk.Label(marco_formulario, text="Carrera:").grid(row=2, column=0, sticky="e", padx=5, pady=5)
        self.entry_carrera = ttk.Entry(marco_formulario, width=40)
        self.entry_carrera.grid(row=2, column=1, pady=5)

        ttk.Label(marco_formulario, text="Notas (separadas por coma):").grid(row=3, column=0, sticky="e", padx=5, pady=5)
        self.entry_notas = ttk.Entry(marco_formulario, width=40)
        self.entry_notas.grid(row=3, column=1, pady=5)

        btn_registrar = ttk.Button(marco_formulario, text="Registrar Estudiante", command=self.registrar_estudiante)
        btn_registrar.grid(row=4, column=0, columnspan=2, pady=15)

        marco_tabla = ttk.LabelFrame(self.root, text="Lista de Estudiantes", padding=10)
        marco_tabla.pack(fill="both", expand=True, padx=20, pady=10)

        columnas = ("Nombre", "Edad", "Carrera", "Notas", "Promedio", "Aprobado")
        self.tree = ttk.Treeview(marco_tabla, columns=columnas, show="headings")

        for col in columnas:
            self.tree.heading(col, text=col)
            self.tree.column(col, anchor="center")

        self.tree.pack(fill="both", expand=True)

        self.marco_estadisticas = ttk.LabelFrame(self.root, text="Estadísticas Generales", padding=10)
        self.marco_estadisticas.pack(fill="x", padx=20, pady=10)

        self.label_estadisticas = ttk.Label(self.marco_estadisticas, text="Aún no hay estudiantes registrados.", background="#f2f6fa", font=("Segoe UI", 11))
        self.label_estadisticas.pack()

    def registrar_estudiante(self):
        nombre = self.entry_nombre.get().strip()
        edad = self.entry_edad.get().strip()
        carrera = self.entry_carrera.get().strip()
        notas_texto = self.entry_notas.get().strip()

        if not nombre or not edad or not carrera or not notas_texto:
            messagebox.showwarning("Campos incompletos", "Por favor, complete todos los campos.")
            return

        try:
            edad = int(edad)
            notas = [float(n.strip()) for n in notas_texto.split(",") if n.strip()]
        except ValueError:
            messagebox.showerror("Error", "Edad debe ser un número y las notas deben ser válidas separadas por coma.")
            return

        estudiante = Estudiante(nombre, edad, carrera)
        for nota in notas:
            estudiante.agregar_nota(nota)

        self.estudiantes.append(estudiante)
        self.actualizar_tabla()
        self.limpiar_entradas()
        self.actualizar_estadisticas_generales()

    def actualizar_tabla(self):
        for fila in self.tree.get_children():
            self.tree.delete(fila)

        for est in self.estudiantes:
            self.tree.insert("", tk.END, values=(
                est.nombre,
                est.edad,
                est.carrera,
                ", ".join(map(str, est.notas)),
                round(est.obtener_promedio(), 2),
                "SI" if est.esta_aprobado() else "NO"
            ))

    def limpiar_entradas(self):
        self.entry_nombre.delete(0, tk.END)
        self.entry_edad.delete(0, tk.END)
        self.entry_carrera.delete(0, tk.END)
        self.entry_notas.delete(0, tk.END)

    def actualizar_estadisticas_generales(self):
        if not self.estudiantes:
            self.label_estadisticas.config(text="Aún no hay estudiantes registrados.")
            return

        total_estudiantes = len(self.estudiantes)
        promedios = [est.obtener_promedio() for est in self.estudiantes if est.notas]
        aprobados = sum(1 for est in self.estudiantes if est.esta_aprobado())

        media = round(statistics.mean(promedios), 2) if promedios else 0
        mediana = round(statistics.median(promedios), 2) if promedios else 0
        minimo = round(min(promedios), 2) if promedios else 0
        maximo = round(max(promedios), 2) if promedios else 0
        porcentaje_aprobados = round((aprobados / total_estudiantes) * 100, 2) if total_estudiantes > 0 else 0

        texto_estadisticas = (
            f"Total de estudiantes: {total_estudiantes}\n"
            f"Promedio general: {media}\n"
            f"Mediana de promedios: {mediana}\n"
            f"Nota mínima: {minimo}\n"
            f"Nota máxima: {maximo}\n"
            f"Aprobados: {aprobados} ({porcentaje_aprobados}%)"
        )

        self.label_estadisticas.config(text=texto_estadisticas)

if __name__ == "__main__":
    root = tk.Tk()
    app = AppEstudiantes(root)
    root.mainloop()
