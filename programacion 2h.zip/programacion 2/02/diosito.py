import os
from PIL import Image
from fpdf import FPDF

def convertir_imagenes_a_pdf(ruta_carpeta):
    """
    Convierte todas las imágenes JPG y PNG en una carpeta a archivos PDF individuales.

    Args:
        ruta_carpeta (str): La ruta al directorio que contiene las imágenes.
    """
    try:
        if not os.path.isdir(ruta_carpeta):
            raise NotADirectoryError(f"La ruta proporcionada '{ruta_carpeta}' no es un directorio válido.")

        archivos = os.listdir(ruta_carpeta)
        imagenes = [archivo for archivo in archivos if archivo.lower().endswith(('.jpg', '.jpeg', '.png'))]

        if not imagenes:
            print(f"No se encontraron archivos JPG o PNG en la carpeta '{ruta_carpeta}'.")
            return

        for nombre_imagen in imagenes:
            ruta_imagen = os.path.join(ruta_carpeta, nombre_imagen)
            nombre_base, extension = os.path.splitext(nombre_imagen)
            nombre_pdf = os.path.join(ruta_carpeta, f"{nombre_base}.pdf")

            try:
                imagen = Image.open(ruta_imagen)
                ancho, alto = imagen.size

                pdf = FPDF(unit="pt", format=[ancho, alto])
                pdf.add_page()
                pdf.image(ruta_imagen, 0, 0, ancho, alto)
                pdf.output(nombre_pdf, "F")
                print(f"Se convirtió '{nombre_imagen}' a '{nombre_base}.pdf'")

            except FileNotFoundError:
                print(f"Error: No se pudo encontrar la imagen '{ruta_imagen}'.")
            except Image.UnidentifiedImageError:
                print(f"Error: No se pudo abrir o identificar el formato de la imagen '{ruta_imagen}'.")
            except Exception as e:
                print(f"Error inesperado al procesar '{nombre_imagen}': {e}")

    except NotADirectoryError as e:
        print(f"Error: {e}")
    except Exception as e:
        print(f"Error general: {e}")

if __name__ == "__main__":
    ruta_de_la_carpeta = input("Por favor, introduce la ruta de la carpeta con las fotos: ")
    convertir_imagenes_a_pdf(ruta_de_la_carpeta)
    print("Proceso completado.")