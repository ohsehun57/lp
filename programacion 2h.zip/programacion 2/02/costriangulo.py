class Triangulo:
    def __init__(self, base, altura, lado1, lado2):
        self.base = base
        self.altura = altura
        self.lado1 = lado1
        self.lado2 = lado2
        self.area = (self.base * self.altura) / 2
        self.perimetro = self.base + self.lado1 + self.lado2
        print(f"Constructor: se creó el área del triángulo {self.base} * {self.altura} / 2 = {self.area}")

    def mostrar_resultado(self):
        print(f"El resultado del área es: {self.area}")
        print(f"El resultado del perímetro es: {self.perimetro}")

    def __del__(self):
        print(f"Destructor: se eliminó el área del triángulo {self.base} * {self.altura} / 2 = {self.area}")
        print(f"Destructor: se eliminó el perímetro {self.base} + {self.lado1} + {self.lado2}")


base = int(input("Ingrese el valor de la base: "))
altura = int(input("Ingrese el valor de la altura: "))
lado1 = int(input("Ingrese el valor del lado1: "))
lado2 = int(input("Ingrese el valor del lado2: "))


triangulo1 = Triangulo(base, altura, lado1, lado2)
triangulo1.mostrar_resultado()
