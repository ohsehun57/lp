class Libro:
    def __init__(self, titulo, autor, paginas):
        self.titulo = titulo
        self.autor = autor
        self.paginas = paginas
    
    def leer(self, mensaje):
        print(f"{self.titulo} se está leyendo: {mensaje}")

    def marcar(self, numero):
        print(f"Se han marcado {numero} páginas en {self.titulo} de {self.autor}.")

    def prestar(self, horas):
        print(f"El libro '{self.titulo}' ha sido prestado por {horas} horas.")

# Creación de objetos
libro1 = Libro("POO", "Raúl Cristian", 452)
libro2 = Libro("Java", "Cristian Raúl", 456)

# Uso de métodos
print("\n---- Libro de programación ----")
libro1.leer("todas las páginas del libro")
libro1.marcar(5)
libro1.prestar(2)

print("\n---- Acciones de María ----")
libro2.leer("media hoja")
libro2.marcar(300)
libro2.prestar(7)
