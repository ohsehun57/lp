import math

class Ciudad:
    def __init__(self, nombre, x, y):
        self.nombre = nombre
        self.x = x
        self.y = y

    def distancia(self, otra_ciudad):
        dx = self.x - otra_ciudad.x
        dy = self.y - otra_ciudad.y
        return math.sqrt(dx**2 + dy**2)

# Ingreso de datos para la primera ciudad
nombre1 = input("Ingrese el nombre de la primera ciudad: ")
x1 = float(input(f"Ingrese la coordenada X de {nombre1}: "))
y1 = float(input(f"Ingrese la coordenada Y de {nombre1}: "))

# Ingreso de datos para la segunda ciudad
nombre2 = input("Ingrese el nombre de la segunda ciudad: ")
x2 = float(input(f"Ingrese la coordenada X de {nombre2}: "))
y2 = float(input(f"Ingrese la coordenada Y de {nombre2}: "))

# Crear objetos
ciudad1 = Ciudad(nombre1, x1, y1)
ciudad2 = Ciudad(nombre2, x2, y2)

# Crear referencias
ref1 = ciudad1
ref2 = ciudad2

# Calcular distancia
distancia_km = ref1.distancia(ref2)

# Mostrar resultado
print(f"\nLa distancia entre {ref1.nombre} y {ref2.nombre} es: {distancia_km:.2f} unidades")
