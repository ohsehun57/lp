import tkinter as tk

class CalculadoraBasica:
    def __init__(self, numero1, numero2):
        self.__numero1 = numero1
        self.__numero2 = numero2

    def suma(self):
        return self.__numero1 + self.__numero2

    def resta(self):
        return self.__numero1 - self.__numero2

    def multiplicacion(self):
        return self.__numero1 * self.__numero2

    def division(self):
        if self.__numero2 != 0:
            return self.__numero1 / self.__numero2
        else:
            return "Error: división entre cero"

    def raiz(self):
        try:
            return self.__numero1 ** 0.5
        except:
            return "Error"

    def potencia(self):
        return self.__numero1 ** self.__numero2

# Interfaz gráfica
def operar(op):
    try:
        a = float(entry1.get())
        b = float(entry2.get())
        calc = CalculadoraBasica(a, b)

        if op == "+":
            resultado = calc.suma()
        elif op == "-":
            resultado = calc.resta()
        elif op == "*":
            resultado = calc.multiplicacion()
        elif op == "/":
            resultado = calc.division()
        elif op == "√":
            resultado = calc.raiz()
        elif op == "pot":
            resultado = calc.potencia()
        else:
            resultado = "Operación inválida"

        resultado_var.set(f"Resultado: {resultado}")
    except:
        resultado_var.set("Error: solo números")

def limpiar():
    entry1.delete(0, tk.END)
    entry2.delete(0, tk.END)
    resultado_var.set("")

def salir():
    ventana.destroy()

ventana = tk.Tk()
ventana.title("Calculadora")
ventana.configure(bg="#f0f0f0")
ventana.resizable(False, False)

# Entrada de datos
tk.Label(ventana, text="Numero 1", bg="#f0f0f0").grid(row=0, column=0, padx=5, pady=5)
entry1 = tk.Entry(ventana, width=15)
entry1.grid(row=0, column=1, padx=5, pady=5)

tk.Label(ventana, text="Numero 2", bg="#f0f0f0").grid(row=0, column=2, padx=5, pady=5)
entry2 = tk.Entry(ventana, width=15)
entry2.grid(row=0, column=3, padx=5, pady=5)

# Botones de operaciones
botones = [
    ("+", 1, 0), ("-", 1, 1), ("*", 1, 2),
    ("/", 1, 3), ("√", 1, 4), ("pot", 1, 5)
]
for (text, fila, col) in botones:
    tk.Button(ventana, text=text, width=6, command=lambda t=text: operar(t)).grid(row=fila, column=col, padx=4, pady=4)

# Resultado
resultado_var = tk.StringVar()
resultado_label = tk.Entry(ventana, textvariable=resultado_var, state="readonly", width=40, justify="center")
resultado_label.grid(row=2, column=0, columnspan=4, padx=5, pady=10)

# Botones limpiar y salir
tk.Button(ventana, text="Limpiar", width=10, bg="lightblue", command=limpiar).grid(row=2, column=4, pady=10)
tk.Button(ventana, text="Salir", width=10, bg="red", fg="white", command=salir).grid(row=2, column=5, pady=10)

ventana.mainloop()
