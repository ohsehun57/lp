class producto: 
    def __init__(self,nombre,precio,stock):
        self.nombre=nombre
        self.precio=precio
        self.stock=stock

    def mostrar_informacion(self):
        print("\n=====Informacion del Producto=====")
        print("Nombre :",self.nombre)
        print("precio :",self.precio)
        print("stock :",self.stock)

    def actualizar_precio(self,nuevo_precio):
        self.precio=nuevo_precio
        print("\nPresio actualizado correctamente")

    def actualizar_stock(self,nuevo_stock):
        self.stock =nuevo_stock
        print("\nStock actualizado correctamente")

    def aplicar_descuento(self,porcentaje_descuento):
        descuento=self.precio*(porcentaje_descuento/100)
        self.precio -=descuento
        print(f"descuento del{porcentaje_descuento}% aplicado. Nuevo precio. S/. {self.precio}")

    def realizar_venta(self,cantidad):
        if cantidad<=self.stock:
            self.stock-=cantidad
            print(f"venta realizada:  {cantidad}:  unidades vendidas")
            print(f"Stock restante para realizar la venta")
        else:
            print(f"no hay suficiente stock para realizar la venta")

# funcion general para aplicar descuento a todos los productos
def aplicar_descuento_general(lista_productos, porcentaje):
    for p in lista_productos:
        p.aplicar_descuento(porcentaje)

#crear objetos de la clase producto
producto1=producto("Arroz",3.50,100)
producto2=producto("Azucar",4.50,50)
producto3=producto("Aceite",8.00,80)
producto4=producto("Leche",4.50,60)

#mostrar informacion de los productos
producto1.mostrar_informacion()
producto2.mostrar_informacion()
producto3.mostrar_informacion()
producto4.mostrar_informacion()

# aplicar descuento general del 10%
aplicar_descuento_general([producto1,producto2,producto3,producto4],10)

# mostrar nueva informacion
producto1.mostrar_informacion()
producto2.mostrar_informacion()
producto3.mostrar_informacion()
producto4.mostrar_informacion()

# realizar venta
producto1.realizar_venta(20)#vender 20 unidades
producto1.mostrar_informacion()

# intentar vender más unidades de las que hay en stock
producto1.realizar_venta(90)#intentar vender 90 unidades (no hay suficiente stock)
