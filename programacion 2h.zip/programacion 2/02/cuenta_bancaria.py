class CuentaBancaria:
    def __init__(self, titular, saldo):
        self.__titular = titular
        self.__saldo = saldo
        print(f"Cuenta creada para {self.__titular} con saldo inicial: S/. {self.__saldo:.2f}")

  
    def obtener_titular(self):
        return self.__titular


    def establecer_titular(self, nuevo_titular):
        if nuevo_titular:
            self.__titular = nuevo_titular
        else:
            print("Nombre de titular invalido.")

    def obtener_saldo(self):
        return self.__saldo

    
    def establecer_saldo(self, nuevo_saldo):
        if nuevo_saldo >= 0:
            self.__saldo = nuevo_saldo
        else:
            print("Saldo invalido.")

    def agregar_mas_platita(self, monto):
        if monto > 0:
            self.__saldo += monto
            print(f"Deposito de S/. {monto:.2f} realizado con exito.")
        else:
            print("El monto debe ser mayor que cero.")

    def retirar(self, monto):
        if 0 < monto <= self.__saldo:
            self.__saldo -= monto
            print(f"Retiro de S/. {monto:.2f} realizado con exito.")
        else:
            print("Fondos insuficientes o monto invalido.")

    def mostrar_info(self):
        print(f"Titular: {self.__titular}")
        print(f"Saldo actual: S/. {self.__saldo:.2f}")

nombre = input("Ingrese el nombre del titular: ")
saldo_inicial = float(input("Ingrese el saldo inicial: "))
cuenta = CuentaBancaria(nombre, saldo_inicial)

while True:
    print("\nSeleccione una opcion:")
    print("1. Depositar dinero")
    print("2. Retirar dinero")
    print("3. Mostrar informacion")
    print("4. Salir")

    opcion = input("Ingrese opcion : ")

    if opcion == "1":
        monto = float(input("Ingrese monto a depositar: "))
        cuenta.agregar_mas_platita(monto)
    elif opcion == "2":
        monto = float(input("Ingrese monto a retirar: "))
        cuenta.retirar(monto)
    elif opcion == "3":
        cuenta.mostrar_info()
    elif opcion == "4":
        print("Programa finalizado.")
        break
    else:
        print("Opcion invalida. Intente de nuevo.")
