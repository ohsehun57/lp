import tkinter as tk
import os

class producto: 
    def __init__(self,nombre,precio,stock):
        self.nombre = nombre
        self.precio = precio
        self.stock = stock

    def mostrar_informacion(self):
        return f"Nombre: {self.nombre} | Precio: S/. {self.precio:.2f} | Stock: {self.stock}"

    def aplicar_descuento(self, porcentaje_descuento):
        descuento = self.precio * (porcentaje_descuento / 100)
        self.precio -= descuento

    def realizar_venta(self, cantidad):
        if cantidad <= self.stock:
            self.stock -= cantidad
            return True
        else:
            return False

def aplicar_descuento_general(lista_productos, porcentaje):
    for p in lista_productos:
        p.aplicar_descuento(porcentaje)

productos = [
    producto("Arroz", 3.50, 100),
    producto("Azúcar", 4.50, 50),
    producto("Aceite", 8.00, 80),
    producto("Leche", 4.50, 60)
]

# FUNCIONES
def agregar_producto():
    try:
        nombre = entry_nombre.get()
        precio = float(entry_precio.get())
        stock = int(entry_stock.get())
        nuevo = producto(nombre, precio, stock)
        productos.append(nuevo)
        registrar(f"✅ Producto '{nombre}' agregado.")
        limpiar_campos()
    except:
        registrar("❌ Error al agregar producto. Verifica los datos.")

def mostrar_productos():
    registrar("📦 Lista de productos:")
    for p in productos:
        registrar("  - " + p.mostrar_informacion())

def aplicar_descuento():
    try:
        porcentaje = float(entry_descuento.get())
        aplicar_descuento_general(productos, porcentaje)
        registrar(f"🔻 Se aplicó un {porcentaje}% de descuento a todos los productos.")
        mostrar_productos()
    except:
        registrar("❌ Error al aplicar descuento. Verifica el porcentaje.")

def vender_producto():
    nombre = entry_venta_nombre.get().lower()
    try:
        cantidad = int(entry_venta_cantidad.get())
        for p in productos:
            if p.nombre.lower() == nombre:
                if p.realizar_venta(cantidad):
                    registrar(f"🛒 Venta realizada: {cantidad} unidades de {p.nombre}.")
                else:
                    registrar(f"⚠️ No hay suficiente stock de {p.nombre}.")
                mostrar_productos()
                return
        registrar(f"❌ Producto '{nombre}' no encontrado.")
    except:
        registrar("❌ Error en la cantidad ingresada.")

def guardar_txt():
    ruta = os.path.abspath("productos.txt")
    with open(ruta, "w") as f:
        for p in productos:
            f.write(p.mostrar_informacion() + "\n")
    registrar(f"💾 Guardado exitosamente en:\n{ruta}")

def registrar(texto):
    historial.insert(tk.END, texto + "\n")
    historial.see(tk.END)

def limpiar_campos():
    entry_nombre.delete(0, tk.END)
    entry_precio.delete(0, tk.END)
    entry_stock.delete(0, tk.END)

# INTERFAZ
ventana = tk.Tk()
ventana.title("Gestión de Productos - Examen Final")
ventana.geometry("850x650")
ventana.configure(bg="#f0f8ff")

titulo = tk.Label(ventana, text="Sistema de Gestión de Productos", font=("Arial", 18, "bold"), bg="#f0f8ff", fg="#003366")
titulo.pack(pady=10)

# AGREGAR PRODUCTO
frame_agregar = tk.Frame(ventana, bg="#e6f2ff")
frame_agregar.pack(pady=10)

tk.Label(frame_agregar, text="Nombre", bg="#e6f2ff").grid(row=0, column=0, padx=5)
entry_nombre = tk.Entry(frame_agregar)
entry_nombre.grid(row=0, column=1, padx=5)

tk.Label(frame_agregar, text="Precio", bg="#e6f2ff").grid(row=0, column=2, padx=5)
entry_precio = tk.Entry(frame_agregar)
entry_precio.grid(row=0, column=3, padx=5)

tk.Label(frame_agregar, text="Stock", bg="#e6f2ff").grid(row=0, column=4, padx=5)
entry_stock = tk.Entry(frame_agregar)
entry_stock.grid(row=0, column=5, padx=5)

tk.Button(frame_agregar, text="Agregar Producto", command=agregar_producto, bg="#b3daff").grid(row=0, column=6, padx=10)

# DESCUENTO GENERAL
frame_descuento = tk.Frame(ventana, bg="#f0f8ff")
frame_descuento.pack(pady=5)

tk.Label(frame_descuento, text="Descuento (%)", bg="#f0f8ff").grid(row=0, column=0)
entry_descuento = tk.Entry(frame_descuento, width=10)
entry_descuento.grid(row=0, column=1, padx=5)
tk.Button(frame_descuento, text="Aplicar Descuento", command=aplicar_descuento, bg="#b3daff").grid(row=0, column=2, padx=10)

# VENTA
frame_venta = tk.Frame(ventana, bg="#f0f8ff")
frame_venta.pack(pady=5)

tk.Label(frame_venta, text="Producto", bg="#f0f8ff").grid(row=0, column=0)
entry_venta_nombre = tk.Entry(frame_venta, width=15)
entry_venta_nombre.grid(row=0, column=1, padx=5)

tk.Label(frame_venta, text="Cantidad", bg="#f0f8ff").grid(row=0, column=2)
entry_venta_cantidad = tk.Entry(frame_venta, width=10)
entry_venta_cantidad.grid(row=0, column=3, padx=5)

tk.Button(frame_venta, text="Vender", command=vender_producto, bg="#ffcccb").grid(row=0, column=4, padx=10)

# BOTONES ADICIONALES
frame_botones = tk.Frame(ventana, bg="#f0f8ff")
frame_botones.pack(pady=5)

tk.Button(frame_botones, text="Mostrar Productos", command=mostrar_productos, bg="#d1e0e0").grid(row=0, column=0, padx=10)
tk.Button(frame_botones, text="Guardar en TXT", command=guardar_txt, bg="#d1e0e0").grid(row=0, column=1, padx=10)

# HISTORIAL
historial = tk.Text(ventana, height=18, width=100, bg="#ffffff", fg="#003366", font=("Courier", 10))
historial.pack(pady=10)

ventana.mainloop()
