import sys
import math

class pitqgoras:
    def __init__(self,base,altura):
        self.base=base
        self.altura=altura
        self.hipotenusa=math.sqrt(base**2 +altura**2)

    def calcular_area(self):
        return (self.base*self.altura)/2
    
    def calcular_perimetro(self):
        return self.base+ self.altura+ self.hipotenusa
    



area =pitqgoras(3,4)
print(f"arae:{area.calcular_area()}")
print(f"perimetro:{area.calcular_perimetro()}")
print(f"tamaño en memoria(bytes)")
tamaño_objeto=sys.getsizeof(area)
tamaño_objeto1=sys.getsizeof(area.base)
tamaño_objeto2=sys.getsizeof(area.altura)
tam_area=sys.getsizeof(area.calcular_area)
tam_perimetro_class=sys.getsizeof(area.calcular_perimetro)
tam_class=sys.getsizeof(pitqgoras)

print(f"objeto area:  {tamaño_objeto} bytes")
print(f"objeto base:  {tamaño_objeto1} bytes")
print(f"objeto altura:  {tamaño_objeto2} bytes")
print(f"metodo calcular_area:  {tam_area} bytes")
print(f"metodo calcular_perimetro:  {tam_perimetro_class} bytes")
print(f"clase :  {tam_class} bytes")


suma_total = tamaño_objeto+tamaño_objeto1+tamaño_objeto2+tam_area+tam_perimetro_class+tam_class
print(f"suma total del uso de memoria : {suma_total} bytes")