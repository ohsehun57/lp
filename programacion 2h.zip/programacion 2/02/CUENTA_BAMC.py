import tkinter as tk
from tkinter import ttk

class CuentaBancaria:
    def __init__(self, titular, saldo):
        self._titular = titular
        self._saldo = saldo
        self.historial = []

    def consultar_saldo(self):
        return f"Saldo actual de {self._titular}: S/. {self._saldo:.2f}"

    def agregar_mas_platita(self, monto):
        if monto > 0:
            self._saldo += monto
            mensaje = f"Depósito de S/. {monto:.2f} realizado con éxito."
            self.historial.append(mensaje)
            return mensaje
        else:
            mensaje = "El monto a depositar debe ser positivo."
            self.historial.append(mensaje)
            return mensaje

    def retirar(self, monto):
        if 0 < monto <= self._saldo:
            self._saldo -= monto
            mensaje = f"Retiro de S/. {monto:.2f} realizado con éxito."
            self.historial.append(mensaje)
            return mensaje
        else:
            mensaje = "Fondos insuficientes o monto inválido."
            self.historial.append(mensaje)
            return mensaje

class AppBanco(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("💳 Cuenta Bancaria Horizontal de Raúl 💰")
        self.geometry("800x320")
        self.configure(bg="#e6f2ff")
        self.resizable(False, False)

        self.cuenta = CuentaBancaria("Raúl", 500.00)

        self.crear_interfaz()

    def crear_interfaz(self):
        estilo = ttk.Style()
        estilo.theme_use("clam")
        estilo.configure("TButton", font=("Segoe UI", 10), padding=6, relief="flat",
                         background="#00bcd4", foreground="white")
        estilo.map("TButton", background=[('active', '#008c9e')])

        # Contenedor general
        contenedor = tk.Frame(self, bg="#e6f2ff")
        contenedor.pack(expand=True, fill="both", padx=10, pady=10)

        # Panel izquierdo: saldo y acciones
        panel_izq = tk.Frame(contenedor, bg="#e6f2ff")
        panel_izq.pack(side="left", fill="y", padx=20)

        ttk.Label(panel_izq, text="Cuenta de Raúl 🧑‍💼", font=("Segoe UI", 14, "bold"),
                  background="#e6f2ff").pack(pady=5)

        self.saldo_label = ttk.Label(panel_izq, text=self.cuenta.consultar_saldo(),
                                     font=("Segoe UI", 12), background="#e6f2ff", foreground="#333")
        self.saldo_label.pack(pady=10)

        ttk.Label(panel_izq, text="Monto:", background="#e6f2ff", font=("Segoe UI", 10)).pack()
        self.entry_monto = ttk.Entry(panel_izq, font=("Segoe UI", 11), width=20)
        self.entry_monto.pack(pady=5)

        # Botones
        ttk.Button(panel_izq, text="➕ Depositar", command=self.depositar).pack(pady=5)
        ttk.Button(panel_izq, text="➖ Retirar", command=self.retirar).pack(pady=5)
        ttk.Button(panel_izq, text="🔄 Consultar Saldo", command=self.actualizar_saldo).pack(pady=5)

        self.resultado_label = ttk.Label(panel_izq, text="", font=("Segoe UI", 10, "italic"),
                                         background="#e6f2ff", foreground="green", wraplength=200)
        self.resultado_label.pack(pady=10)

        # Panel derecho: historial
        panel_der = tk.Frame(contenedor, bg="#f5fbff", bd=2, relief="groove")
        panel_der.pack(side="left", fill="both", expand=True, padx=10)

        ttk.Label(panel_der, text="📜 Historial de Movimientos", font=("Segoe UI", 12, "bold"),
                  background="#f5fbff").pack(pady=10)

        self.historial_text = tk.Text(panel_der, height=12, width=50, font=("Segoe UI", 10),
                                      bg="#ffffff", relief="sunken", bd=1)
        self.historial_text.pack(padx=10, pady=5)
        self.historial_text.insert("end", "→ Bienvenido al sistema bancario de Raúl\n")
        self.historial_text.config(state="disabled")

    def depositar(self):
        try:
            monto = float(self.entry_monto.get())
            mensaje = self.cuenta.agregar_mas_platita(monto)
            self.mostrar_resultado(mensaje)
            self.actualizar_saldo()
            self.actualizar_historial()
        except ValueError:
            self.mostrar_resultado("Por favor ingresa un monto válido.", error=True)

    def retirar(self):
        try:
            monto = float(self.entry_monto.get())
            mensaje = self.cuenta.retirar(monto)
            self.mostrar_resultado(mensaje, error="inválido" in mensaje.lower())
            self.actualizar_saldo()
            self.actualizar_historial()
        except ValueError:
            self.mostrar_resultado("Por favor ingresa un monto válido.", error=True)

    def actualizar_saldo(self):
        self.saldo_label.config(text=self.cuenta.consultar_saldo())
        self.entry_monto.delete(0, tk.END)

    def mostrar_resultado(self, mensaje, error=False):
        color = "red" if error else "green"
        self.resultado_label.config(text=mensaje, foreground=color)

    def actualizar_historial(self):
        self.historial_text.config(state="normal")
        self.historial_text.delete("1.0", "end")
        for item in self.cuenta.historial[-10:]:
            self.historial_text.insert("end", f"→ {item}\n")
        self.historial_text.config(state="disabled")

# Ejecutar la aplicación
if __name__ == "__main__":
    app = AppBanco()
    app.mainloop()
