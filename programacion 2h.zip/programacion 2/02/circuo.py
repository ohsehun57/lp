import math

class circulo:
    def __init__(self, radio):
        self.__radio = radio

    # Getter para radio
    def obtener_radio(self):
        return self.__radio

    # Setter para radio
    def establecer_radio(self, nuevo_radio):
        if nuevo_radio > 0:
            self.__radio = nuevo_radio
        else:
            print("Radio no válido")

    # Método para calcular el área del círculo
    def calcular_area(self):
        return math.pi * self.__radio ** 2

    # Método para calcular el perímetro (circunferencia)
    def calcular_perimetro(self):
        return 2 * math.pi * self.__radio

    # Método para mostrar datos
    def mostrar_datos(self):
        print(f"Radio: {self.__radio}")
        print(f"Área: {self.calcular_area()}")
        print(f"Perímetro (circunferencia): {self.calcular_perimetro()}")

cir = circulo(1)
cir.mostrar_datos()

# Cambiar radio
cir.establecer_radio(5)
cir.mostrar_datos()
