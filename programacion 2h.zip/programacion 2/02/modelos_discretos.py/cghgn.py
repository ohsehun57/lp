import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from mpl_toolkits.mplot3d import Axes3D
import numpy as np

# Cargar los datos desde un archivo CSV (ajusta el nombre si es diferente)
df = pd.read_csv('dddd.csv')

# Variables predictoras y variable de respuesta
X = df[['Edad', 'Genero', 'Frecuencia_Comidas_Diarias', 'Horas_Estudio', 'Horas_Sueño']]
y = df['Nivel_Estres']

# División de los datos
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Crear y entrenar el modelo
modelo = LinearRegression()
modelo.fit(X_train, y_train)

# Resultados
print("Coeficientes:")
for col, coef in zip(X.columns, modelo.coef_):
    print(f"{col}: {coef:.4f}")
print(f"Intercepto: {modelo.intercept_:.4f}")

# ===== Gráfico de dispersión simple =====
sns.pairplot(df, vars=['Edad', 'Horas_Estudio', 'Horas_Sueño'], hue='Nivel_Estres', palette='coolwarm')
plt.suptitle("Relaciones con Nivel de Estrés", y=1.02)
plt.show()

# ===== Gráfico 3D: Horas_Estudio, Horas_Sueño vs Nivel_Estres =====
fig = plt.figure(figsize=(10, 7))
ax = fig.add_subplot(111, projection='3d')

x_sueño = df['Horas_Sueño']
x_estudio = df['Horas_Estudio']
z_estres = df['Nivel_Estres']

ax.scatter(x_estudio, x_sueño, z_estres, c=z_estres, cmap='coolwarm', s=50)

ax.set_xlabel('Horas de Estudio')
ax.set_ylabel('Horas de Sueño')
ax.set_zlabel('Nivel de Estrés')
ax.set_title('3D: Estudio vs Sueño vs Estrés')
plt.show()
