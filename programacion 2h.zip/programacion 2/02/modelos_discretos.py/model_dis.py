import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.linear_model import LinearRegression

# Datos ficticios
data = {
    'Horas_Estudio': [2, 3, 5, 7, 9],
    'Horas_Sueño': [7, 6, 5, 4, 3],
    'Nivel_Estres': [80, 70, 60, 50, 40]
}
df = pd.DataFrame(data)

# Modelo de regresión múltiple
X = df[['Horas_Estudio', 'Horas_Sueño']]
y = df['Nivel_Estres']
modelo = LinearRegression()
modelo.fit(X, y)

# Predicciones
df['Nivel_Estres_Pronosticado'] = modelo.predict(X)

# Gráfico de dispersión: real vs pronosticado
plt.figure(figsize=(8, 6))
sns.scatterplot(x=df['Nivel_Estres'], y=df['Nivel_Estres_Pronosticado'], color='blue', s=60)
plt.plot([df['Nivel_Estres'].min(), df['Nivel_Estres'].max()],
         [df['Nivel_Estres'].min(), df['Nivel_Estres'].max()],
         'r--')
plt.title("Regresión Múltiple: Estrés Real vs Pronosticado")
plt.xlabel("Nivel de Estrés Real")
plt.ylabel("Nivel de Estrés Pronosticado")
plt.tight_layout()
plt.show()
