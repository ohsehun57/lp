import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression

# Cargar los datos
df = pd.read_csv('datos_estres.csv')

# Verifica los datos (opcional)
print(df.head())

# ====== REGRESIÓN MÚLTIPLE ======
X = df[['Edad', 'Genero', 'Frecuencia_Comidas_Diarias', 'Horas_Estudio', 'Horas_Sueño']]
y = df['Nivel_Estres']

modelo = LinearRegression()
modelo.fit(X, y)

# Mostrar coeficientes
print("Intercepto:", modelo.intercept_)
print("Coeficientes:", list(zip(X.columns, modelo.coef_)))

# ====== GRAFICAR MATRIZ DE DISPERSIÓN ======
sns.pairplot(df, diag_kind="kde", plot_kws={'alpha': 0.6, 's': 50, 'edgecolor': 'k'})
plt.suptitle("Matriz de dispersión: Nivel de estrés y variables asociadas", y=1.02)
plt.tight_layout()
plt.show()
