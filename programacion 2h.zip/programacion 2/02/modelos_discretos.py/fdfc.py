import pandas as pd

# Crear los datos como un diccionario
datos = {
    "Edad": [18, 19, 18, 20, 19, 21, 20, 19, 18, 22, 21, 19, 18, 20, 19, 21, 20, 22, 19, 21, 18, 20, 19, 22, 21, 23, 19, 20, 18, 21],
    "Genero": [1, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1],
    "Frecuencia_Comidas_Diarias": [3, 5, 2, 3, 4, 2, 3, 4, 3, 2, 5, 3, 2, 4, 3, 3, 4, 2, 3, 5, 2, 3, 4, 3, 5, 2, 3, 4, 2, 3],
    "Horas_Estudio": [6, 4, 8, 5, 4, 9, 3, 7, 5, 10, 2, 6, 9, 3, 5, 8, 4, 9, 6, 3, 7, 4, 5, 8, 2, 9, 5, 3, 8, 5],
    "Horas_Sueño": [5, 7, 4, 6, 8, 5, 9, 6, 7, 4, 8, 5, 4, 7, 6, 5, 8, 4, 7, 8, 5, 6, 7, 5, 9, 4, 7, 8, 5, 6],
    "Nivel_Estres": [3, 1, 3, 2, 1, 3, 1, 2, 2, 3, 1, 2, 3, 1, 2, 3, 1, 3, 2, 1, 3, 2, 1, 3, 1, 3, 2, 1, 3, 2]
}

# Crear DataFrame y guardar como CSV
df = pd.DataFrame(datos)
df.to_csv("datos_estres.csv", index=False)
print("Archivo 'datos_estres.csv' creado correctamente.")
