import math

def predecir_accidentes(hr_conduccion, experiencia):
    # Coeficiente
    intercepto = 0.741
    log_mu = intercepto

    # Horas de conducción solo -> (categoría 2 es significativa)
    if hr_conduccion == 2:
        log_mu += 0.215

    # Años de experiencia -> (1, 2, 3 son significativos)
    if experiencia == 1:
        log_mu += 0.408
    elif experiencia == 2:
        log_mu += 0.264
    elif experiencia == 3:
        log_mu += 0.395

    # Calcular valor esperado de accidentes
    mu = math.exp(log_mu)
    return mu

def interpretar_resultado(mu, hr_conduccion, experiencia):
    mu_redondeado = round(mu)

    horas_texto = {
        1: "menos de 6 horas diarias",
        2: "entre 6 y 9 horas exactas",
        3: "más de 9 horas diarias"
    }

    experiencia_texto = {
        1: "menos de 2 años de experiencia (nivel junior)",
        2: "entre 2 y 5 años de experiencia (nivel asociado)",
        3: "entre 5 y 10 años de experiencia (nivel medio)",
        4: "más de 10 años de experiencia (nivel senior)"
    }

    return (
        f"\n📊 Según el modelo ajustado del estudio “Factores Asociados al Número de Accidentes de Tránsito "
        f"en Conductores de Taxis (Ciudad de Juliaca, 2024)”,\n"
        f"se puede predecir que el número **esperado** de accidentes es aproximadamente **{mu:.2f} ≈ {mu_redondeado}**,\n"
        f"si el conductor realiza {horas_texto[hr_conduccion]} y cuenta con {experiencia_texto[experiencia]}.\n"
        f"Este valor representa el riesgo promedio dentro del grupo de taxistas con estas características en Juliaca."
    )

def mostrar_opciones():
    print("\nSeleccione las horas de conducción del conductor:")
    print("1: Menos de 6 horas")
    print("2: Entre 6 y 9 horas exactas")
    print("3: Más de 9 horas (categoría de referencia)")

    print("\nSeleccione los años de experiencia del conductor:")
    print("1: Junior (menos de 2 años)")
    print("2: Asociado (2 a 5 años)")
    print("3: Nivel medio (5 a 10 años)")
    print("4: Senior (más de 10 años) (categoría de referencia)")

if __name__ == "__main__":
    print("🛻 Pronóstico del número esperado de accidentes en conductores de taxi - Juliaca 2024")
    mostrar_opciones()

    try:
        hr = int(input("\nIngrese la opción de horas de conducción (1–3): "))
        exp = int(input("Ingrese la opción de experiencia del conductor (1–4): "))

        if hr not in [1, 2, 3] or exp not in [1, 2, 3, 4]:
            print("⚠️ Error: Las opciones ingresadas están fuera del rango permitido.")
        else:
            mu = predecir_accidentes(hr, exp)
            resultado = interpretar_resultado(mu, hr, exp)
            print(resultado)

    except ValueError:
        print("❌ Entrada no válida. Debes ingresar números enteros.")
