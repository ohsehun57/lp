"""class animal:
    def hablar(self):
        return "hace sonido"
    
class perro(animal):
    def hablar(self):
        return "ladra"
p =perro()
print(p.hablar())

######################################################################################################
class persona:
    def __init__(self,nombre):
        self.nombre=nombre
    
class estudinate(persona):
    def __init__(self,nombre,carrera):
        super().__init__(nombre)
        self.carrera=carrera
e= estudinate("maria","ingenieria")
print(e.nombre)
print(e.carrera)

#######################################################################################################
class vehiculo:
    def __init__(self,marca,modelo):
        self.marca=marca
        self.modelo=modelo
    
    def describcion(self):
        return f"vehiculo:{self.marca} {self.modelo}"
    
class auto(vehiculo):
    def __init__(self,marca,modelo,puertas):
        super().__init__(marca,modelo)
        self.puertas=puertas

    def describcion(self):
        return super().describcion()+f"    puertas: {self.puertas}"
    
auto1=auto("toyota","corolla",4)    
print(auto1.describcion())


#######################################################################################################

class computadora:
    def encender(self):
        return "computadora encendida"
    
class telefono:
    def llamar(self,numero):
        return f"llamada al numero {numero}.........."
    
class smartphone(computadora,telefono):
    def usar_aplicacion(self,app):
        return f"abriendo la app: {app}"
mi_telefono=smartphone()
print(mi_telefono.encender())
print(mi_telefono.llamar("951085250"))
print(mi_telefono.usar_aplicacion("watssap"))


#######################################################################################################

class figura_geometrica:
    def reso(self,nombre):
        return f"la figura es:{nombre}"
class trectangulo(figura_geometrica):
    def resolver(self,base,altura):
        return f" con resolucion de:{base}*{altura} /2 = {(base*altura)/2}"
res=figura_geometrica()  
tria=trectangulo()
print(tria.reso("triangulo"))
print(tria.resolver(5,4))

#######################################################################################################

class figura_geometrica:
    def fig(self,nombre):
        return f"la figura es:{nombre}"

class color:
    def colo(self,color):
        return f"el color es:{color}" 

class textura:
    def tex(self,textura):
        return f"su textura es:{textura}"    

class cuadrado(figura_geometrica,color,textura):
    def resolver(self,base): 
        return f" con resolucion del area del cuadrado es:{base}*{base} = {base*base}"
    def per(self,base):
        return f" el perimetro es :{base}+{base}+{base}+{base} = {base+base+base+base}"
tria=cuadrado()
print(tria.fig("cuadrado"))
print(tria.colo("verde"))
print(tria.resolver(4))
print(tria.per(4))
print(tria.tex("enmallado"))


#######################################################################################################
class figura_geometrica:
    def __init__(self, nombre):
        self.nombre = nombre

    def mostrar_nombre(self):
        return f"La figura es: {self.nombre}"

class color:
    def __init__(self, color):
        self.color = color

    def mostrar_color(self):
        return f"El color es: {self.color}"

class dimension:
    def __init__(self, lado):
        self.lado = lado

    def mostrar_lado(self):
        return f"Lado: {self.lado}"

class cuadrado(figura_geometrica, color, dimension):
    def __init__(self, nombre, color_valor, lado):
        figura_geometrica.__init__(self, nombre)
        color.__init__(self, color_valor)
        dimension.__init__(self, lado)

    def calcular_area(self):
        return self.lado * self.lado

    def mostrar_todo(self):
        print(self.mostrar_nombre())
        print(self.mostrar_color())
        print(self.mostrar_lado())
        print(f"Área: {self.calcular_area()} unidades al cuadrado")

# Prueba
cuad = cuadrado("Cuadrado", "azul", 6)
cuad.mostrar_todo()

#######################################################################################################"""""



class figura_geometrica:
    def __init__(self, nombre):
        self.nombre = nombre

    def mostrar_nombre(self):
        return f"La figura es: {self.nombre}"

class color:
    def __init__(self, color):
        self.color = color

    def mostrar_color(self):
        return f"El color es: {self.color}"

class dimension_triangulo:
    def __init__(self, base, altura):
        self.base = base
        self.altura = altura

    def mostrar_dimensiones(self):
        return f"Base: {self.base}, Altura: {self.altura}"

class triangulo_rectangulo(figura_geometrica, color, dimension_triangulo):
    def __init__(self, nombre, color_valor, base, altura):
        figura_geometrica.__init__(self, nombre)
        color.__init__(self, color_valor)
        dimension_triangulo.__init__(self, base, altura)

    def calcular_area(self):
        return (self.base * self.altura) / 2

    def mostrar_todo(self):
        print(self.mostrar_nombre())
        print(self.mostrar_color())
        print(self.mostrar_dimensiones())
        print(f"Área = (base × altura) / 2 = ({self.base} × {self.altura}) / 2 = {self.calcular_area()} unidades cuadradas")

# Prueba
tri = triangulo_rectangulo("Triángulo Rectángulo", "rojo", 5, 4)
tri.mostrar_todo()
