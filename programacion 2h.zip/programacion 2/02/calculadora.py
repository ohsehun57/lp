class CalculadoraBasica:
    def __init__(self, numero1, numero2):
        self.__numero1 = numero1
        self.__numero2 = numero2

    # Getters
    def obtener_numero1(self):
        return self.__numero1

    def obtener_numero2(self):
        return self.__numero2

    # Setters
    def establecer_numero1(self, nuevo_valor):
        self.__numero1 = nuevo_valor

    def establecer_numero2(self, nuevo_valor):
        self.__numero2 = nuevo_valor

#
# 
# opoeraciones
    def suma(self):
        return self.__numero1 +self.__numero2
    def resta(self):
        return self.__numero1 -self.__numero2
    def multiplicacion(self):
        return self.__numero1 *self.__numero2
    
    def divicion(self):
        if self.__numero2!=0:
            return self.__numero1 /self.__numero2
        else:
            return "error: divicion entre cero"
    
    def mostrar_operaciones(self):
        print(f"Numero1 :{self.__numero1}")
        print(f"Numero2 :{self.__numero2}")
        print(f"suma :{self.suma()}")
        print(f"resta :{self.resta()}")
        print(f"multiplicacion :{self.multiplicacion()}")
        print(f"divicion :{self.divicion()}")

#uso de la calculadora basicA

try:

    a=int(input("ingrese el valor de a: "))
    b=int(input("ingrese el valor de b: "))

    calc =CalculadoraBasica(a,b)
    calc.mostrar_operaciones()
     
    print("\ncambiando valores")
    Na=int(input("ingrese el nuevo valor de a: "))
    Nb=int(input("ingrese el nuevo valor de b: "))

    calc =CalculadoraBasica(a,b)
    calc.establecer_numero1(Na)
    calc.establecer_numero2(Nb)
    calc.mostrar_operaciones()
     

except ValueError:
    print("erorr:  ingrese valores numericos")