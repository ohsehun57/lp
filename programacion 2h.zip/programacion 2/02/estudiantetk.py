import tkinter as tk
from tkinter import ttk, simpledialog, messagebox

class Estudiante:
    def __init__(self, nombre, edad, carrera):
        self.nombre = nombre
        self.edad = edad
        self.carrera = carrera
        self.notas = []

    def agregar_notas(self, nota):
        self.notas.append(nota)

    def calcular_promedio(self):
        return sum(self.notas) / len(self.notas) if self.notas else 0

    def esta_aprobado(self):
        return self.calcular_promedio() >= 11

    def obtener_info(self):
        promedio = self.calcular_promedio()
        aprobado = 'SI' if self.esta_aprobado() else 'NO'
        return f"Nombre: {self.nombre}\nEdad: {self.edad}\nCarrera: {self.carrera}\nNotas: {self.notas}\nPromedio: {round(promedio, 2)}\nAprobado: {aprobado}"

class AppEstudiantes(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Registro de Estudiantes")
        self.geometry("650x500")
        self.configure(bg="#e0f2f7")  # Azul muy claro
        self.lista_estudiantes = []
        self.crear_widgets()

    def crear_widgets(self):
        # Estilo para los elementos
        style = ttk.Style()
        style.configure("TLabel", font=("Segoe UI", 12), background="#e0f2f7", foreground="#263238")  # Gris azulado oscuro
        style.configure("TButton", font=("Segoe UI", 12, "bold"), background="#64b5f6", foreground="white", padding=10)  # Azul más llamativo
        style.configure("TListbox", font=("Segoe UI", 11), background="white", foreground="#263238")
        style.configure("TFrame", background="#e0f2f7")

        # Frame principal
        main_frame = ttk.Frame(self)
        main_frame.pack(padx=20, pady=20, fill="both", expand=True)

        # Título principal
        titulo_label = ttk.Label(main_frame, text="Sistema de Registro de Estudiantes", font=("Segoe UI", 18, "bold"), foreground="#1976d2")  # Azul más intenso
        titulo_label.pack(pady=(0, 15))

        # Frame para botones y lista
        controls_frame = ttk.Frame(main_frame)
        controls_frame.pack(pady=(0, 15), fill="x")

        agregar_btn = ttk.Button(controls_frame, text="Agregar Nuevo Estudiante", command=self.agregar_estudiante)
        agregar_btn.pack(side="left", padx=(0, 10))

        # Lista de estudiantes registrados
        self.lista_estudiantes_lb = tk.Listbox(main_frame, width=40, height=10, font=("Segoe UI", 11), bg="white", fg="#263238")
        self.lista_estudiantes_lb.pack(fill="both", expand=True)
        self.lista_estudiantes_lb.bind('<<ListboxSelect>>', self.mostrar_detalle_estudiante)

        # Frame para detalles del estudiante
        details_frame = ttk.Frame(main_frame)
        details_frame.pack(pady=(15, 0), fill="both", expand=True)

        detalle_titulo_label = ttk.Label(details_frame, text="Detalles del Estudiante:", font=("Segoe UI", 14, "bold"), foreground="#1976d2")
        detalle_titulo_label.pack(pady=(0, 5), anchor="w")

        self.detalle_text = tk.Text(details_frame, height=10, font=("Segoe UI", 11), bg="#f5f5f5", fg="#263238")
        self.detalle_text.pack(fill="both", expand=True)
        self.detalle_text.config(state=tk.DISABLED)  # Hacerlo de solo lectura

    def agregar_estudiante(self):
        dialogo = VentanaNuevoEstudiante(self)
        self.wait_window(dialogo)
        self.actualizar_lista_estudiantes()

    def actualizar_lista_estudiantes(self):
        self.lista_estudiantes_lb.delete(0, tk.END)
        for estudiante in self.lista_estudiantes:
            self.lista_estudiantes_lb.insert(tk.END, estudiante.nombre)

    def mostrar_detalle_estudiante(self, event):
        seleccion = self.lista_estudiantes_lb.curselection()
        if seleccion:
            index = seleccion[0]
            estudiante = self.lista_estudiantes[index]
            self.mostrar_en_detalle(estudiante.obtener_info())
        else:
            self.mostrar_en_detalle("Seleccione un estudiante para ver sus detalles.")

    def mostrar_en_detalle(self, texto):
        self.detalle_text.config(state=tk.NORMAL)
        self.detalle_text.delete("1.0", tk.END)
        self.detalle_text.insert(tk.END, texto)
        self.detalle_text.config(state=tk.DISABLED)

class VentanaNuevoEstudiante(tk.Toplevel):
    def __init__(self, master):
        super().__init__(master)
        self.master = master
        self.title("Nuevo Estudiante")
        self.geometry("400x320")
        self.configure(bg="#bbdefb")  # Otro tono de azul claro
        self.estudiante = None
        self.crear_formulario()

    def crear_formulario(self):
        style = ttk.Style()
        style.configure("TLabel", font=("Segoe UI", 12), background="#bbdefb", foreground="#263238")
        style.configure("TButton", font=("Segoe UI", 12, "bold"), background="#64b5f6", foreground="white", padding=8)
        style.configure("TEntry", font=("Segoe UI", 12))

        ttk.Label(self, text="Nombre:", style="TLabel").grid(row=0, column=0, padx=10, pady=10, sticky="w")
        self.nombre_entry = ttk.Entry(self, width=30, style="TEntry")
        self.nombre_entry.grid(row=0, column=1, padx=10, pady=10)

        ttk.Label(self, text="Edad:", style="TLabel").grid(row=1, column=0, padx=10, pady=10, sticky="w")
        self.edad_entry = ttk.Entry(self, width=30, style="TEntry")
        self.edad_entry.grid(row=1, column=1, padx=10, pady=10)

        ttk.Label(self, text="Carrera:", style="TLabel").grid(row=2, column=0, padx=10, pady=10, sticky="w")
        self.carrera_entry = ttk.Entry(self, width=30, style="TEntry")
        self.carrera_entry.grid(row=2, column=1, padx=10, pady=10)

        ttk.Label(self, text="Cantidad de Notas:", style="TLabel").grid(row=3, column=0, padx=10, pady=10, sticky="w")
        self.cantidad_notas_entry = ttk.Entry(self, width=10, style="TEntry")
        self.cantidad_notas_entry.grid(row=3, column=1, padx=10, pady=10, sticky="w")

        agregar_notas_btn = ttk.Button(self, text="Ingresar Notas", command=self.ingresar_notas, style="TButton")
        agregar_notas_btn.grid(row=4, column=0, columnspan=2, pady=10)

        self.notas_ingresadas = []
        self.estudiante_creado = None

        guardar_btn = ttk.Button(self, text="Guardar Estudiante", command=self.guardar_estudiante, state=tk.DISABLED, style="TButton")
        guardar_btn.grid(row=5, column=0, columnspan=2, pady=10)
        self.guardar_btn = guardar_btn

    def ingresar_notas(self):
        try:
            cantidad = int(self.cantidad_notas_entry.get())
            if cantidad <= 0:
                messagebox.showerror("Error", "La cantidad de notas debe ser mayor que cero.")
                return

            self.notas_ingresadas = []
            for i in range(cantidad):
                nota_str = simpledialog.askstring("Ingresar Nota", f"Ingrese la nota {i+1}:")
                if nota_str is None:  # El usuario canceló
                    self.notas_ingresadas = []
                    return
                try:
                    nota = float(nota_str)
                    if 0 <= nota <= 20:
                        self.notas_ingresadas.append(nota)
                    else:
                        messagebox.showerror("Error", "Las notas deben estar entre 0 y 20.")
                        self.notas_ingresadas = []
                        return
                except ValueError:
                    messagebox.showerror("Error", "Ingrese un valor numérico para la nota.")
                    self.notas_ingresadas = []
                    return

            nombre = self.nombre_entry.get()
            edad = self.edad_entry.get()
            carrera = self.carrera_entry.get()

            if nombre and edad.isdigit() and carrera and self.notas_ingresadas:
                self.estudiante_creado = Estudiante(nombre, int(edad), carrera)
                for nota in self.notas_ingresadas:
                    self.estudiante_creado.agregar_notas(nota)
                self.guardar_btn.config(state=tk.NORMAL)
                messagebox.showinfo("Éxito", f"Se han ingresado {len(self.notas_ingresadas)} notas para el estudiante.")
            else:
                messagebox.showerror("Error", "Por favor, complete todos los campos y asegúrese de ingresar las notas.")

        except ValueError:
            messagebox.showerror("Error", "Ingrese un número válido para la cantidad de notas.")

    def guardar_estudiante(self):
        if self.estudiante_creado:
            self.master.lista_estudiantes.append(self.estudiante_creado)
            self.destroy()
        else:
            messagebox.showerror("Error", "Primero debe ingresar las notas del estudiante.")

if __name__ == "__main__":
    app = AppEstudiantes()
    app.mainloop()