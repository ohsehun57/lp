import tkinter as tk
from tkinter import messagebox

class Doctor:
    def __init__(self, nombre, especialidad, experiencia, correo, telefono, hospital):
        self.nombre = nombre
        self.especialidad = especialidad
        self.experiencia = experiencia
        self.correo = correo
        self.telefono = telefono
        self.hospital = hospital

    def mostrar_informacion(self):
        return (
            f"👨‍⚕️ Nombre: {self.nombre}\n"
            f"📌 Especialidad: {self.especialidad}\n"
            f"📅 Experiencia: {self.experiencia} años\n"
            f"📧 Correo: {self.correo}\n"
            f"📞 Teléfono: {self.telefono}\n"
            f"🏥 Hospital: {self.hospital}"
        )

    def atender_paciente(self, paciente):
        return f"🩺 El Dr. {self.nombre} está atendiendo a {paciente}."

    def calcular_salario(self):
        salario_base = 2001
        bono_experiencia = self.experiencia * 150
        salario_total = salario_base + bono_experiencia
        return f"💵 El salario del Dr. {self.nombre} es ${salario_total}"

    def recetar_medicamento(self, medicamento):
        return f"💊 El Dr. {self.nombre} receta: {medicamento}"

# Diccionario para guardar los doctores
doctores = {}

# Funciones
def guardar_doctor():
    nombre = entry_nombre.get().strip()
    especialidad = entry_especialidad.get().strip()
    experiencia = entry_experiencia.get().strip()
    correo = entry_correo.get().strip()
    telefono = entry_telefono.get().strip()
    hospital = entry_hospital.get().strip()

    if not (nombre and especialidad and experiencia.isdigit() and correo and telefono and hospital):
        messagebox.showwarning("Error", "Todos los campos son obligatorios y la experiencia debe ser un número.")
        return

    experiencia = int(experiencia)
    doctores[nombre] = Doctor(nombre, especialidad, experiencia, correo, telefono, hospital)
    messagebox.showinfo("Doctor Guardado", f"✅ El doctor {nombre} ha sido guardado correctamente.")

def buscar_doctor():
    nombre = doctor_busqueda_entry.get().strip()
    if nombre in doctores:
        global doctor_actual
        doctor_actual = doctores[nombre]
        label_info.config(text=doctor_actual.mostrar_informacion())
    else:
        messagebox.showerror("No encontrado", f"❌ No se encontró al doctor {nombre}")

def atender():
    if not doctor_actual:
        return
    paciente = entry_paciente.get().strip()
    if paciente:
        messagebox.showinfo("Atención", doctor_actual.atender_paciente(paciente))
    else:
        messagebox.showwarning("Error", "Debe ingresar el nombre del paciente.")

def calcular_salario():
    if doctor_actual:
        messagebox.showinfo("Salario", doctor_actual.calcular_salario())

def recetar():
    if not doctor_actual:
        return
    medicamento = entry_medicamento.get().strip()
    if medicamento:
        messagebox.showinfo("Receta", doctor_actual.recetar_medicamento(medicamento))
    else:
        messagebox.showwarning("Error", "Debe ingresar un medicamento.")

# GUI
ventana = tk.Tk()
ventana.title("Gestión de Doctores")
ventana.geometry("600x720")
ventana.configure(bg="#e1f5fe")

# Contenedor general
frame = tk.Frame(ventana, bg="#e1f5fe")
frame.pack(anchor="w", padx=20, pady=10)

# Sección: Registrar doctor
tk.Label(frame, text="🩺 Registrar Doctor", font=("Helvetica", 14, "bold"), bg="#e1f5fe", fg="#0277bd").pack(anchor="w", pady=5)

def crear_campo(label_text):
    tk.Label(frame, text=label_text, font=("Arial", 10), bg="#e1f5fe").pack(anchor="w")
    entrada = tk.Entry(frame)
    entrada.pack(anchor="w", pady=2)
    return entrada

entry_nombre = crear_campo("Nombre:")
entry_especialidad = crear_campo("Especialidad:")
entry_experiencia = crear_campo("Años de Experiencia:")
entry_correo = crear_campo("Correo:")
entry_telefono = crear_campo("Teléfono:")
entry_hospital = crear_campo("Hospital:")

tk.Button(frame, text="Guardar Doctor", bg="#0288d1", fg="white", command=guardar_doctor).pack(anchor="w", pady=10)

# Sección: Buscar doctor
tk.Label(frame, text="🔍 Buscar Doctor por Nombre:", font=("Arial", 10, "bold"), bg="#e1f5fe").pack(anchor="w")
doctor_busqueda_entry = tk.Entry(frame)
doctor_busqueda_entry.pack(anchor="w", pady=2)
tk.Button(frame, text="Buscar", bg="#00796b", fg="white", command=buscar_doctor).pack(anchor="w", pady=5)

# Mostrar información del doctor
label_info = tk.Label(frame, text="Información del doctor aparecerá aquí.", bg="#b3e5fc", justify="left", anchor="w", width=70, height=10, font=("Arial", 10))
label_info.pack(anchor="w", pady=10)

# Sección: Paciente y medicamento
tk.Label(frame, text="👤 Nombre del paciente:", bg="#e1f5fe", font=("Arial", 10, "bold")).pack(anchor="w")
entry_paciente = tk.Entry(frame)
entry_paciente.pack(anchor="w", pady=2)
tk.Button(frame, text="Atender Paciente", bg="#00796b", fg="white", command=atender).pack(anchor="w", pady=5)

tk.Button(frame, text="Calcular Salario", bg="#00796b", fg="white", command=calcular_salario).pack(anchor="w", pady=5)

tk.Label(frame, text="💊 Medicamento:", bg="#e1f5fe", font=("Arial", 10, "bold")).pack(anchor="w")
entry_medicamento = tk.Entry(frame)
entry_medicamento.pack(anchor="w", pady=2)
tk.Button(frame, text="Recetar Medicamento", bg="#009688", fg="white", command=recetar).pack(anchor="w", pady=5)

doctor_actual = None  # Variable global para trabajar con el doctor activo

ventana.mainloop()
