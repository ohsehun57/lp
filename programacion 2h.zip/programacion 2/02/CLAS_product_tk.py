import tkinter as tk
from tkinter import ttk
from datetime import datetime

class Producto:
    def __init__(self, nombre, precio, stock, unidad, fecha):
        self.nombre = nombre
        self.precio = precio
        self.stock = stock
        self.unidad = unidad
        self.fecha = fecha

    def mostrar_informacion(self):
        return f"Nombre: {self.nombre}\nPrecio: S/.{self.precio}\nStock: {self.stock} {self.unidad}\nFecha de ingreso: {self.fecha}"

    def actualizar_precio(self, nuevo_precio):
        self.precio = nuevo_precio

    def actualizar_stock(self, nuevo_stock):
        self.stock = nuevo_stock

class AppProductos:
    def __init__(self, root):
        self.root = root
        self.root.title("Sistema de Inventario de Productos")
        self.root.geometry("950x650")
        self.root.configure(bg="#d0e7ff")

        self.productos = []
        self.estilo = ttk.Style()
        self.estilo.theme_use("clam")

        self.estilo.configure("Treeview",
            background="#ffffff",
            foreground="black",
            rowheight=30,
            fieldbackground="#ffffff",
            font=("Segoe UI", 10))

        self.estilo.configure("TLabel", font=("Segoe UI", 11))
        self.estilo.configure("TEntry", font=("Segoe UI", 11))
        self.estilo.configure("TButton", font=("Segoe UI", 11, "bold"))

        self.crear_widgets()

    def crear_widgets(self):
        titulo = ttk.Label(self.root, text="Registro y Gestión de Productos", font=("Segoe UI", 20, "bold"), background="#d0e7ff", foreground="#004080")
        titulo.pack(pady=20)

        marco_formulario = ttk.LabelFrame(self.root, text="Agregar Producto", padding=20)
        marco_formulario.pack(pady=10, padx=20, fill="x")

        ttk.Label(marco_formulario, text="Nombre: ").grid(row=0, column=0, sticky="e", padx=5, pady=5)
        self.entry_nombre = ttk.Entry(marco_formulario, width=40)
        self.entry_nombre.grid(row=0, column=1)

        ttk.Label(marco_formulario, text="Precio (S/.):").grid(row=1, column=0, sticky="e", padx=5, pady=5)
        self.entry_precio = ttk.Entry(marco_formulario, width=40)
        self.entry_precio.grid(row=1, column=1)

        ttk.Label(marco_formulario, text="Stock: ").grid(row=2, column=0, sticky="e", padx=5, pady=5)
        self.entry_stock = ttk.Entry(marco_formulario, width=40)
        self.entry_stock.grid(row=2, column=1)

        ttk.Label(marco_formulario, text="Unidad de medida: ").grid(row=3, column=0, sticky="e", padx=5, pady=5)
        self.entry_unidad = ttk.Entry(marco_formulario, width=40)
        self.entry_unidad.grid(row=3, column=1)

        btn_agregar = ttk.Button(marco_formulario, text="Agregar Producto", command=self.agregar_producto)
        btn_agregar.grid(row=4, column=0, columnspan=2, pady=10)

        marco_tabla = ttk.LabelFrame(self.root, text="Lista de Productos", padding=10)
        marco_tabla.pack(fill="both", expand=True, padx=20, pady=10)

        columnas = ("Nombre", "Precio", "Stock", "Unidad", "Fecha")
        self.tree = ttk.Treeview(marco_tabla, columns=columnas, show="headings")
        for col in columnas:
            self.tree.heading(col, text=col)
            self.tree.column(col, anchor="center")
        self.tree.pack(fill="both", expand=True)

        self.info_text = tk.Text(self.root, height=5, font=("Segoe UI", 11))
        self.info_text.pack(fill="x", padx=20, pady=5)

        btn_frame = ttk.Frame(self.root)
        btn_frame.pack(pady=10)

        self.btn_info = ttk.Button(btn_frame, text="Ver Información", command=self.mostrar_info_producto)
        self.btn_info.grid(row=0, column=0, padx=5)

        self.btn_actualizar_precio = ttk.Button(btn_frame, text="Actualizar Precio", command=self.actualizar_precio_producto)
        self.btn_actualizar_precio.grid(row=0, column=1, padx=5)

        self.btn_actualizar_stock = ttk.Button(btn_frame, text="Actualizar Stock", command=self.actualizar_stock_producto)
        self.btn_actualizar_stock.grid(row=0, column=2, padx=5)

    def agregar_producto(self):
        nombre = self.entry_nombre.get().strip()
        precio = self.entry_precio.get().strip()
        stock = self.entry_stock.get().strip()
        unidad = self.entry_unidad.get().strip()
        fecha = datetime.now().strftime("%d/%m/%Y")

        if not nombre or not precio or not stock or not unidad:
            self.info_text.insert(tk.END, "\n[!] Por favor, complete todos los campos.\n")
            return

        try:
            precio = float(precio)
            stock = int(stock)
        except ValueError:
            self.info_text.insert(tk.END, "\n[!] Error: Precio debe ser decimal y stock entero.\n")
            return

        nuevo_producto = Producto(nombre, precio, stock, unidad, fecha)
        self.productos.append(nuevo_producto)
        self.actualizar_tabla()
        self.limpiar_campos()
        self.info_text.insert(tk.END, f"\n[+] Producto '{nombre}' agregado correctamente.\n")

    def actualizar_tabla(self):
        for fila in self.tree.get_children():
            self.tree.delete(fila)

        for prod in self.productos:
            self.tree.insert("", tk.END, values=(prod.nombre, f"S/.{prod.precio:.2f}", prod.stock, prod.unidad, prod.fecha))

    def limpiar_campos(self):
        self.entry_nombre.delete(0, tk.END)
        self.entry_precio.delete(0, tk.END)
        self.entry_stock.delete(0, tk.END)
        self.entry_unidad.delete(0, tk.END)

    def mostrar_info_producto(self):
        item = self.tree.focus()
        if not item:
            self.info_text.insert(tk.END, "\n[!] Seleccione un producto de la tabla.\n")
            return

        valores = self.tree.item(item, "values")
        nombre_seleccionado = valores[0]

        for prod in self.productos:
            if prod.nombre == nombre_seleccionado:
                info = prod.mostrar_informacion()
                self.info_text.insert(tk.END, f"\n{info}\n")
                return

    def actualizar_precio_producto(self):
        item = self.tree.focus()
        if not item:
            self.info_text.insert(tk.END, "\n[!] Seleccione un producto para actualizar el precio.\n")
            return

        valores = self.tree.item(item, "values")
        nombre_seleccionado = valores[0]

        self.info_text.insert(tk.END, f"\nIngrese el nuevo precio para '{nombre_seleccionado}' en la caja de texto y presione Enter.\n")
        self.root.bind("<Return>", lambda e: self.confirmar_actualizacion_precio(nombre_seleccionado))

    def confirmar_actualizacion_precio(self, nombre):
        nuevo_valor = self.info_text.get("end-2l", "end-1l").strip()
        try:
            nuevo_precio = float(nuevo_valor)
            for prod in self.productos:
                if prod.nombre == nombre:
                    prod.actualizar_precio(nuevo_precio)
                    break
            self.actualizar_tabla()
            self.info_text.insert(tk.END, f"\n[✔] Precio actualizado para '{nombre}'.\n")
        except:
            self.info_text.insert(tk.END, f"\n[!] Valor no válido para precio.\n")

    def actualizar_stock_producto(self):
        item = self.tree.focus()
        if not item:
            self.info_text.insert(tk.END, "\n[!] Seleccione un producto para actualizar el stock.\n")
            return

        valores = self.tree.item(item, "values")
        nombre_seleccionado = valores[0]

        self.info_text.insert(tk.END, f"\nIngrese el nuevo stock para '{nombre_seleccionado}' en la caja de texto y presione Enter.\n")
        self.root.bind("<Return>", lambda e: self.confirmar_actualizacion_stock(nombre_seleccionado))

    def confirmar_actualizacion_stock(self, nombre):
        nuevo_valor = self.info_text.get("end-2l", "end-1l").strip()
        try:
            nuevo_stock = int(nuevo_valor)
            for prod in self.productos:
                if prod.nombre == nombre:
                    prod.actualizar_stock(nuevo_stock)
                    break
            self.actualizar_tabla()
            self.info_text.insert(tk.END, f"\n[✔] Stock actualizado para '{nombre}'.\n")
        except:
            self.info_text.insert(tk.END, f"\n[!] Valor no válido para stock.\n")

if __name__ == "__main__":
    root = tk.Tk()
    app = AppProductos(root)
    root.mainloop()
