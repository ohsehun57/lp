class Doctor:
    def __init__(self, nombre, especialidad, experiencia):
        self.nombre = nombre
        self.especialidad = especialidad
        self.edad = experiencia

    def diagnosticar(self, paciente):
        print(f"un(a) Dr(a). {self.nombre} ha diagnosticado a {paciente}")

    def operar(self, tipo_cirugia):
        print(f"un(a) Dr(a).{self.nombre} realizó una cirugía de tipo: {tipo_cirugia}")

    def descansar(self, años):
        print(f"un(a) Dr(a). {self.nombre} tiene una experiencia {años} años")

# Creación de objetos
doctor1 = Doctor("Carlos", "Cardiología", 45)
doctor2 = Doctor("carla", "Pediatría", 38)

# Uso de métodos
print("\n----Acciones del Dr. Carlos---")
doctor1.diagnosticar("Juan Pérez")
doctor1.operar("bypass coronario")
doctor1.descansar(6)

print("\n----Acciones de la Dra. carla---")
doctor2.diagnosticar("María López")
doctor2.operar("apendicectomía")
doctor2.descansar(8)
