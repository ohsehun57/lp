class Persona:
    def __init__(self, nombre, edad):
        self.nombre = nombre
        self.edad = edad
    
    def mostrar_info(self):
        return f"Nombre: {self.nombre}, Edad: {self.edad}"

# Creación de un objeto
persona1 = Persona("Raúl", 25)
print(persona1.mostrar_info())
