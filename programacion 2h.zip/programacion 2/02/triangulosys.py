import sys
import math

class pitqgoras:
    def __init__(self,c1,c2):
        self.c1=c1
        self.c2=c2

    def calcular_hipotenusa(self):
        return math.sqrt(self.c1**2 +self.c2**2)
t1 =pitqgoras(3,4)
print(f"hipotenusa{t1.calcular_hipotenusa()}")
print(f"tamaño en memoria(bytes)")
tamaño_objeto=sys.getsizeof(t1)
tamaño_objeto1=sys.getsizeof(t1.c1)
tamaño_objeto2=sys.getsizeof(t1.c2)
tam_tamaño=sys.getsizeof(t1.calcular_hipotenusa)
tam_tamaño_class=sys.getsizeof(pitqgoras)


print(f"objeto triangulo:  {tamaño_objeto} bytes")
print(f"objeto c1:  {tamaño_objeto1} bytes")
print(f"objeto c2:  {tamaño_objeto2} bytes")
print(f"metodo calcular_hipotenusa:  {tam_tamaño} bytes")
print(f"clase :  {tam_tamaño_class} bytes")


suma_total = tamaño_objeto+tam_tamaño_class+tamaño_objeto1+tamaño_objeto2+tam_tamaño
print(f"suma total del uso de memoria : {suma_total} bytes")