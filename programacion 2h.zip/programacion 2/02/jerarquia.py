######################jerarquia multiple####################""""
"""""
class Base:
    def __init__(self, base):
        self.base = base

class Altura:
    def __init__(self, altura):
        self.altura = altura

class Triangulo(Base, Altura):
    def __init__(self, base, altura):
        Base.__init__(self, base)
        Altura.__init__(self, altura)

    def area(self):
        return (self.base * self.altura) / 2

# Prueba
t = Triangulo(10, 5)
print(f"base: {t.base}")
print(f"altura: {t.altura}")
print(f"área del triángulo: {t.area()} unidades al cuadrado")
###################################3jerarquia arbol###############"""""

class Figura:
    def __init__(self, nombre):
        self.nombre = nombre

    def mostrar_nombre(self):
        print(f"Soy una figura: {self.nombre}")

class Cuadrado(Figura):
    def __init__(self, lado):
        super().__init__("Cuadrado")
        self.lado = lado

    def area(self):
        return self.lado ** 2

class Triangulo(Figura):
    def __init__(self, base, altura):
        super().__init__("Triangulo")
        self.base = base
        self.altura = altura

    def area(self):
        return (self.base * self.altura) / 2

class Circulo(Figura):
    def __init__(self, radio):
        super().__init__("Circulo")
        self.radio = radio

    def area(self):
        return self.radio ** 2 * 3.14


figuras = [Cuadrado(4), Triangulo(3, 4), Circulo(5)]

for figura in figuras:
    figura.mostrar_nombre()
    print(f"Área: {figura.area()} unidades al cuadrado\n")
