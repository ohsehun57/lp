import tkinter as tk
from tkinter import messagebox

class Doctor:
    def __init__(self, nombre, especialidad, experiencia, correo, telefono, hospital):
        self.nombre = nombre
        self.especialidad = especialidad
        self.experiencia = experiencia
        self.correo = correo
        self.telefono = telefono
        self.hospital = hospital

    def mostrar_informacion(self):
        return (
            f"👨‍⚕️ Nombre: {self.nombre}\n"
            f"📌 Especialidad: {self.especialidad}\n"
            f"📅 Experiencia: {self.experiencia} años\n"
            f"📧 Correo: {self.correo}\n"
            f"📞 Teléfono: {self.telefono}\n"
            f"🏥 Hospital: {self.hospital}"
        )

    def atender_paciente(self, paciente):
        return f"🩺 El Dr. {self.nombre} está atendiendo a {paciente}."

    def calcular_salario(self):
        salario_base = 2001
        bono_experiencia = self.experiencia * 150
        salario_total = salario_base + bono_experiencia
        return f"💵 El salario del Dr. {self.nombre} es ${salario_total}"

    def recetar_medicamento(self, medicamento):
        return f"💊 El Dr. {self.nombre} receta: {medicamento}"

# Lista de doctores
doctores = {
    "Dr. Carlos": Doctor("Carlos", "Cardiología", 15, "carlos@hospital.com", "987654321", "Hospital Central"),
    "Dr. Raul": Doctor("Raul", "Dentista", 5, "raul@clinicadental.com", "945123789", "Clínica Sonrisas"),
    "Dra. Ana": Doctor("Ana", "Pediatría", 12, "ana@hospitalninos.com", "943222111", "Hospital Infantil"),
    "Dr. Javier": Doctor("Javier", "Neurología", 18, "javier@neuroclinic.com", "951334455", "NeuroClinic Perú"),
    "Dra. Lucia": Doctor("Lucia", "Dermatología", 8, "lucia@dermasalud.com", "900112233", "DermaSalud")
}

# Funciones para GUI
def seleccionar_doctor(event=None):
    global doctor_actual
    nombre_doctor = doctor_var.get()
    doctor_actual = doctores[nombre_doctor]
    actualizar_info()

def actualizar_info():
    info_label.config(text=doctor_actual.mostrar_informacion())

def atender():
    paciente = paciente_entry.get()
    if paciente:
        resultado = doctor_actual.atender_paciente(paciente)
        messagebox.showinfo("Atención al Paciente", resultado)
    else:
        messagebox.showwarning("Error", "Ingrese el nombre del paciente")

def calcular_salario():
    resultado = doctor_actual.calcular_salario()
    messagebox.showinfo("Cálculo de Salario", resultado)

def recetar():
    medicamento = medicamento_entry.get()
    if medicamento:
        resultado = doctor_actual.recetar_medicamento(medicamento)
        messagebox.showinfo("Receta Médica", resultado)
    else:
        messagebox.showwarning("Error", "Ingrese el medicamento")

# ----------------- INTERFAZ GRÁFICA -----------------
ventana = tk.Tk()
ventana.title("Sistema de Gestión Médica")
ventana.geometry("520x550")
ventana.configure(bg="#e0f7fa")

tk.Label(ventana, text="🩺 Panel de Gestión de Doctores", font=("Helvetica", 16, "bold"), bg="#e0f7fa", fg="#00695c").pack(pady=10)

# Menú de selección
doctor_var = tk.StringVar(value="Dr. Carlos")
doctor_menu = tk.OptionMenu(ventana, doctor_var, *doctores.keys(), command=seleccionar_doctor)
doctor_menu.config(bg="#80cbc4", fg="black", font=("Arial", 10, "bold"))
doctor_menu.pack(pady=10)

# Frame para información
frame_info = tk.Frame(ventana, bg="#b2ebf2", bd=2, relief="solid")
frame_info.pack(padx=20, pady=10, fill="both")

info_label = tk.Label(frame_info, text="", font=("Arial", 11), justify="left", bg="#b2ebf2", anchor="w")
info_label.pack(padx=10, pady=10, fill="both")

# Entrada paciente
tk.Label(ventana, text="👤 Nombre del paciente:", bg="#e0f7fa", font=("Arial", 10, "bold")).pack()
paciente_entry = tk.Entry(ventana)
paciente_entry.pack(pady=5)

tk.Button(ventana, text="Atender Paciente", bg="#4db6ac", fg="white", command=atender).pack(pady=5)

# Salario
tk.Button(ventana, text="Calcular Salario", bg="#00796b", fg="white", command=calcular_salario).pack(pady=5)

# Receta
tk.Label(ventana, text="💊 Medicamento:", bg="#e0f7fa", font=("Arial", 10, "bold")).pack()
medicamento_entry = tk.Entry(ventana)
medicamento_entry.pack(pady=5)

tk.Button(ventana, text="Recetar Medicamento", bg="#26a69a", fg="white", command=recetar).pack(pady=5)

# Inicializar
doctor_actual = doctores["Dr. Carlos"]
actualizar_info()

ventana.mainloop()
