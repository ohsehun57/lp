import tkinter as tk
from tkinter import ttk

class Producto:
    def __init__(self, nombre, precio):
        self._nombre = nombre
        self._precio = precio

    def obtener_nombre(self):
        return self._nombre

    def obtener_precio(self):
        return self._precio

    def establecer_nombre(self, nuevo_nombre):
        self._nombre = nuevo_nombre

    def establecer_precio(self, nuevo_precio):
        if nuevo_precio >= 0:
            self._precio = nuevo_precio
            return True
        return False

    def calcular_igv(self):
        return self._precio * 0.18

    def calcular_precio_total(self):
        return self._precio * 1.18

    def aplicar_descuento(self, porcentaje):
        return self._precio * (1 - porcentaje / 100)


class ProductoApp:
    def __init__(self, root):
        self.root = root
        self.root.title("🌿 Gestor de Productos Pro")
        self.root.geometry("750x450")
        self.root.configure(bg="#f0f4f7")

        self.producto = None

        self.nombre_var = tk.StringVar()
        self.precio_var = tk.StringVar()
        self.nuevo_precio_var = tk.StringVar()
        self.descuento_var = tk.StringVar()

        self._crear_widgets()

    def _crear_widgets(self):
        # Título
        titulo = tk.Label(self.root, text="Gestor de Productos", bg="#f0f4f7",
                          font=("Arial", 20, "bold"), fg="#333")
        titulo.pack(pady=10)

        # Frame de entradas
        frame_entradas = tk.Frame(self.root, bg="#f0f4f7")
        frame_entradas.pack(pady=5)

        # Nombre
        tk.Label(frame_entradas, text="Nombre:", bg="#f0f4f7").grid(row=0, column=0, padx=5)
        tk.Entry(frame_entradas, textvariable=self.nombre_var, width=20).grid(row=0, column=1)

        # Precio
        tk.Label(frame_entradas, text="Precio:", bg="#f0f4f7").grid(row=0, column=2, padx=5)
        tk.Entry(frame_entradas, textvariable=self.precio_var, width=10).grid(row=0, column=3)

        # Nuevo precio
        tk.Label(frame_entradas, text="Nuevo precio:", bg="#f0f4f7").grid(row=1, column=0, pady=5)
        tk.Entry(frame_entradas, textvariable=self.nuevo_precio_var, width=10).grid(row=1, column=1)

        # Descuento
        tk.Label(frame_entradas, text="Descuento %:", bg="#f0f4f7").grid(row=1, column=2)
        tk.Entry(frame_entradas, textvariable=self.descuento_var, width=10).grid(row=1, column=3)

        # Frame botones
        frame_botones = tk.Frame(self.root, bg="#f0f4f7")
        frame_botones.pack(pady=10)

        botones = [
            ("Crear", self.crear_producto),
            ("Mostrar Info", self.mostrar_info),
            ("Actualizar Precio", self.actualizar_precio),
            ("Aplicar Descuento", self.aplicar_descuento),
            ("Duplicar Producto", self.duplicar_producto),
            ("Eliminar Producto", self.eliminar_producto),
            ("Resumen Rápido", self.resumen_rapido),
            ("Limpiar", self.limpiar),
            ("Salir", self.root.destroy)
        ]

        for i, (texto, comando) in enumerate(botones):
            tk.Button(frame_botones, text=texto, width=15, bg="#d9edf7", fg="#333",
                      command=comando).grid(row=i // 3, column=i % 3, padx=6, pady=4)

        # Área de información
        self.info_text = tk.Text(self.root, height=10, width=90, wrap=tk.WORD, bg="#ffffff", fg="#222")
        self.info_text.pack(padx=10, pady=10)
        self.info_text.config(state=tk.DISABLED)

    def crear_producto(self):
        nombre = self.nombre_var.get().strip()
        try:
            precio = float(self.precio_var.get())
        except ValueError:
            self._mostrar("❌ Precio inválido.")
            return

        if not nombre:
            self._mostrar("❌ Ingrese un nombre.")
            return

        if precio < 0:
            self._mostrar("❌ El precio no puede ser negativo.")
            return

        self.producto = Producto(nombre, precio)
        self._mostrar(f"✅ Producto '{nombre}' creado con precio S/ {precio:.2f}")

    def mostrar_info(self):
        if not self.producto:
            self._mostrar("⚠️ Primero debe crear un producto.")
            return

        nombre = self.producto.obtener_nombre()
        precio = self.producto.obtener_precio()
        igv = self.producto.calcular_igv()
        total = self.producto.calcular_precio_total()

        info = f"📦 Producto: {nombre}\n💵 Precio: S/ {precio:.2f}\n🧾 IGV (18%): S/ {igv:.2f}\n💰 Total con IGV: S/ {total:.2f}"
        self._mostrar(info)

    def actualizar_precio(self):
        if not self.producto:
            self._mostrar("⚠️ Primero debe crear un producto.")
            return

        try:
            nuevo = float(self.nuevo_precio_var.get())
        except ValueError:
            self._mostrar("❌ Precio inválido.")
            return

        if self.producto.establecer_precio(nuevo):
            self._mostrar(f"🔁 Precio actualizado a S/ {nuevo:.2f}")
        else:
            self._mostrar("❌ El precio debe ser mayor o igual a 0.")

    def aplicar_descuento(self):
        if not self.producto:
            self._mostrar("⚠️ Primero debe crear un producto.")
            return

        try:
            descuento = float(self.descuento_var.get())
            if not (0 < descuento < 100):
                self._mostrar("⚠️ El descuento debe estar entre 1 y 99.")
                return
        except ValueError:
            self._mostrar("❌ Descuento inválido.")
            return

        nuevo_precio = self.producto.aplicar_descuento(descuento)
        self._mostrar(f"🔽 Precio con {descuento:.0f}% de descuento: S/ {nuevo_precio:.2f}")

    def duplicar_producto(self):
        if not self.producto:
            self._mostrar("⚠️ Primero debe crear un producto.")
            return

        duplicado = Producto(self.producto.obtener_nombre() + " (copia)", self.producto.obtener_precio())
        self.producto = duplicado
        self._mostrar(f"📎 Producto duplicado como '{duplicado.obtener_nombre()}'")

    def eliminar_producto(self):
        if self.producto:
            nombre = self.producto.obtener_nombre()
            self.producto = None
            self._mostrar(f"🗑️ Producto '{nombre}' eliminado.")
        else:
            self._mostrar("⚠️ No hay producto para eliminar.")

    def resumen_rapido(self):
        if not self.producto:
            self._mostrar("⚠️ No hay producto.")
            return

        nombre = self.producto.obtener_nombre()
        precio = self.producto.obtener_precio()
        total = self.producto.calcular_precio_total()
        self._mostrar(f"{nombre} cuesta S/ {precio:.2f} (S/ {total:.2f} con IGV)")

    def limpiar(self):
        self.nombre_var.set("")
        self.precio_var.set("")
        self.nuevo_precio_var.set("")
        self.descuento_var.set("")
        self.producto = None
        self._mostrar("🧹 Datos limpiados.")

    def _mostrar(self, texto):
        self.info_text.config(state=tk.NORMAL)
        self.info_text.delete("1.0", tk.END)
        self.info_text.insert(tk.END, texto)
        self.info_text.config(state=tk.DISABLED)


if __name__ == "__main__":
    root = tk.Tk()
    app = ProductoApp(root)
    root.mainloop()
