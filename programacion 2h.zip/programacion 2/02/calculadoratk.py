import tkinter as tk
from tkinter import ttk

class CalculadoraBasica:
    def __init__(self, numero1=0, numero2=0):
        self.__numero1 = numero1
        self.__numero2 = numero2

    def establecer_numero1(self, valor):
        self.__numero1 = valor

    def establecer_numero2(self, valor):
        self.__numero2 = valor

    def suma(self):
        return self.__numero1 + self.__numero2

    def resta(self):
        return self.__numero1 - self.__numero2

    def multiplicacion(self):
        return self.__numero1 * self.__numero2

    def division(self):
        if self.__numero2 != 0:
            return round(self.__numero1 / self.__numero2, 2)
        return "\u274c error: divisi\u00f3n entre cero"

class InterfazCalculadora:
    def __init__(self, root):
        self.root = root
        self.root.title("Calculadora Profesional - Ra\u00fal Chura")
        self.root.geometry("450x500")
        self.root.config(bg="#eaf6ff")

        self.calculadora = CalculadoraBasica()

        estilo = ttk.Style()
        estilo.theme_use("clam")
        estilo.configure("TButton", font=("Segoe UI", 11), padding=10)
        estilo.configure("TLabel", font=("Segoe UI", 11))

        # Titulo
        titulo = tk.Label(root, text="Calculadora B\u00e1sica con Estilo",
                          font=("Segoe UI", 18, "bold"), bg="#eaf6ff", fg="#0a3d62")
        titulo.pack(pady=15)

        # Entradas
        self.crear_entrada("N\u00famero 1:", "entrada1")
        self.crear_entrada("N\u00famero 2:", "entrada2")

        # Botones
        botones_frame = ttk.Frame(root)
        botones_frame.pack(pady=20)

        self.crear_boton(botones_frame, "➕ Sumar", self.mostrar_suma, 0, 0)
        self.crear_boton(botones_frame, "➖ Restar", self.mostrar_resta, 0, 1)
        self.crear_boton(botones_frame, "✖️ Multiplicar", self.mostrar_multiplicacion, 1, 0)
        self.crear_boton(botones_frame, "➗ Dividir", self.mostrar_division, 1, 1)

        # Resultado
        self.resultado = tk.Label(root, text="", bg="#ffffff", fg="#00695c", 
                                  font=("Segoe UI", 13, "bold"), relief="solid", padx=10, pady=10, width=40)
        self.resultado.pack(pady=15)

        # Mensaje de error
        self.mensaje_error = tk.Label(root, text="", bg="#eaf6ff", fg="red", font=("Segoe UI", 10))
        self.mensaje_error.pack()

        # Pie de pagina
        tk.Label(root, text="Desarrollado por Ra\u00fal Chura - Examen Final",
                 bg="#eaf6ff", font=("Segoe UI", 9, "italic"), fg="#636e72").pack(side="bottom", pady=5)

    def crear_entrada(self, texto, atributo):
        etiqueta = ttk.Label(self.root, text=texto)
        etiqueta.pack()
        entrada = ttk.Entry(self.root, font=("Segoe UI", 11), justify="center")
        entrada.pack(pady=5)
        setattr(self, atributo, entrada)

    def crear_boton(self, frame, texto, comando, fila, columna):
        boton = ttk.Button(frame, text=texto, command=comando)
        boton.grid(row=fila, column=columna, padx=12, pady=8)

    def obtener_valores(self):
        self.mensaje_error.config(text="")
        try:
            a = float(self.entrada1.get())
            b = float(self.entrada2.get())
            self.calculadora.establecer_numero1(a)
            self.calculadora.establecer_numero2(b)
            return True
        except ValueError:
            self.resultado.config(text="")
            self.mensaje_error.config(text="⚠️ Error: Ingrese valores num\u00e9ricos v\u00e1lidos.")
            return False

    def mostrar_suma(self):
        if self.obtener_valores():
            self.resultado.config(text=f"✅ Suma: {self.calculadora.suma()}")

    def mostrar_resta(self):
        if self.obtener_valores():
            self.resultado.config(text=f"✅ Resta: {self.calculadora.resta()}")

    def mostrar_multiplicacion(self):
        if self.obtener_valores():
            self.resultado.config(text=f"✅ Multiplicaci\u00f3n: {self.calculadora.multiplicacion()}")

    def mostrar_division(self):
        if self.obtener_valores():
            self.resultado.config(text=f"✅ Divisi\u00f3n: {self.calculadora.division()}")

if __name__ == "__main__":
    root = tk.Tk()
    app = InterfazCalculadora(root)
    root.mainloop()
