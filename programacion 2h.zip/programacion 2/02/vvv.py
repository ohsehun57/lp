import os
import argparse
from PIL import Image

def convert_images_to_pdf(input_folder, output_folder=None):
    """
    Convierte todas las imágenes JPG y PNG en una carpeta a archivos PDF individuales.

    Args:
        input_folder (str): Ruta a la carpeta con las imágenes
        output_folder (str, optional): Ruta de la carpeta de salida. Si no se proporciona,
                                         se usará una subcarpeta 'pdf' dentro de la carpeta de entrada.
    """
    # Si no se proporciona carpeta de salida, crear una subcarpeta 'pdf'
    if output_folder is None:
        output_folder = os.path.join(input_folder, "pdf")

    # Crear la carpeta de salida si no existe
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)
        print(f"Carpeta de salida creada: {output_folder}")

    # Extensiones de imagen soportadas
    supported_extensions = ['.jpg', '.jpeg', '.png']

    # Contador de archivos procesados
    converted_count = 0

    # Recorrer todos los archivos en la carpeta
    for filename in os.listdir(input_folder):
        # Obtener la extensión del archivo
        _, extension = os.path.splitext(filename)

        # Comprobar si es una imagen soportada
        if extension.lower() in supported_extensions:
            # Ruta completa de la imagen
            image_path = os.path.join(input_folder, filename)

            try:
                # Abrir la imagen
                image = Image.open(image_path)

                # Convertir imagen a modo RGB si es necesario (para archivos PNG con transparencia)
                if image.mode != 'RGB':
                    image = image.convert('RGB')

                # Nombre del archivo PDF de salida (mismo nombre pero con extensión .pdf)
                pdf_filename = os.path.splitext(filename)[0] + '.pdf'
                pdf_path = os.path.join(output_folder, pdf_filename)

                # Guardar la imagen como PDF
                image.save(pdf_path, "PDF", resolution=100.0)

                print(f"Convertido: {filename} -> {pdf_filename}")
                converted_count += 1

            except FileNotFoundError:
                print(f"Error: No se encontró el archivo {filename}")
            except Exception as e:
                print(f"Error al procesar {filename}: {e}")

    print(f"\nProceso completado. {converted_count} archivos convertidos a PDF.")
    print(f"Los archivos PDF se guardaron en: {output_folder}")

if __name__ == "__main__":
    # Configurar el parser de argumentos
    parser = argparse.ArgumentParser(description='Convierte imágenes JPG y PNG a PDF')
    parser.add_argument('input_folder', help='fotos')
    parser.add_argument('--output_folder', help='Carpeta donde guardar los PDFs (opcional)')

    # Analizar los argumentos
    args = parser.parse_args()

    # Ejecutar la conversión
    convert_images_to_pdf(args.input_folder, args.output_folder)