""""
#clase base o interfas
class curso:
    def calcular_nota_final(self):
        pass
#class con comportamientos diferentes}
class curso_teorico(curso):
    def __init__(self,examen,tareas):
        self.examen=examen
        self.tareas=tareas

    def calcular_nota_final(self):
        
        return 0.7*self.examen + 0.3*self.tareas

class cursopractico(curso):
    def __init__(self,practicas,asistencia):
        self.practicas=practicas
        self.asistencia=asistencia

    def calcular_nota_final(self):
        return 0.8*self.practicas +0.2*self.asistencia
    
class curso_proyecto(curso):
    def __init__(self,proyecto,expocicion):
        self.proyecto=proyecto
        self.expocicion=expocicion

    def calcular_nota_final(self):
        return 0.6*self.proyecto +0.4*self.expocicion
    
#uso polimorfico
cursos=[curso_teorico(examen=16,tareas=18),
       cursopractico(practicas=17,asistencia=19),
       curso_proyecto(proyecto=18,expocicion=17)]

for curso in cursos:
    print("nota final: " ,curso.calcular_nota_final())
    """
###################3dibujar figura
"""
class Figura:
    def dibujar(self):
        print("No se puede dibujar una figura genérica.")


class Cuadrado(Figura):
    def __init__(self, lado):
        self.lado = lado

    def dibujar(self):
        print("Cuadrado:")
        for _ in range(self.lado):
            print("■ " * self.lado)


class Triangulo(Figura):
    def __init__(self, altura):
        self.altura = altura

    def dibujar(self):
        print("Triángulo:")
        for i in range(1, self.altura + 1):
            print("▲ " * i)

class Circulo(Figura):
    def dibujar(self):
        print("Círculo (aproximado):")
        print("   ●●●   ")
        print(" ●     ● ")
        print("●       ●")
        print(" ●     ● ")
        print("   ●●●   ")

class Circulo(Figura):
    def __init__(self, radio):
        self.radio = radio

    def dibujar(self):
        print("Círculo :")
       
        for _ in range(self.radio):
            print("●"+" "*(self.radio)+"●")

figuras = [Cuadrado(3), Triangulo(4), Circulo(7)]

# Dibujar todas las figuras usando polimorfismo
for figura in figuras:
    figura.dibujar()
    print()
###################################################################3

import math

class Figura:
    def dibujar(self):
        print("No se puede calcular el perímetro de una figura genérica.")

    def calcular_perimetro(self):
        return 0

class Cuadrado(Figura):
    def __init__(self, lado):
        self.lado = lado

    def dibujar(self):
        print("Cuadrado")

    def calcular_perimetro(self):
        return 4 * self.lado


class Rectangulo(Figura):
    def __init__(self, base, altura):
        self.base = base
        self.altura = altura

    def dibujar(self):
        print("Rectángulo")

    def calcular_perimetro(self):
        return 2 * (self.base + self.altura)

class Circulo(Figura):
    def __init__(self, radio):
        self.radio = radio

    def dibujar(self):
        print("Círculo")

    def calcular_perimetro(self):
        return 2 * math.pi * self.radio

figuras = [
    Cuadrado(lado=5),
    Rectangulo(base=4, altura=7),
    Circulo(radio=3)
]


for figura in figuras:
    figura.dibujar()
    print(f"Perímetro: {figura.calcular_perimetro():.2f}")
    print()


"""
"""
class Pago:
    def procesar_pago(self):
        print("No se puede procesar un pago genérico.")

    def mostrar_metodo(self):
        print("Método de pago genérico.")

class PagoTarjetaCredito(Pago):
    def __init__(self, monto, numero_tarjeta):
        self.monto = monto
        self.numero_tarjeta = numero_tarjeta

    def mostrar_metodo(self):
        print("Pago con Tarjeta de Crédito")

    def procesar_pago(self):
        return f"Procesando pago de s/{self.monto:.2f} con tarjeta {self.numero_tarjeta[-4:]}..."


class PagoPayPal(Pago):
    def __init__(self, monto, correo):
        self.monto = monto
        self.correo = correo

    def mostrar_metodo(self):
        print("Pago con PayPal")

    def procesar_pago(self):
        return f"Procesando pago de s/{self.monto:.2f} mediante PayPal a la cuenta {self.correo}..."


class PagoCriptomoneda(Pago):
    def __init__(self, monto, wallet):
        self.monto = monto
        self.wallet = wallet

    def mostrar_metodo(self):
        print("Pago con Criptomoneda")

    def procesar_pago(self):
        return f"Procesando pago de s/{self.monto:.2f} desde la wallet {self.wallet[:6]}..."


pagos = [
    PagoTarjetaCredito(monto=100.0, numero_tarjeta="1234567890123456"),
    PagoPayPal(monto=75.5, correo="raulc.com"),
    PagoCriptomoneda(monto=250.75, wallet="dghdgfg")
]

for pago in pagos:
    pago.mostrar_metodo()
    print(pago.procesar_pago())
    print()
    """
import tkinter as tk
from tkinter import ttk
import re # Importar para expresiones regulares

# === CLASES POLIMÓRFICAS ===
class Pago:
    """Clase base para métodos de pago, demostrando polimorfismo."""
    def procesar_pago(self):
        """Método para procesar el pago, a ser implementado por subclases."""
        return "No se puede procesar un pago genérico."

    def mostrar_metodo(self):
        """Método para retornar el nombre del método de pago."""
        return "Método de pago genérico."

class PagoTarjetaCredito(Pago):
    """Clase para pagos con Tarjeta de Crédito."""
    def __init__(self, monto, numero_tarjeta, destino):
        self.monto = monto
        self.numero_tarjeta = numero_tarjeta
        self.destino = destino # Nuevo campo para el destino

    def mostrar_metodo(self):
        return "💳 Tarjeta de Crédito"

    def procesar_pago(self):
        # Simula el procesamiento de pago con tarjeta
        return (f"Procesando pago de S/{self.monto:.2f} con tarjeta ****{self.numero_tarjeta[-4:]}\n"
                f"Destino/Referencia: {self.destino}")

class PagoPayPal(Pago):
    """Clase para pagos con PayPal."""
    def __init__(self, monto, correo, destino):
        self.monto = monto
        self.correo = correo
        self.destino = destino # Nuevo campo para el destino

    def mostrar_metodo(self):
        return "📧 PayPal"

    def procesar_pago(self):
        # Simula el procesamiento de pago con PayPal
        return (f"Procesando pago de S/{self.monto:.2f} a la cuenta PayPal {self.correo}\n"
                f"Destino/Referencia: {self.destino}")

class PagoCriptomoneda(Pago):
    """Clase para pagos con Criptomoneda."""
    def __init__(self, monto, wallet, destino):
        self.monto = monto
        self.wallet = wallet
        self.destino = destino # Nuevo campo para el destino

    def mostrar_metodo(self):
        return "🪙 Criptomoneda"

    def procesar_pago(self):
        # Simula el procesamiento de pago con criptomoneda
        return (f"Procesando pago de S/{self.monto:.2f} desde wallet {self.wallet[:6]}...\n"
                f"Destino/Referencia: {self.destino}")

# === INTERFAZ GRÁFICA CON TKINTER ===
class InterfazPagos:
    """Clase para la interfaz gráfica del sistema de pagos."""
    def __init__(self, root):
        self.root = root
        self.root.title("Sistema de Pagos Completo y Robusto")
        self.root.geometry("650x700") # Aumentar un poco el tamaño para el nuevo campo
        self.root.resizable(False, False) # Evita que la ventana sea redimensionable
        self.root.config(bg="#e0f7fa") # Un azul claro más brillante como fondo

        # Configuración de estilos para los widgets
        self.style = ttk.Style()
        self.style.theme_use('clam') # Un tema más moderno para ttk

        self.style.configure('TFrame', background='#e0f7fa')
        self.style.configure('TLabel', background='#e0f7fa', foreground='#263238', font=("Inter", 11))
        self.style.configure('TButton', font=("Inter", 12, "bold"), background='#00796b', foreground='white',
                             padding=[15, 10], relief="flat", borderwidth=0, focusthickness=0) # Más padding y sin borde de foco
        self.style.map('TButton', background=[('active', '#004d40')], foreground=[('active', 'white')]) # Efecto hover

        self.style.configure('TEntry', fieldbackground='#ffffff', foreground='#263238', font=("Inter", 11),
                             padding=8, relief="flat", borderwidth=1, bordercolor="#b0bec5") # Más padding y borde suave

        self.style.configure('TLabelframe', background='#e0f7fa', foreground='#004d40', font=("Inter", 13, "bold"),
                             padding=[10, 5, 10, 10]) # Estilo para los LabelFrame
        self.style.configure('TLabelframe.Label', background='#e0f7fa', foreground='#004d40') # Estilo para el texto del LabelFrame

        self.style.configure('TRadiobutton', background='#e0f7fa', foreground='#263238', font=("Inter", 11))

        # Título de la aplicación
        title_frame = ttk.Frame(root, padding="20 20 20 20")
        title_frame.pack(pady=(20, 10))
        titulo = ttk.Label(title_frame, text="SISTEMA DE PAGOS SEGURO", font=("Inter", 24, "bold"), foreground="#004d40")
        titulo.pack()

        # Marco para la selección del método de pago
        method_frame = ttk.LabelFrame(root, text="Seleccione Método de Pago", padding="15 20 15 15")
        method_frame.pack(pady=10, padx=30, fill="x")

        self.payment_method_var = tk.StringVar()
        self.payment_method_var.set("Tarjeta de Crédito") # Valor por defecto

        # Opciones de radio button para seleccionar el método
        rb_tarjeta = ttk.Radiobutton(method_frame, text="Tarjeta de Crédito", variable=self.payment_method_var,
                                     value="Tarjeta de Crédito", command=self.update_input_fields)
        rb_tarjeta.grid(row=0, column=0, padx=15, pady=8, sticky="w")

        rb_paypal = ttk.Radiobutton(method_frame, text="PayPal", variable=self.payment_method_var,
                                    value="PayPal", command=self.update_input_fields)
        rb_paypal.grid(row=0, column=1, padx=15, pady=8, sticky="w")

        rb_crypto = ttk.Radiobutton(method_frame, text="Criptomoneda", variable=self.payment_method_var,
                                    value="Criptomoneda", command=self.update_input_fields)
        rb_crypto.grid(row=0, column=2, padx=15, pady=8, sticky="w")

        method_frame.columnconfigure(0, weight=1)
        method_frame.columnconfigure(1, weight=1)
        method_frame.columnconfigure(2, weight=1)


        # Marco para la entrada de datos del pago
        input_frame = ttk.Frame(root, padding="15 20 15 15")
        input_frame.pack(pady=10, padx=30, fill="x")

        # Etiqueta y campo de entrada para el monto
        ttk.Label(input_frame, text="Monto (S/):").grid(row=0, column=0, padx=5, pady=10, sticky="w")
        self.monto_entry = ttk.Entry(input_frame, width=35)
        self.monto_entry.grid(row=0, column=1, padx=5, pady=10, sticky="ew")
        self.monto_entry.insert(0, "100.00") # Valor inicial
        self.monto_entry.bind("<KeyRelease>", self.clear_message) # Limpiar mensaje al escribir

        # Campos de entrada dinámicos (se actualizan según el método de pago)
        self.dynamic_label = ttk.Label(input_frame, text="Número de Tarjeta:")
        self.dynamic_label.grid(row=1, column=0, padx=5, pady=10, sticky="w")
        self.dynamic_entry = ttk.Entry(input_frame, width=35)
        self.dynamic_entry.grid(row=1, column=1, padx=5, pady=10, sticky="ew")
        self.dynamic_entry.insert(0, "1234567890123456") # Valor inicial para tarjeta
        self.dynamic_entry.bind("<KeyRelease>", self.clear_message) # Limpiar mensaje al escribir

        # Nuevo campo para el destino/referencia
        ttk.Label(input_frame, text="Destino/Referencia:").grid(row=2, column=0, padx=5, pady=10, sticky="w")
        self.destino_entry = ttk.Entry(input_frame, width=35)
        self.destino_entry.grid(row=2, column=1, padx=5, pady=10, sticky="ew")
        self.destino_entry.insert(0, "Compra de productos en línea") # Valor inicial
        self.destino_entry.bind("<KeyRelease>", self.clear_message) # Limpiar mensaje al escribir


        input_frame.columnconfigure(1, weight=1) # Permite que el campo de entrada se expanda

        # Etiqueta para mensajes de error/información
        self.message_label = ttk.Label(root, text="", font=("Inter", 10, "bold"), foreground="red", background="#e0f7fa")
        self.message_label.pack(pady=(0, 10))

        # Botones de acción
        button_frame = ttk.Frame(root, padding="10 0 10 0")
        button_frame.pack(pady=15)
        btn_procesar = ttk.Button(button_frame, text="Procesar Pago", command=self.procesar_pago_seleccionado)
        btn_procesar.pack(side="left", padx=10)

        btn_limpiar = ttk.Button(button_frame, text="Limpiar Campos", command=self.clear_fields)
        btn_limpiar.pack(side="left", padx=10)

        # Área de resultados
        result_frame = ttk.LabelFrame(root, text="Resultado del Pago", padding="15 15 15 15")
        result_frame.pack(pady=10, padx=30, fill="x", expand=True)
        self.resultado_text = tk.Text(result_frame, height=7, font=("Inter", 12), wrap=tk.WORD,
                                      bg="#fcfcfc", fg="#333333", relief="flat", borderwidth=1,
                                      state="disabled", padx=10, pady=10) # Deshabilitado para solo lectura, con padding
        self.resultado_text.pack(fill="both", expand=True)

        # Inicializa los campos de entrada según la selección por defecto
        self.update_input_fields()

    def _display_message(self, message, is_error=True):
        """Muestra un mensaje al usuario (error o éxito)."""
        self.message_label.config(text=message, foreground="red" if is_error else "#00796b")
        self.root.update_idletasks() # Asegura que el mensaje se muestre inmediatamente

    def clear_message(self, event=None):
        """Limpia el mensaje mostrado."""
        self.message_label.config(text="")

    def _is_valid_luhn(self, card_number):
        """Valida un número de tarjeta usando el algoritmo de Luhn."""
        digits = [int(d) for d in card_number if d.isdigit()]
        if not digits:
            return False

        total = 0
        num_digits = len(digits)
        for i in range(num_digits - 1, -1, -1):
            digit = digits[i]
            if (num_digits - 1 - i) % 2 == 1: # Doblar cada segundo dígito desde la derecha
                digit *= 2
                if digit > 9:
                    digit -= 9
            total += digit
        return total % 10 == 0

    def update_input_fields(self):
        """Actualiza las etiquetas y placeholders de los campos de entrada dinámicos."""
        self.clear_message() # Limpiar mensaje al cambiar de método
        selected_method = self.payment_method_var.get()
        self.dynamic_entry.delete(0, tk.END) # Limpiar el campo de entrada

        if selected_method == "Tarjeta de Crédito":
            self.dynamic_label.config(text="Número de Tarjeta:")
            self.dynamic_entry.insert(0, "Ej: 1234567890123456")
        elif selected_method == "PayPal":
            self.dynamic_label.config(text="Correo PayPal:")
            self.dynamic_entry.insert(0, "Ej: tu.correo@example.com")
        elif selected_method == "Criptomoneda":
            self.dynamic_label.config(text="Dirección de Wallet:")
            self.dynamic_entry.insert(0, "Ej: bc1q... (Bitcoin) o 0x... (Ethereum)")

    def procesar_pago_seleccionado(self):
        """Procesa el pago según el método seleccionado y los datos ingresados."""
        self.clear_message() # Limpiar cualquier mensaje anterior

        try:
            monto_str = self.monto_entry.get().replace(',', '.') # Aceptar coma como separador decimal
            monto = float(monto_str)
            if monto <= 0:
                self._display_message("Error: El monto debe ser un número positivo. Por favor, corrija el valor.", is_error=True)
                self.monto_entry.focus_set()
                return
        except ValueError:
            self._display_message("Error: Por favor, ingrese un monto válido (número, Ej: 100.00).", is_error=True)
            self.monto_entry.focus_set()
            return

        dynamic_input = self.dynamic_entry.get().strip() # Eliminar espacios en blanco
        destino_input = self.destino_entry.get().strip() # Obtener y limpiar el campo destino

        if not destino_input:
            self._display_message("Error: El campo 'Destino/Referencia' no puede estar vacío.", is_error=True)
            self.destino_entry.focus_set()
            return

        pago = None

        selected_method = self.payment_method_var.get()

        if selected_method == "Tarjeta de Crédito":
            # Eliminar espacios en blanco y guiones del número de tarjeta
            card_number_clean = re.sub(r'[\s-]', '', dynamic_input)
            if not (card_number_clean.isdigit() and 13 <= len(card_number_clean) <= 19 and self._is_valid_luhn(card_number_clean)):
                self._display_message("Error: Número de tarjeta inválido. Debe contener solo dígitos (13-19) y pasar la validación de Luhn.", is_error=True)
                self.dynamic_entry.focus_set()
                return
            pago = PagoTarjetaCredito(monto, card_number_clean, destino_input)
        elif selected_method == "PayPal":
            # Expresión regular más robusta para validar correos electrónicos
            email_regex = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
            if not re.match(email_regex, dynamic_input):
                self._display_message("Error: Correo electrónico de PayPal inválido. Verifique el formato.", is_error=True)
                self.dynamic_entry.focus_set()
                return
            pago = PagoPayPal(monto, dynamic_input, destino_input)
        elif selected_method == "Criptomoneda":
            # Expresiones regulares básicas para BTC y ETH (ejemplos, no exhaustivas)
            btc_regex = r"^(bc1|[13])[a-zA-HJ-NP-Z0-9]{25,39}$" # Bitcoin
            eth_regex = r"^0x[a-fA-F0-9]{40}$" # Ethereum
            if not (re.match(btc_regex, dynamic_input) or re.match(eth_regex, dynamic_input)):
                self._display_message("Error: Dirección de wallet inválida. Verifique el formato de Bitcoin (bc1, 1, 3) o Ethereum (0x).", is_error=True)
                self.dynamic_entry.focus_set()
                return
            pago = PagoCriptomoneda(monto, dynamic_input, destino_input)
        else:
            self._display_message("Error: Método de pago no seleccionado o no reconocido.", is_error=True)
            return

        if pago:
            self.mostrar_resultado(pago)
            self._display_message("Pago procesado exitosamente.", is_error=False)


    def mostrar_resultado(self, metodo_pago):
        """Muestra el resultado del procesamiento del pago en el área de texto."""
        self.resultado_text.config(state="normal") # Habilitar para escribir
        self.resultado_text.delete(1.0, tk.END)
        self.resultado_text.insert(tk.END, f"Método: {metodo_pago.mostrar_metodo()}\n\n")
        self.resultado_text.insert(tk.END, metodo_pago.procesar_pago())
        self.resultado_text.config(state="disabled") # Deshabilitar después de escribir

    def clear_fields(self):
        """Limpia todos los campos de entrada y el área de resultados."""
        self.monto_entry.delete(0, tk.END)
        self.monto_entry.insert(0, "100.00")
        self.dynamic_entry.delete(0, tk.END)
        self.destino_entry.delete(0, tk.END) # Limpiar el nuevo campo de destino
        self.destino_entry.insert(0, "Compra de productos en línea") # Restablecer valor inicial
        self.payment_method_var.set("Tarjeta de Crédito") # Reset to default
        self.update_input_fields() # Update dynamic field based on default
        self.resultado_text.config(state="normal")
        self.resultado_text.delete(1.0, tk.END)
        self.resultado_text.config(state="disabled")
        self.clear_message() # Limpiar mensaje al limpiar campos


# === INICIAR APLICACIÓN ===
if __name__ == "__main__":
    root = tk.Tk()
    app = InterfazPagos(root)
    root.mainloop()

