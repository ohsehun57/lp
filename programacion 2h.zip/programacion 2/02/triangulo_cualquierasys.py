import sys
import math

class Triangulo:
    def __init__(self, lado1, lado2, lado3):
        self.lado1 = lado1
        self.lado2 = lado2
        self.lado3 = lado3

    def calcular_perimetro(self):
        return self.lado1 + self.lado2 + self.lado3

    def calcular_area(self):
        s = self.calcular_perimetro() / 2  
        return math.sqrt(s * (s - self.lado1) * (s - self.lado2) * (s - self.lado3))


def validar_triangulo(l1, l2, l3):
    return (l1 + l2 > l3) and (l1 + l3 > l2) and (l2 + l3 > l1)


try:
    lado1 = float(input("Ingrese el lado 1 del triangulo: "))
    lado2 = float(input("Ingrese el lado 2 del triangulo: "))
    lado3 = float(input("Ingrese el lado 3 del triangulo: "))

    if validar_triangulo(lado1, lado2, lado3):
        tri = Triangulo(lado1, lado2, lado3)
        print(f"Area: {tri.calcular_area()}")
        print(f"Perimetro: {tri.calcular_perimetro()}")

        print(f"\nTamaño en memoria (bytes):")
        tam_objeto = sys.getsizeof(tri)
        tam_lado1 = sys.getsizeof(tri.lado1)
        tam_lado2 = sys.getsizeof(tri.lado2)
        tam_lado3 = sys.getsizeof(tri.lado3)
        tam_area = sys.getsizeof(tri.calcular_area)
        tam_perimetro = sys.getsizeof(tri.calcular_perimetro)
        tam_validar = sys.getsizeof(validar_triangulo)
        tam_clase = sys.getsizeof(Triangulo)

        print(f"Objeto triangulo:  {tam_objeto} bytes")
        print(f"Lado 1:  {tam_lado1} bytes")
        print(f"Lado 2:  {tam_lado2} bytes")
        print(f"Lado 3:  {tam_lado3} bytes")
        print(f"Metodo calcular_area:  {tam_area} bytes")
        print(f"Metodo calcular_perimetro:  {tam_perimetro} bytes")
        print(f"Función validar_triangulo:  {tam_validar} bytes")
        print(f"Clase Triangulo:  {tam_clase} bytes")

        suma_total = tam_objeto + tam_lado1 + tam_lado2 + tam_lado3 + tam_area + tam_perimetro + tam_validar + tam_clase
        print(f"Suma total del uso de memoria: {suma_total} bytes")
    else:
        print("Los lados ingresados no forman un triangulo valido.")

except ValueError:
    print("Por favor, ingrese valores numericos validos.")
