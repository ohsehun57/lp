import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3
import re
import datetime
import os

# --- Helpers (Utility and Validation Functions) ---
def validate_email(email):
    """Validates a simple email format."""
    return re.match(r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$", email)

def validate_phone(phone):
    """Validates a simple phone number format."""
    # Allows numbers, spaces, hyphens, and an optional initial '+'
    return re.match(r"^\+?[\d\s-]{7,20}$", phone)

def validate_positive_number(value, type_func):
    """Validates if a value is a positive number of the specified type."""
    try:
        num = type_func(value)
        return num > 0
    except ValueError:
        return False

# --- Database Manager ---
class DatabaseManager:
    def __init__(self, database_name="asle.db"):
        # Ensures the database is created in the same directory as the script
        self.database_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), database_name)
        self.conn = None

    def _get_connection(self):
        """Establishes and returns a database connection."""
        if self.conn is None:
            self.conn = sqlite3.connect(self.database_path)
            self.conn.row_factory = sqlite3.Row # Allows accessing columns by name
        return self.conn

    def _close_connection(self):
        """Closes the database connection if open."""
        if self.conn:
            self.conn.close()
            self.conn = None

    def create_tables(self):
        """Creates the necessary tables in the database."""
        conn = self._get_connection()
        cursor = conn.cursor()
        try:
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS clients (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    address TEXT,
                    phone TEXT,
                    email TEXT UNIQUE
                )
            ''')
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS products (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL UNIQUE,
                    description TEXT,
                    price REAL NOT NULL,
                    stock INTEGER NOT NULL
                )
            ''')
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS orders (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    client_id INTEGER,
                    order_date TEXT NOT NULL,
                    total_amount REAL NOT NULL,
                    FOREIGN KEY (client_id) REFERENCES clients(id)
                )
            ''')
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS order_details (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    order_id INTEGER,
                    product_id INTEGER,
                    quantity INTEGER NOT NULL,
                    price_at_order REAL NOT NULL,
                    FOREIGN KEY (order_id) REFERENCES orders(id),
                    FOREIGN KEY (product_id) REFERENCES products(id)
                )
            ''')
            conn.commit()
        except sqlite3.Error as e:
            messagebox.showerror("Database Error", f"Error creating tables: {e}")
        finally:
            self._close_connection()

    def insert_data(self, table_name, data):
        """Inserts a new record into the specified table."""
        conn = self._get_connection()
        cursor = conn.cursor()
        columns = ', '.join(data.keys())
        placeholders = ', '.join('?' * len(data))
        sql = f"INSERT INTO {table_name} ({columns}) VALUES ({placeholders})"
        try:
            cursor.execute(sql, tuple(data.values()))
            conn.commit()
            return cursor.lastrowid
        except sqlite3.IntegrityError as e: # For UNIQUE constraints
            if "UNIQUE constraint failed: clients.email" in str(e):
                 messagebox.showerror("Database Error", "Error: Email already exists for another client.")
            elif "UNIQUE constraint failed: products.name" in str(e):
                 messagebox.showerror("Database Error", "Error: A product with this name already exists.")
            else:
                 messagebox.showerror("Database Error", f"Duplication error: {e}")
            return None
        except sqlite3.Error as e:
            messagebox.showerror("Database Error", f"Error inserting data into {table_name}: {e}")
            conn.rollback()
            return None
        finally:
            self._close_connection()

    def fetch_all(self, table_name):
        """Fetches all records from a table."""
        conn = self._get_connection()
        cursor = conn.cursor()
        try:
            cursor.execute(f"SELECT * FROM {table_name}")
            return cursor.fetchall()
        except sqlite3.Error as e:
            messagebox.showerror("Database Error", f"Error fetching data from {table_name}: {e}")
            return []
        finally:
            self._close_connection()

    def fetch_one(self, table_name, record_id):
        """Fetches a specific record by ID."""
        conn = self._get_connection()
        cursor = conn.cursor()
        try:
            cursor.execute(f"SELECT * FROM {table_name} WHERE id = ?", (record_id,))
            return cursor.fetchone()
        except sqlite3.Error as e:
            messagebox.showerror("Database Error", f"Error fetching record from {table_name}: {e}")
            return None
        finally:
            self._close_connection()

    def update_data(self, table_name, record_id, data):
        """Updates an existing record."""
        conn = self._get_connection()
        cursor = conn.cursor()
        set_clause = ', '.join(f"{key} = ?" for key in data.keys())
        sql = f"UPDATE {table_name} SET {set_clause} WHERE id = ?"
        values = list(data.values()) + [record_id]
        try:
            cursor.execute(sql, tuple(values))
            conn.commit()
            return True
        except sqlite3.IntegrityError as e:
            if "UNIQUE constraint failed: clients.email" in str(e):
                 messagebox.showerror("Database Error", "Error: Email already exists for another client.")
            elif "UNIQUE constraint failed: products.name" in str(e):
                 messagebox.showerror("Database Error", "Error: A product with this name already exists.")
            else:
                 messagebox.showerror("Database Error", f"Duplication error: {e}")
            return False
        except sqlite3.Error as e:
            messagebox.showerror("Database Error", f"Error updating data in {table_name}: {e}")
            conn.rollback()
            return False
        finally:
            self._close_connection()

    def delete_data(self, table_name, record_id):
        """Deletes a record by ID."""
        conn = self._get_connection()
        cursor = conn.cursor()
        try:
            cursor.execute(f"DELETE FROM {table_name} WHERE id = ?", (record_id,))
            conn.commit()
            return True
        except sqlite3.IntegrityError: # If trying to delete a client with associated orders, etc.
             messagebox.showerror("Database Error", "Cannot delete this record. It may have relations in other tables (e.g., associated orders).")
             return False
        except sqlite3.Error as e:
            messagebox.showerror("Database Error", f"Error deleting data from {table_name}: {e}")
            conn.rollback()
            return False
        finally:
            self._close_connection()

# --- View Classes (User Interface Views) ---

class ClientView:
    def __init__(self, parent_frame, db_manager):
        self.parent_frame = parent_frame
        self.db_manager = db_manager
        self._create_widgets()
        self.load_clients()

    def _create_widgets(self):
        # Frame for the input form
        input_frame = ttk.LabelFrame(self.parent_frame, text="Client Data", padding=(10, 10, 10, 10))
        input_frame.pack(padx=15, pady=15, fill="x", expand=False)

        # Configure columns to expand
        input_frame.grid_columnconfigure(1, weight=1)

        labels = ["Name:", "Address:", "Phone:", "Email:"]
        self.entries = {}
        for i, text in enumerate(labels):
            ttk.Label(input_frame, text=text).grid(row=i, column=0, padx=5, pady=5, sticky="w")
            entry = ttk.Entry(input_frame)
            entry.grid(row=i, column=1, padx=5, pady=5, sticky="ew")
            self.entries[text.replace(":", "").lower()] = entry

        # Action buttons
        button_frame = ttk.Frame(input_frame)
        button_frame.grid(row=len(labels), column=0, columnspan=2, pady=10)

        ttk.Button(button_frame, text="Add Client", command=self._add_client, style="Accent.TButton").pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Update Client", command=self._update_client).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Clear Fields", command=self._clear_fields).pack(side=tk.LEFT, padx=5)

        # Frame for the client table
        table_frame = ttk.LabelFrame(self.parent_frame, text="Client List", padding=(10, 10, 10, 10))
        table_frame.pack(padx=15, pady=15, fill="both", expand=True)

        columns = ("ID", "Name", "Address", "Phone", "Email")
        self.tree = ttk.Treeview(table_frame, columns=columns, show="headings", selectmode="browse")
        self.tree.pack(side="left", fill="both", expand=True)

        for col in columns:
            self.tree.heading(col, text=col, anchor=tk.W)
            self.tree.column(col, width=120)

        self.tree.column("ID", width=60, stretch=tk.NO)
        self.tree.column("Name", width=180)
        self.tree.column("Address", width=250)
        self.tree.column("Phone", width=120)
        self.tree.column("Email", width=200)

        scrollbar = ttk.Scrollbar(table_frame, orient="vertical", command=self.tree.yview)
        scrollbar.pack(side="right", fill="y")
        self.tree.configure(yscrollcommand=scrollbar.set)

        self.tree.bind("<<TreeviewSelect>>", self._on_client_select)

        delete_button = ttk.Button(self.parent_frame, text="Delete Selected Client", command=self._delete_client, style="Danger.TButton")
        delete_button.pack(pady=10)

    def _add_client(self):
        name = self.entries["nombre"].get().strip()
        address = self.entries["dirección"].get().strip()
        phone = self.entries["teléfono"].get().strip()
        email = self.entries["email"].get().strip()

        if not name:
            messagebox.showerror("Validation Error", "Name is required.")
            return
        if not email:
            messagebox.showerror("Validation Error", "Email is required.")
            return
        if not validate_email(email):
            messagebox.showerror("Validation Error", "Invalid email format.")
            return
        if phone and not validate_phone(phone):
            messagebox.showerror("Validation Error", "Invalid phone format (only numbers, spaces, hyphens, and '+' allowed).")
            return

        client_data = {"name": name, "address": address, "phone": phone, "email": email}
        client_id = self.db_manager.insert_data("clients", client_data)
        if client_id:
            messagebox.showinfo("Success", "Client added successfully.")
            self.load_clients()
            self._clear_fields()

    def _update_client(self):
        selected_item = self.tree.focus()
        if not selected_item:
            messagebox.showwarning("Warning", "Please select a client to update.")
            return

        client_id = self.tree.item(selected_item, "values")[0]
        name = self.entries["nombre"].get().strip()
        address = self.entries["dirección"].get().strip()
        phone = self.entries["teléfono"].get().strip()
        email = self.entries["email"].get().strip()

        if not name:
            messagebox.showerror("Validation Error", "Name is required.")
            return
        if not email:
            messagebox.showerror("Validation Error", "Email is required.")
            return
        if not validate_email(email):
            messagebox.showerror("Validation Error", "Invalid email format.")
            return
        if phone and not validate_phone(phone):
            messagebox.showerror("Validation Error", "Invalid phone format.")
            return

        client_data = {"name": name, "address": address, "phone": phone, "email": email}
        if self.db_manager.update_data("clients", client_id, client_data):
            messagebox.showinfo("Success", "Client updated successfully.")
            self.load_clients()
            self._clear_fields()

    def _delete_client(self):
        selected_item = self.tree.focus()
        if not selected_item:
            messagebox.showwarning("Warning", "Please select a client to delete.")
            return

        client_id = self.tree.item(selected_item, "values")[0]
        if messagebox.askyesno("Confirm Deletion", f"Are you sure you want to delete client with ID {client_id}?"):
            if self.db_manager.delete_data("clients", client_id):
                messagebox.showinfo("Success", "Client deleted successfully.")
                self.load_clients()
                self._clear_fields()

    def load_clients(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        clients = self.db_manager.fetch_all("clients")
        for client in clients:
            self.tree.insert("", "end", values=(client["id"], client["name"], client["address"], client["phone"], client["email"]))

    def _on_client_select(self, event):
        selected_item = self.tree.focus()
        if selected_item:
            values = self.tree.item(selected_item, "values")
            self.entries["nombre"].delete(0, tk.END)
            self.entries["nombre"].insert(0, values[1])
            self.entries["dirección"].delete(0, tk.END)
            self.entries["dirección"].insert(0, values[2])
            self.entries["teléfono"].delete(0, tk.END)
            self.entries["teléfono"].insert(0, values[3])
            self.entries["email"].delete(0, tk.END)
            self.entries["email"].insert(0, values[4])

    def _clear_fields(self):
        for entry in self.entries.values():
            entry.delete(0, tk.END)
        # Ensure no selection in the Treeview
        self.tree.selection_remove(self.tree.focus())

class ProductView:
    def __init__(self, parent_frame, db_manager):
        self.parent_frame = parent_frame
        self.db_manager = db_manager
        self._create_widgets()
        self.load_products()

    def _create_widgets(self):
        input_frame = ttk.LabelFrame(self.parent_frame, text="Product Data", padding=(10, 10, 10, 10))
        input_frame.pack(padx=15, pady=15, fill="x", expand=False)
        input_frame.grid_columnconfigure(1, weight=1)

        labels = ["Name:", "Description:", "Price:", "Stock:"]
        self.entries = {}
        for i, text in enumerate(labels):
            ttk.Label(input_frame, text=text).grid(row=i, column=0, padx=5, pady=5, sticky="w")
            entry = ttk.Entry(input_frame)
            entry.grid(row=i, column=1, padx=5, pady=5, sticky="ew")
            self.entries[text.replace(":", "").lower()] = entry

        button_frame = ttk.Frame(input_frame)
        button_frame.grid(row=len(labels), column=0, columnspan=2, pady=10)

        ttk.Button(button_frame, text="Add Product", command=self._add_product, style="Accent.TButton").pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Update Product", command=self._update_product).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Clear Fields", command=self._clear_fields).pack(side=tk.LEFT, padx=5)

        table_frame = ttk.LabelFrame(self.parent_frame, text="Product List", padding=(10, 10, 10, 10))
        table_frame.pack(padx=15, pady=15, fill="both", expand=True)

        columns = ("ID", "Name", "Description", "Price", "Stock")
        self.tree = ttk.Treeview(table_frame, columns=columns, show="headings", selectmode="browse")
        self.tree.pack(side="left", fill="both", expand=True)

        for col in columns:
            self.tree.heading(col, text=col, anchor=tk.W)
            self.tree.column(col, width=120)

        self.tree.column("ID", width=60, stretch=tk.NO)
        self.tree.column("Name", width=180)
        self.tree.column("Description", width=250)
        self.tree.column("Price", width=90, anchor=tk.E)
        self.tree.column("Stock", width=70, anchor=tk.E)

        scrollbar = ttk.Scrollbar(table_frame, orient="vertical", command=self.tree.yview)
        scrollbar.pack(side="right", fill="y")
        self.tree.configure(yscrollcommand=scrollbar.set)

        self.tree.bind("<<TreeviewSelect>>", self._on_product_select)

        delete_button = ttk.Button(self.parent_frame, text="Delete Selected Product", command=self._delete_product, style="Danger.TButton")
        delete_button.pack(pady=10)

    def _add_product(self):
        name = self.entries["nombre"].get().strip()
        description = self.entries["descripción"].get().strip()
        price_str = self.entries["precio"].get().strip()
        stock_str = self.entries["stock"].get().strip()

        if not name or not price_str or not stock_str:
            messagebox.showerror("Validation Error", "Name, Price, and Stock are required.")
            return

        if not validate_positive_number(price_str, float):
            messagebox.showerror("Validation Error", "Price must be a valid positive number.")
            return
        if not validate_positive_number(stock_str, int):
            messagebox.showerror("Validation Error", "Stock must be a valid positive integer.")
            return

        try:
            price = float(price_str)
            stock = int(stock_str)
        except ValueError:
            messagebox.showerror("Validation Error", "Price or Stock in incorrect format.")
            return

        product_data = {"name": name, "description": description, "price": price, "stock": stock}
        if self.db_manager.insert_data("products", product_data):
            messagebox.showinfo("Success", "Product added successfully.")
            self.load_products()
            self._clear_fields()

    def _update_product(self):
        selected_item = self.tree.focus()
        if not selected_item:
            messagebox.showwarning("Warning", "Please select a product to update.")
            return

        product_id = self.tree.item(selected_item, "values")[0]
        name = self.entries["nombre"].get().strip()
        description = self.entries["descripción"].get().strip()
        price_str = self.entries["precio"].get().strip()
        stock_str = self.entries["stock"].get().strip()

        if not name or not price_str or not stock_str:
            messagebox.showerror("Validation Error", "Name, Price, and Stock are required.")
            return

        if not validate_positive_number(price_str, float):
            messagebox.showerror("Validation Error", "Price must be a valid positive number.")
            return
        if not validate_positive_number(stock_str, int):
            messagebox.showerror("Validation Error", "Stock must be a valid positive integer.")
            return

        try:
            price = float(price_str)
            stock = int(stock_str)
        except ValueError:
            messagebox.showerror("Validation Error", "Price or Stock in incorrect format.")
            return

        product_data = {"name": name, "description": description, "price": price, "stock": stock}
        if self.db_manager.update_data("products", product_id, product_data):
            messagebox.showinfo("Success", "Product updated successfully.")
            self.load_products()
            self._clear_fields()

    def _delete_product(self):
        selected_item = self.tree.focus()
        if not selected_item:
            messagebox.showwarning("Warning", "Please select a product to delete.")
            return

        product_id = self.tree.item(selected_item, "values")[0]
        if messagebox.askyesno("Confirm Deletion", f"Are you sure you want to delete product with ID {product_id}?"):
            if self.db_manager.delete_data("products", product_id):
                messagebox.showinfo("Success", "Product deleted successfully.")
                self.load_products()
                self._clear_fields()

    def load_products(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        products = self.db_manager.fetch_all("products")
        for product in products:
            self.tree.insert("", "end", values=(product["id"], product["name"], product["description"], f"{product['price']:.2f}", product["stock"]))

    def _on_product_select(self, event):
        selected_item = self.tree.focus()
        if selected_item:
            values = self.tree.item(selected_item, "values")
            self.entries["nombre"].delete(0, tk.END)
            self.entries["nombre"].insert(0, values[1])
            self.entries["descripción"].delete(0, tk.END)
            self.entries["descripción"].insert(0, values[2])
            self.entries["precio"].delete(0, tk.END)
            self.entries["precio"].insert(0, values[3])
            self.entries["stock"].delete(0, tk.END)
            self.entries["stock"].insert(0, values[4])

    def _clear_fields(self):
        for entry in self.entries.values():
            entry.delete(0, tk.END)
        self.tree.selection_remove(self.tree.focus())

class OrderView:
    def __init__(self, parent_frame, db_manager):
        self.parent_frame = parent_frame
        self.db_manager = db_manager
        self.clients_data = {}
        self.products_data = {}
        self.current_order_items = []

        self._create_widgets()
        self._load_combobox_data()
        self.load_orders()

    def _create_widgets(self):
        # Frame for order creation
        create_order_frame = ttk.LabelFrame(self.parent_frame, text="Create New Order", padding=(10, 10, 10, 10))
        create_order_frame.pack(padx=15, pady=15, fill="x", expand=False)
        create_order_frame.grid_columnconfigure(1, weight=1)

        ttk.Label(create_order_frame, text="Client:").grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.client_combobox = ttk.Combobox(create_order_frame, state="readonly")
        self.client_combobox.grid(row=0, column=1, padx=5, pady=5, sticky="ew")

        ttk.Label(create_order_frame, text="Product:").grid(row=1, column=0, padx=5, pady=5, sticky="w")
        self.product_combobox = ttk.Combobox(create_order_frame, state="readonly")
        self.product_combobox.grid(row=1, column=1, padx=5, pady=5, sticky="ew")

        ttk.Label(create_order_frame, text="Quantity:").grid(row=2, column=0, padx=5, pady=5, sticky="w")
        self.quantity_entry = ttk.Entry(create_order_frame)
        self.quantity_entry.grid(row=2, column=1, padx=5, pady=5, sticky="ew")

        add_product_btn = ttk.Button(create_order_frame, text="Add Product to Order", command=self._add_item_to_current_order, style="Accent.TButton")
        add_product_btn.grid(row=3, column=0, columnspan=2, pady=10)

        items_frame = ttk.LabelFrame(create_order_frame, text="Current Order Items", padding=(10, 10, 10, 10))
        items_frame.grid(row=4, column=0, columnspan=2, padx=5, pady=5, sticky="ew")

        self.current_order_tree = ttk.Treeview(items_frame, columns=("Product", "Quantity", "Unit Price", "Subtotal"), show="headings", height=5)
        self.current_order_tree.pack(side="left", fill="both", expand=True)

        for col in self.current_order_tree["columns"]:
            self.current_order_tree.heading(col, text=col)
            self.current_order_tree.column(col, width=100)

        self.current_order_tree.column("Quantity", width=70, anchor=tk.E)
        self.current_order_tree.column("Unit Price", width=90, anchor=tk.E)
        self.current_order_tree.column("Subtotal", width=90, anchor=tk.E)

        item_scrollbar = ttk.Scrollbar(items_frame, orient="vertical", command=self.current_order_tree.yview)
        item_scrollbar.pack(side="right", fill="y")
        self.current_order_tree.configure(yscrollcommand=item_scrollbar.set)

        self.total_label = ttk.Label(create_order_frame, text="Order Total: S/ 0.00", font=("Arial", 12, "bold"))
        self.total_label.grid(row=5, column=0, columnspan=2, pady=10, sticky="e")

        save_order_btn = ttk.Button(create_order_frame, text="Save Order", command=self._save_order, style="Success.TButton")
        save_order_btn.grid(row=6, column=0, columnspan=2, pady=10)

        # Frame for existing order list
        list_orders_frame = ttk.LabelFrame(self.parent_frame, text="Order List", padding=(10, 10, 10, 10))
        list_orders_frame.pack(padx=15, pady=15, fill="both", expand=True)

        self.orders_tree = ttk.Treeview(list_orders_frame, columns=("ID", "Client", "Date", "Total"), show="headings", selectmode="browse")
        self.orders_tree.pack(side="left", fill="both", expand=True)

        for col in self.orders_tree["columns"]:
            self.orders_tree.heading(col, text=col, anchor=tk.W)
            self.orders_tree.column(col, width=120)

        self.orders_tree.column("ID", width=60, stretch=tk.NO)
        self.orders_tree.column("Client", width=180)
        self.orders_tree.column("Date", width=120)
        self.orders_tree.column("Total", width=100, anchor=tk.E)

        orders_scrollbar = ttk.Scrollbar(list_orders_frame, orient="vertical", command=self.orders_tree.yview)
        orders_scrollbar.pack(side="right", fill="y")
        self.orders_tree.configure(yscrollcommand=orders_scrollbar.set)

        self.orders_tree.bind("<<TreeviewSelect>>", self._on_order_select)

        delete_order_btn = ttk.Button(self.parent_frame, text="Delete Selected Order", command=self._delete_order, style="Danger.TButton")
        delete_order_btn.pack(pady=10)

    def _load_combobox_data(self):
        # Load clients
        clients = self.db_manager.fetch_all("clients")
        client_names = []
        self.clients_data = {}
        for client in clients:
            self.clients_data[client["name"]] = client["id"]
            client_names.append(client["name"])
        self.client_combobox["values"] = client_names
        if client_names:
            self.client_combobox.set(client_names[0])
        else:
            self.client_combobox.set("")

        # Load products
        products = self.db_manager.fetch_all("products")
        product_names = []
        self.products_data = {}
        for product in products:
            self.products_data[product["name"]] = {"id": product["id"], "price": product["price"], "stock": product["stock"]}
            product_names.append(product["name"])
        self.product_combobox["values"] = product_names
        if product_names:
            self.product_combobox.set(product_names[0])
        else:
            self.product_combobox.set("")

    def _add_item_to_current_order(self):
        selected_product_name = self.product_combobox.get()
        quantity_str = self.quantity_entry.get().strip()

        if not selected_product_name:
            messagebox.showwarning("Warning", "Please select a product.")
            return
        if not quantity_str:
            messagebox.showwarning("Warning", "Please enter a quantity.")
            return

        if not validate_positive_number(quantity_str, int):
            messagebox.showerror("Validation Error", "Quantity must be a positive integer.")
            return

        try:
            quantity = int(quantity_str)
        except ValueError:
            messagebox.showerror("Validation Error", "Quantity in incorrect format.")
            return

        product_info = self.products_data.get(selected_product_name)
        if not product_info:
            messagebox.showerror("Error", "Product not found or unavailable.")
            return

        product_id = product_info["id"]
        product_price = product_info["price"]
        product_stock = product_info["stock"]

        # Check available stock including what's already added to the current order
        current_added_quantity = sum(item["quantity"] for item in self.current_order_items if item["product_id"] == product_id)
        if quantity + current_added_quantity > product_stock:
            messagebox.showwarning("Insufficient Stock",
                                   f"Only {product_stock} units of '{selected_product_name}' are available. "
                                   f"{current_added_quantity} have already been added to this order. "
                                   f"Cannot add {quantity} more.")
            return

        subtotal = quantity * product_price

        item_found = False
        for item in self.current_order_items:
            if item["product_id"] == product_id:
                item["quantity"] += quantity
                item["subtotal"] += subtotal
                item_found = True
                break
        if not item_found:
            self.current_order_items.append({
                "product_id": product_id,
                "product_name": selected_product_name,
                "quantity": quantity,
                "price_at_order": product_price,
                "subtotal": subtotal
            })
        self._update_current_order_tree()
        self._update_order_total()
        self.quantity_entry.delete(0, tk.END)

    def _update_current_order_tree(self):
        for item in self.current_order_tree.get_children():
            self.current_order_tree.delete(item)
        for item in self.current_order_items:
            self.current_order_tree.insert("", "end", values=(
                item["product_name"],
                item["quantity"],
                f"{item['price_at_order']:.2f}",
                f"{item['subtotal']:.2f}"
            ))

    def _update_order_total(self):
        total_amount = sum(item["subtotal"] for item in self.current_order_items)
        self.total_label.config(text=f"Order Total: S/ {total_amount:.2f}")

    def _save_order(self):
        selected_client_name = self.client_combobox.get()
        if not selected_client_name:
            messagebox.showerror("Error", "You must select a client for the order.")
            return
        if not self.current_order_items:
            messagebox.showerror("Error", "You must add products to the order.")
            return

        client_id = self.clients_data.get(selected_client_name)
        if not client_id:
            messagebox.showerror("Error", "Invalid client. Please select one from the list.")
            return

        total_amount = sum(item["subtotal"] for item in self.current_order_items)
        order_date = datetime.date.today().isoformat()

        # Insert the main order
        order_id = self.db_manager.insert_data("orders", {
            "client_id": client_id,
            "order_date": order_date,
            "total_amount": total_amount
        })

        if order_id:
            success = True
            for item in self.current_order_items:
                detail_data = {
                    "order_id": order_id,
                    "product_id": item["product_id"],
                    "quantity": item["quantity"],
                    "price_at_order": item["price_at_order"]
                }
                if not self.db_manager.insert_data("order_details", detail_data):
                    success = False
                    break

                # Update product stock
                product_info = self.db_manager.fetch_one("products", item["product_id"])
                if product_info:
                    new_stock = product_info["stock"] - item["quantity"]
                    self.db_manager.update_data("products", item["product_id"], {"stock": new_stock})
                    self._load_combobox_data() # Reload product data (stock) for the combobox

            if success:
                messagebox.showinfo("Success", f"Order {order_id} saved successfully.")
                self.load_orders()
                self._clear_current_order()
            else:
                messagebox.showerror("Error", "Not all order details could be saved.")
        else:
            messagebox.showerror("Error", "Could not create the main order.")

    def _clear_current_order(self):
        self.current_order_items = []
        self._update_current_order_tree()
        self._update_order_total()
        self.quantity_entry.delete(0, tk.END)
        # Reset comboboxes if values are available
        if self.client_combobox["values"]:
            self.client_combobox.set(self.client_combobox["values"][0])
        else:
             self.client_combobox.set("")
        if self.product_combobox["values"]:
            self.product_combobox.set(self.product_combobox["values"][0])
        else:
            self.product_combobox.set("")

    def load_orders(self):
        for item in self.orders_tree.get_children():
            self.orders_tree.delete(item)

        conn = self.db_manager._get_connection()
        cursor = conn.cursor()
        try:
            cursor.execute('''
                SELECT o.id, c.name AS client_name, o.order_date, o.total_amount
                FROM orders o
                JOIN clients c ON o.client_id = c.id
                ORDER BY o.id DESC
            ''')
            orders = cursor.fetchall()
            for order in orders:
                self.orders_tree.insert("", "end", values=(
                    order["id"],
                    order["client_name"],
                    order["order_date"],
                    f"{order['total_amount']:.2f}"
                ))
        except Exception as e:
            messagebox.showerror("Database Error", f"Error loading orders: {e}")
        finally:
            self.db_manager._close_connection()

    def _on_order_select(self, event):
        selected_item = self.orders_tree.focus()
        if selected_item:
            order_id = self.orders_tree.item(selected_item, "values")[0]
            # Here you could open a new window or dialog to show order details
            # For example: self._show_order_details_dialog(order_id)
            print(f"Selected order: {order_id}")

    def _delete_order(self):
        selected_item = self.orders_tree.focus()
        if not selected_item:
            messagebox.showwarning("Warning", "Please select an order to delete.")
            return

        order_id = self.orders_tree.item(selected_item, "values")[0]
        if messagebox.askyesno("Confirm Deletion", f"Are you sure you want to delete order with ID {order_id} and all its details?"):
            conn = self.db_manager._get_connection()
            cursor = conn.cursor()
            try:
                # Retrieve products and quantities to revert stock
                cursor.execute("SELECT product_id, quantity FROM order_details WHERE order_id = ?", (order_id,))
                details_to_revert = cursor.fetchall()

                # First delete order details (due to foreign key constraint)
                cursor.execute("DELETE FROM order_details WHERE order_id = ?", (order_id,))
                # Then delete the main order
                cursor.execute("DELETE FROM orders WHERE id = ?", (order_id,))
                conn.commit()

                # Revert product stock
                for item in details_to_revert:
                    product_id = item["product_id"]
                    quantity = item["quantity"]
                    product_info = self.db_manager.fetch_one("products", product_id)
                    if product_info:
                        new_stock = product_info["stock"] + quantity
                        # It's important to use the direct connection here or reopen it for each update
                        self.db_manager.update_data("products", product_id, {"stock": new_stock})
                self._load_combobox_data() # Reload comboboxes to show updated stock

                messagebox.showinfo("Success", "Order deleted successfully and stock reverted.")
                self.load_orders()
            except Exception as e:
                messagebox.showerror("Error", f"Could not delete order: {e}")
                conn.rollback()
            finally:
                self.db_manager._close_connection()

# --- Main Application Class ---
class ASLEApp:
    def __init__(self, master):
        self.master = master
        master.title("ASLE Management System")
        master.geometry("1200x800")
        master.minsize(1000, 700) # Set a minimum size

        # --- Professional Style Configuration ---
        self.style = ttk.Style()
        self.setup_styles()

        self.db_manager = DatabaseManager(database_name="asle.db")
        self.db_manager.create_tables()

        self._create_menu_bar()
        self._create_notebook()
        self._create_status_bar()

        # Center the window at startup
        master.update_idletasks()
        x = (master.winfo_screenwidth() // 2) - (master.winfo_width() // 2)
        y = (master.winfo_screenheight() // 2) - (master.winfo_height() // 2)
        master.geometry(f"+{x}+{y}")
        master.bind("<Configure>", self._on_resize) # Event to handle resizing

    def setup_styles(self):
        # Colors
        PRIMARY_COLOR = "#0078D4"  # Vibrant blue
        SECONDARY_COLOR = "#2D3E50" # Dark blue/Charcoal gray
        ACCENT_COLOR = "#00BFFF"   # Light blue for accents
        TEXT_COLOR = "#333333"     # Dark gray for general text
        LIGHT_TEXT_COLOR = "#F0F0F0" # Light text for dark backgrounds
        BG_LIGHT = "#E8EEF4"       # Main light background
        BG_DARK = "#FFFFFF"        # Background for individual frames/widgets
        SUCCESS_COLOR = "#28A745"  # Green for success
        DANGER_COLOR = "#DC3545"   # Red for danger

        # Set the base theme ('clam' is a good starting point for customization)
        self.style.theme_use('clam')

        # Main window style
        self.master.configure(bg=BG_LIGHT)

        # Style for Frames and LabelFrames
        self.style.configure("TFrame", background=BG_LIGHT)
        self.style.configure("TLabelframe", background=BG_DARK, bordercolor=PRIMARY_COLOR, foreground=PRIMARY_COLOR, relief="flat")
        self.style.configure("TLabelframe.Label", background=BG_DARK, foreground=PRIMARY_COLOR, font=("Arial", 12, "bold"))

        # Style for Labels
        self.style.configure("TLabel", background=BG_DARK, foreground=TEXT_COLOR, font=("Arial", 10))
        self.style.configure("Dashboard.TLabel", background=BG_LIGHT, foreground=SECONDARY_COLOR)
        self.style.configure("DashboardTitle.TLabel", font=("Arial", 28, "bold"), foreground=PRIMARY_COLOR)

        # Style for Entries (input fields)
        self.style.configure("TEntry", fieldbackground=BG_DARK, foreground=TEXT_COLOR, bordercolor=PRIMARY_COLOR, borderwidth=1, relief="flat")
        self.style.map("TEntry",
            fieldbackground=[('focus', '#E0F2FF')] # Slightly lighter on focus
        )

        # Style for Buttons
        self.style.configure("TButton",
            background=SECONDARY_COLOR,
            foreground=LIGHT_TEXT_COLOR,
            font=("Arial", 10, "bold"),
            borderwidth=0,
            relief="flat",
            padding=(10, 5)
        )
        self.style.map("TButton",
            background=[('active', PRIMARY_COLOR)], # Color change on hover
            foreground=[('active', LIGHT_TEXT_COLOR)]
        )

        # Accent button style
        self.style.configure("Accent.TButton", background=PRIMARY_COLOR, foreground=LIGHT_TEXT_COLOR)
        self.style.map("Accent.TButton",
            background=[('active', ACCENT_COLOR)],
            foreground=[('active', LIGHT_TEXT_COLOR)]
        )

        # Success button style
        self.style.configure("Success.TButton", background=SUCCESS_COLOR, foreground=LIGHT_TEXT_COLOR)
        self.style.map("Success.TButton",
            background=[('active', '#218838')]
        )

        # Danger button style
        self.style.configure("Danger.TButton", background=DANGER_COLOR, foreground=LIGHT_TEXT_COLOR)
        self.style.map("Danger.TButton",
            background=[('active', '#C82333')]
        )

        # Style for Notebook (tabs)
        self.style.configure("TNotebook", background=BG_LIGHT, borderwidth=0)
        self.style.configure("TNotebook.Tab",
            background=SECONDARY_COLOR,
            foreground=LIGHT_TEXT_COLOR,
            padding=[10, 5],
            font=("Arial", 10, "bold")
        )
        self.style.map("TNotebook.Tab",
            background=[('selected', PRIMARY_COLOR)],
            foreground=[('selected', LIGHT_TEXT_COLOR)],
            expand=[('selected', [1, 1, 1, 0])] # Visual expansion on selection
        )
        self.style.configure("TNotebook.Client", background=BG_LIGHT) # Background of the tab content area

        # Style for Treeview (table)
        self.style.configure("Treeview",
            background=BG_DARK,
            foreground=TEXT_COLOR,
            rowheight=25,
            fieldbackground=BG_DARK,
            bordercolor=PRIMARY_COLOR,
            relief="flat"
        )
        self.style.configure("Treeview.Heading",
            font=("Arial", 10, "bold"),
            background=PRIMARY_COLOR,
            foreground=LIGHT_TEXT_COLOR,
            relief="flat"
        )
        self.style.map("Treeview",
            background=[('selected', PRIMARY_COLOR)],
            foreground=[('selected', LIGHT_TEXT_COLOR)]
        )
        self.style.map("Treeview.Heading",
             background=[('active', ACCENT_COLOR)]
        )

        # Style for Scrollbars
        self.style.configure("Vertical.TScrollbar", troughcolor=BG_LIGHT, background=PRIMARY_COLOR, borderwidth=0, arrowcolor=LIGHT_TEXT_COLOR)
        self.style.map("Vertical.TScrollbar",
            background=[('active', ACCENT_COLOR)],
            arrowcolor=[('active', LIGHT_TEXT_COLOR)]
        )

        # Style for Combobox
        self.style.configure("TCombobox",
            fieldbackground=BG_DARK,
            background=BG_DARK,
            foreground=TEXT_COLOR,
            selectbackground=PRIMARY_COLOR,
            selectforeground=LIGHT_TEXT_COLOR,
            bordercolor=PRIMARY_COLOR,
            borderwidth=1,
            relief="flat"
        )
        self.style.map("TCombobox",
            fieldbackground=[('readonly', BG_DARK)],
            background=[('readonly', BG_DARK)],
            selectbackground=[('readonly', PRIMARY_COLOR)],
            selectforeground=[('readonly', LIGHT_TEXT_COLOR)]
        )
        # Dropdown button
        self.style.configure("TCombobox.Border", background=PRIMARY_COLOR, bordercolor=PRIMARY_COLOR)
        self.style.configure("TCombobox.downarrow", background=PRIMARY_COLOR, foreground=LIGHT_TEXT_COLOR)


        # Style for StatusBar
        self.style.configure("TStatus.Label",
            background=SECONDARY_COLOR,
            foreground=LIGHT_TEXT_COLOR,
            font=("Arial", 9),
            padding=(5, 2)
        )


    def _create_menu_bar(self):
        menubar = tk.Menu(self.master, bg=SECONDARY_COLOR, fg=LIGHT_TEXT_COLOR) # Colors for the main menu
        self.master.config(menu=menubar)

        file_menu = tk.Menu(menubar, tearoff=0, bg=SECONDARY_COLOR, fg=LIGHT_TEXT_COLOR, activebackground=PRIMARY_COLOR, activeforeground=LIGHT_TEXT_COLOR)
        file_menu.add_command(label="Exit", command=self.master.quit)
        menubar.add_cascade(label="File", menu=file_menu)

        help_menu = tk.Menu(menubar, tearoff=0, bg=SECONDARY_COLOR, fg=LIGHT_TEXT_COLOR, activebackground=PRIMARY_COLOR, activeforeground=LIGHT_TEXT_COLOR)
        help_menu.add_command(label="About", command=self._show_about_dialog)
        menubar.add_cascade(label="Help", menu=help_menu)

    def _create_notebook(self):
        self.notebook = ttk.Notebook(self.master, style="TNotebook")
        self.notebook.pack(expand=True, fill="both", padx=10, pady=10)

        # Dashboard Tab
        self.dashboard_frame = ttk.Frame(self.notebook, style="TFrame")
        self.notebook.add(self.dashboard_frame, text="Dashboard")
        ttk.Label(self.dashboard_frame, text="Welcome to ASLE System", font=("Arial", 28, "bold"), style="DashboardTitle.TLabel").pack(pady=50)
        ttk.Label(self.dashboard_frame, text="Navigate between tabs to manage clients, products, and orders.", font=("Arial", 12), style="Dashboard.TLabel").pack(pady=10)
        ttk.Label(self.dashboard_frame, text="Developed with Python and Tkinter for efficient management.", font=("Arial", 10, "italic"), style="Dashboard.TLabel").pack(pady=5)

        # Clients Tab
        self.client_frame = ttk.Frame(self.notebook, style="TFrame")
        self.notebook.add(self.client_frame, text="Clients")
        self.client_view = ClientView(self.client_frame, self.db_manager)

        # Products Tab
        self.product_frame = ttk.Frame(self.notebook, style="TFrame")
        self.notebook.add(self.product_frame, text="Products")
        self.product_view = ProductView(self.product_frame, self.db_manager)

        # Orders Tab
        self.order_frame = ttk.Frame(self.notebook, style="TFrame")
        self.notebook.add(self.order_frame, text="Orders")
        self.order_view = OrderView(self.order_frame, self.db_manager)

        self.notebook.bind("<<NotebookTabChanged>>", self._on_tab_changed)

    def _create_status_bar(self):
        self.status_bar = ttk.Label(self.master, text="Ready", style="TStatus.Label")
        self.status_bar.pack(side=tk.BOTTOM, fill=tk.X)

    def _show_about_dialog(self):
        messagebox.showinfo("About ASLE", "ASLE Management System\nVersion 1.0\nDeveloped with Tkinter and Python.\n\n© 2025 Your Company/Name")

    def _on_tab_changed(self, event):
        selected_tab = self.notebook.tab(self.notebook.select(), "text")
        self.status_bar.config(text=f"Loading {selected_tab} view...")

        # Update view data when changing tabs
        if selected_tab == "Clients":
            self.client_view.load_clients()
        elif selected_tab == "Products":
            self.product_view.load_products()
        elif selected_tab == "Orders":
            self.order_view._load_combobox_data()
            self.order_view.load_orders()

        self.master.after(500, lambda: self.status_bar.config(text="Ready"))

    def _on_resize(self, event):
        # Adjust column width in Treeviews when resizing the window
        # This is an example, it can be made more sophisticated
        if event.widget == self.master:
            current_width = self.master.winfo_width()
            # Adjust this according to your window size and desired proportion
            client_col_width = max(100, (current_width - 300) // 4) # Example
            product_col_width = max(100, (current_width - 300) // 4)
            order_col_width = max(100, (current_width - 300) // 3)

            # Clients
            self.client_view.tree.column("Name", width=client_col_width)
            self.client_view.tree.column("Address", width=client_col_width * 1.5)
            self.client_view.tree.column("Email", width=client_col_width * 1.2)

            # Products
            self.product_view.tree.column("Name", width=product_col_width)
            self.product_view.tree.column("Description", width=product_col_width * 1.5)
            self.product_view.tree.column("Price", width=product_col_width * 0.5)

            # Orders
            self.order_view.orders_tree.column("Client", width=order_col_width)
            self.order_view.orders_tree.column("Date", width=order_col_width * 0.8)
            self.order_view.orders_tree.column("Total", width=order_col_width * 0.7)


# --- Application Entry Point ---
if __name__ == "__main__":
    root = tk.Tk()
    app = ASLEApp(root)
    root.mainloop()
