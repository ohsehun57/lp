import tkinter as tk
from tkinter import ttk, scrolledtext
import re
import datetime
import time # Used to simulate a processing delay
import uuid # For generating unique transaction IDs
import random # For generating random data for stress test

# === POLIMORPHIC CLASSES ===
class Pago:
    """
    Base class for different payment methods.
    Demonstrates polymorphism by providing common interfaces for processing
    and displaying payment information.
    """
    def __init__(self, monto: float, destino: str, user_id: str, transaction_id: str):
        """
        Initializes a generic payment object.

        Args:
            monto (float): The amount of the payment.
            destino (str): The destination or reference for the payment.
            user_id (str): The ID of the user initiating the payment.
            transaction_id (str): A unique identifier for the transaction.
        """
        self.monto = monto
        self.destino = destino
        self.user_id = user_id
        self.transaction_id = transaction_id
        # Record the exact date and time of payment creation
        self.fecha_pago = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.estado = "Pendiente" # Initial state of the payment

    def procesar_pago(self) -> str:
        """
        Abstract method to process the payment.
        This method should be overridden by concrete payment classes.

        Returns:
            str: A message indicating the result of the payment processing.
        """
        self.estado = "Fallido"
        return "No se puede procesar un pago genérico."

    def mostrar_metodo(self) -> str:
        """
        Returns a human-readable name for the payment method.

        Returns:
            str: The name of the generic payment method.
        """
        return "Método de pago genérico."

    def get_summary(self) -> str:
        """
        Generates a summary string of the payment details.

        Returns:
            str: A formatted string containing key payment information.
        """
        return (f"ID Transacción: {self.transaction_id}\n"
                f"ID Usuario: {self.user_id}\n"
                f"Método: {self.mostrar_metodo()}\n"
                f"Monto: S/{self.monto:.2f}\n"
                f"Destino: {self.destino}\n"
                f"Fecha: {self.fecha_pago}\n"
                f"Estado: {self.estado}")

class PagoTarjetaCredito(Pago):
    """
    Concrete class for Credit Card payments.
    Extends the base Pago class with credit card specific attributes.
    """
    def __init__(self, monto: float, numero_tarjeta: str, nombre_titular: str,
                 mes_exp: str, anio_exp: str, cvv: str, billing_address: str,
                 destino: str, user_id: str, transaction_id: str):
        """
        Initializes a credit card payment.

        Args:
            monto (float): The amount of the payment.
            numero_tarjeta (str): The credit card number.
            nombre_titular (str): The name of the cardholder.
            mes_exp (str): Expiry month (MM).
            anio_exp (str): Expiry year (YYYY).
            cvv (str): Card Verification Value.
            billing_address (str): The billing address for the card.
            destino (str): The destination or reference for the payment.
            user_id (str): The ID of the user.
            transaction_id (str): Unique transaction ID.
        """
        super().__init__(monto, destino, user_id, transaction_id)
        self.numero_tarjeta = numero_tarjeta
        self.nombre_titular = nombre_titular
        self.mes_exp = mes_exp
        self.anio_exp = anio_exp
        self.cvv = cvv
        self.billing_address = billing_address

    def mostrar_metodo(self) -> str:
        """Returns the specific payment method name."""
        return "💳 Tarjeta de Crédito"

    def procesar_pago(self) -> str:
        """
        Simulates credit card payment processing.
        In a real system, this would involve API calls to a payment gateway.

        Returns:
            str: A message detailing the simulated payment processing.
        """
        # Simulate successful processing
        self.estado = "Completado"
        return (f"Procesando pago de S/{self.monto:.2f} con tarjeta ****{self.numero_tarjeta[-4:]}\n"
                f"Titular: {self.nombre_titular}\n"
                f"Vencimiento: {self.mes_exp}/{self.anio_exp}\n"
                f"Dirección de Facturación: {self.billing_address}\n"
                f"Destino/Referencia: {self.destino}\n"
                f"Pago con tarjeta procesado exitosamente.")

class PagoPayPal(Pago):
    """
    Concrete class for PayPal payments.
    Extends the base Pago class with PayPal specific attributes.
    """
    def __init__(self, monto: float, correo: str, password_sim: str,
                 destino: str, user_id: str, transaction_id: str):
        """
        Initializes a PayPal payment.

        Args:
            monto (float): The amount of the payment.
            correo (str): The PayPal account email.
            password_sim (str): A simulated password (for UI purposes only).
            destino (str): The destination or reference for the payment.
            user_id (str): The ID of the user.
            transaction_id (str): Unique transaction ID.
        """
        super().__init__(monto, destino, user_id, transaction_id)
        self.correo = correo
        self.password_sim = password_sim # Simulated password for UI, not for actual use
        
    def mostrar_metodo(self) -> str:
        """Returns the specific payment method name."""
        return "📧 PayPal"

    def procesar_pago(self) -> str:
        """
        Simulates PayPal payment processing.
        In a real system, this would involve redirection to PayPal's website
        or an API integration.

        Returns:
            str: A message detailing the simulated payment processing.
        """
        # Simulate successful processing
        self.estado = "Completado"
        return (f"Procesando pago de S/{self.monto:.2f} a la cuenta PayPal {self.correo}\n"
                f"Destino/Referencia: {self.destino}\n"
                f"Pago con PayPal procesado exitosamente.")

class PagoCriptomoneda(Pago):
    """
    Concrete class for Cryptocurrency payments.
    Extends the base Pago class with cryptocurrency specific attributes.
    """
    def __init__(self, monto: float, wallet: str, red: str,
                 destino: str, user_id: str, transaction_id: str):
        """
        Initializes a cryptocurrency payment.

        Args:
            monto (float): The amount of the payment.
            wallet (str): The cryptocurrency wallet address.
            red (str): The blockchain network (e.g., Bitcoin, Ethereum).
            destino (str): The destination or reference for the payment.
            user_id (str): The ID of the user.
            transaction_id (str): Unique transaction ID.
        """
        super().__init__(monto, destino, user_id, transaction_id)
        self.wallet = wallet
        self.red = red # Blockchain network
        
    def mostrar_metodo(self) -> str:
        """Returns the specific payment method name."""
        return "🪙 Criptomoneda"

    def procesar_pago(self) -> str:
        """
        Simulates cryptocurrency payment processing.
        In a real system, this would involve broadcasting a transaction
        to the specified blockchain network.

        Returns:
            str: A message detailing the simulated payment processing.
        """
        # Simulate successful processing
        self.estado = "Completado"
        return (f"Procesando pago de S/{self.monto:.2f} desde wallet {self.wallet[:10]}... en la red {self.red}\n"
                f"Destino/Referencia: {self.destino}\n"
                f"Pago con criptomoneda procesado exitosamente.")

class PagoTransferenciaBancaria(Pago):
    """
    Concrete class for Bank Transfer payments.
    Extends the base Pago class with bank transfer specific attributes.
    """
    def __init__(self, monto: float, banco: str, numero_cuenta: str, swift_bic: str,
                 destino: str, user_id: str, transaction_id: str):
        """
        Initializes a bank transfer payment.

        Args:
            monto (float): The amount of the payment.
            banco (str): The name of the bank.
            numero_cuenta (str): The bank account number.
            swift_bic (str): The SWIFT/BIC code for international transfers.
            destino (str): The destination or reference for the payment.
            user_id (str): The ID of the user.
            transaction_id (str): Unique transaction ID.
        """
        super().__init__(monto, destino, user_id, transaction_id)
        self.banco = banco
        self.numero_cuenta = numero_cuenta
        self.swift_bic = swift_bic

    def mostrar_metodo(self) -> str:
        """Returns the specific payment method name."""
        return "🏦 Transferencia Bancaria"

    def procesar_pago(self) -> str:
        """
        Simulates bank transfer payment processing.
        In a real system, this would involve providing instructions to the user
        to complete the transfer manually.

        Returns:
            str: A message detailing the simulated payment processing.
        """
        # Simulate successful processing
        self.estado = "Completado"
        return (f"Procesando pago de S/{self.monto:.2f} vía transferencia bancaria\n"
                f"Banco: {self.banco}\n"
                f"Cuenta: {self.numero_cuenta}\n"
                f"SWIFT/BIC: {self.swift_bic}\n"
                f"Destino/Referencia: {self.destino}\n"
                f"Instrucciones de transferencia enviadas.")

class PagoMovil(Pago):
    """
    Concrete class for Mobile Payments (e.g., QR code, app-based payments).
    """
    def __init__(self, monto: float, numero_telefono: str, operador_movil: str,
                 destino: str, user_id: str, transaction_id: str):
        """
        Initializes a mobile payment.

        Args:
            monto (float): The amount of the payment.
            numero_telefono (str): The mobile phone number associated with the payment.
            operador_movil (str): The mobile operator (e.g., Claro, Movistar).
            destino (str): The destination or reference for the payment.
            user_id (str): The ID of the user.
            transaction_id (str): Unique transaction ID.
        """
        super().__init__(monto, destino, user_id, transaction_id)
        self.numero_telefono = numero_telefono
        self.operador_movil = operador_movil

    def mostrar_metodo(self) -> str:
        """Returns the specific payment method name."""
        return "📱 Pago Móvil"

    def procesar_pago(self) -> str:
        """
        Simulates mobile payment processing.
        In a real system, this might involve generating a QR code or
        sending a push notification to the user's mobile app.

        Returns:
            str: A message detailing the simulated payment processing.
        """
        self.estado = "Completado"
        return (f"Procesando pago de S/{self.monto:.2f} vía Pago Móvil\n"
                f"Número de Teléfono: {self.numero_telefono}\n"
                f"Operador: {self.operador_movil}\n"
                f"Destino/Referencia: {self.destino}\n"
                f"Pago móvil procesado exitosamente. Verifique su aplicación.")


# === TKINTER GRAPHICAL INTERFACE ===
class InterfazPagos:
    """
    Class for the graphical interface of the payment system.
    Manages the Tkinter widgets, user input, validation, and display of results.
    """
    def __init__(self, root: tk.Tk, logged_in_user_id: str):
        """
        Initializes the main payment system application window.

        Args:
            root (tk.Tk): The root Tkinter window.
            logged_in_user_id (str): The ID of the user who successfully logged in.
        """
        self.root = root
        self.logged_in_user_id = logged_in_user_id
        self.root.title(f"Sistema de Pagos Empresarial - Usuario: {self.logged_in_user_id}")
        self.root.geometry("1200x950") # Increased size for more features and horizontal layout
        self.root.resizable(False, False) # Prevents window resizing
        self.root.config(bg="#e0f7fa") # Soft light blue background

        # List to store all processed payment objects for history and reports
        self.all_transactions = []

        # --- Style Configuration for Tkinter Widgets ---
        self.style = ttk.Style()
        self.style.theme_use('clam') # A more modern theme for ttk widgets

        # General frame and label styles
        self.style.configure('TFrame', background='#e0f7fa')
        self.style.configure('TLabel', background='#e0f7fa', foreground='#263238', font=("Inter", 11))
        
        # Button styles
        self.style.configure('TButton', font=("Inter", 12, "bold"), background='#00796b', foreground='white',
                             padding=[15, 10], relief="flat", borderwidth=0, focusthickness=0)
        self.style.map('TButton', background=[('active', '#004d40')], foreground=[('active', 'white')])

        # Entry and Combobox styles
        self.style.configure('TEntry', fieldbackground='#ffffff', foreground='#263238', font=("Inter", 11),
                             padding=8, relief="flat", borderwidth=1, bordercolor="#b0bec5")
        self.style.configure('TCombobox', fieldbackground='#ffffff', foreground='#263238', font=("Inter", 11),
                             padding=8, relief="flat", borderwidth=1, bordercolor="#b0bec5")

        # LabelFrame styles (for section headers)
        self.style.configure('TLabelframe', background='#e0f7fa', foreground='#004d40', font=("Inter", 13, "bold"),
                             padding=[10, 5, 10, 10])
        self.style.configure('TLabelframe.Label', background='#e0f7fa', foreground='#004d40')

        # Radiobutton styles
        self.style.configure('TRadiobutton', background='#e0f7fa', foreground='#263238', font=("Inter", 11))

        # Treeview (for transaction history) styles
        self.style.configure('Treeview', background='#fcfcfc', foreground='#333333', fieldbackground='#fcfcfc',
                             font=("Inter", 10), rowheight=25)
        self.style.map('Treeview', background=[('selected', '#b2dfdb')]) # Highlight selected row
        self.style.configure('Treeview.Heading', font=("Inter", 11, "bold"), background='#004d40', foreground='white')
        self.style.layout("Treeview.Heading", [("Treeview.padding", {"sticky": "nswe"}),
                                               ("Treeview.spacing", {"sticky": "nswe"}),
                                               ("Treeview.label", {"sticky": "nswe"})])

        # --- Menu Bar ---
        self.menubar = tk.Menu(root)
        root.config(menu=self.menubar)

        file_menu = tk.Menu(self.menubar, tearoff=0)
        self.menubar.add_cascade(label="Archivo", menu=file_menu)
        file_menu.add_command(label="Cerrar Sesión", command=self.logout)
        file_menu.add_separator()
        file_menu.add_command(label="Salir", command=self.root.quit)

        view_menu = tk.Menu(self.menubar, tearoff=0)
        self.menubar.add_cascade(label="Ver", menu=view_menu)
        view_menu.add_command(label="Reportes y Estadísticas", command=self.show_reports)

        help_menu = tk.Menu(self.menubar, tearoff=0)
        self.menubar.add_cascade(label="Ayuda", menu=help_menu)
        help_menu.add_command(label="Acerca de", command=self.show_about_dialog)


        # --- Application Title ---
        title_frame = ttk.Frame(root, padding="20 20 20 20")
        title_frame.pack(pady=(10, 5))
        titulo = ttk.Label(title_frame, text="SISTEMA DE PAGOS EMPRESARIAL", font=("Inter", 26, "bold"), foreground="#004d40")
        titulo.pack()
        ttk.Label(title_frame, text=f"Usuario Activo: {self.logged_in_user_id}", font=("Inter", 10, "italic"), foreground="#4CAF50").pack()


        # --- Main Content Frame (Horizontal Layout) ---
        self.main_content_frame = ttk.Frame(root, padding="10 10 10 10")
        self.main_content_frame.pack(fill="both", expand=True, padx=20, pady=10)

        # Left Panel (Input and Method Selection)
        self.left_panel_frame = ttk.Frame(self.main_content_frame, padding="10 10 10 10")
        self.left_panel_frame.pack(side="left", fill="both", expand=True, padx=10, pady=10)

        # Right Panel (Result Console and History)
        self.right_panel_frame = ttk.Frame(self.main_content_frame, padding="10 10 10 10")
        self.right_panel_frame.pack(side="right", fill="both", expand=True, padx=10, pady=10)


        # --- Payment Method Selection Frame (moved to left_panel_frame) ---
        method_frame = ttk.LabelFrame(self.left_panel_frame, text="Seleccione Método de Pago", padding="15 20 15 15")
        method_frame.pack(pady=10, padx=10, fill="x")

        self.payment_method_var = tk.StringVar()
        self.payment_method_var.set("Tarjeta de Crédito") # Default selected method

        # Radio buttons for different payment methods
        rb_tarjeta = ttk.Radiobutton(method_frame, text="Tarjeta de Crédito", variable=self.payment_method_var,
                                     value="Tarjeta de Crédito", command=self.update_input_fields)
        rb_tarjeta.grid(row=0, column=0, padx=10, pady=8, sticky="w")

        rb_paypal = ttk.Radiobutton(method_frame, text="PayPal", variable=self.payment_method_var,
                                    value="PayPal", command=self.update_input_fields)
        rb_paypal.grid(row=0, column=1, padx=10, pady=8, sticky="w")

        rb_crypto = ttk.Radiobutton(method_frame, text="Criptomoneda", variable=self.payment_method_var,
                                    value="Criptomoneda", command=self.update_input_fields)
        rb_crypto.grid(row=0, column=2, padx=10, pady=8, sticky="w")

        rb_banco = ttk.Radiobutton(method_frame, text="Transferencia Bancaria", variable=self.payment_method_var,
                                   value="Transferencia Bancaria", command=self.update_input_fields)
        rb_banco.grid(row=0, column=3, padx=10, pady=8, sticky="w")
        
        rb_movil = ttk.Radiobutton(method_frame, text="Pago Móvil", variable=self.payment_method_var,
                                   value="Pago Móvil", command=self.update_input_fields)
        rb_movil.grid(row=0, column=4, padx=10, pady=8, sticky="w")


        # Configure columns to expand equally
        method_frame.columnconfigure(0, weight=1)
        method_frame.columnconfigure(1, weight=1)
        method_frame.columnconfigure(2, weight=1)
        method_frame.columnconfigure(3, weight=1)
        method_frame.columnconfigure(4, weight=1)


        # --- Payment Data Input Frame (moved to left_panel_frame) ---
        self.input_frame = ttk.Frame(self.left_panel_frame, padding="15 20 15 15")
        self.input_frame.pack(pady=10, padx=10, fill="x")

        # Label and input field for amount (common to all methods)
        ttk.Label(self.input_frame, text="Monto (S/):").grid(row=0, column=0, padx=5, pady=8, sticky="w")
        self.monto_entry = ttk.Entry(self.input_frame, width=35)
        self.monto_entry.grid(row=0, column=1, padx=5, pady=8, sticky="ew")
        self.monto_entry.insert(0, "100.00") # Initial value
        self.monto_entry.bind("<KeyRelease>", self.clear_message) # Clear message on key press

        # Dynamic input fields (labels and entries/comboboxes that change based on method)
        # These are placeholders that will be configured by update_input_fields
        self.dynamic_label_1 = ttk.Label(self.input_frame, text="")
        self.dynamic_label_1.grid(row=1, column=0, padx=5, pady=8, sticky="w")
        self.dynamic_entry_1 = ttk.Entry(self.input_frame, width=35)
        self.dynamic_entry_1.grid(row=1, column=1, padx=5, pady=8, sticky="ew")
        self.dynamic_entry_1.bind("<KeyRelease>", self.clear_message)

        self.dynamic_label_2 = ttk.Label(self.input_frame, text="")
        self.dynamic_label_2.grid(row=2, column=0, padx=5, pady=8, sticky="w")
        self.dynamic_entry_2 = ttk.Entry(self.input_frame, width=35)
        self.dynamic_entry_2.grid(row=2, column=1, padx=5, pady=8, sticky="ew")
        self.dynamic_entry_2.bind("<KeyRelease>", self.clear_message)

        self.dynamic_label_3 = ttk.Label(self.input_frame, text="")
        self.dynamic_label_3.grid(row=3, column=0, padx=5, pady=8, sticky="w")
        self.dynamic_entry_3 = ttk.Entry(self.input_frame, width=35)
        self.dynamic_entry_3.grid(row=3, column=1, padx=5, pady=8, sticky="ew")
        self.dynamic_entry_3.bind("<KeyRelease>", self.clear_message)

        self.dynamic_label_4 = ttk.Label(self.input_frame, text="")
        self.dynamic_label_4.grid(row=4, column=0, padx=5, pady=8, sticky="w")
        self.dynamic_entry_4 = ttk.Entry(self.input_frame, width=35)
        self.dynamic_entry_4.grid(row=4, column=1, padx=5, pady=8, sticky="ew")
        self.dynamic_entry_4.bind("<KeyRelease>", self.clear_message)

        # Comboboxes for expiry month/year (credit card) and crypto network / mobile operator
        self.dynamic_combobox_1 = ttk.Combobox(self.input_frame, width=33, state="readonly")
        self.dynamic_combobox_1.bind("<<ComboboxSelected>>", self.clear_message)
        self.dynamic_combobox_2 = ttk.Combobox(self.input_frame, width=33, state="readonly")
        self.dynamic_combobox_2.bind("<<ComboboxSelected>>", self.clear_message)

        # New field for destination/reference (common to all methods)
        ttk.Label(self.input_frame, text="Destino/Referencia:").grid(row=5, column=0, padx=5, pady=8, sticky="w")
        self.destino_entry = ttk.Entry(self.input_frame, width=35)
        self.destino_entry.grid(row=5, column=1, padx=5, pady=8, sticky="ew")
        self.destino_entry.insert(0, "Compra de productos en línea") # Initial value
        self.destino_entry.bind("<KeyRelease>", self.clear_message)

        self.input_frame.columnconfigure(1, weight=1) # Allows the entry fields to expand


        # --- Message Label for Errors/Information ---
        self.message_label = ttk.Label(self.left_panel_frame, text="", font=("Inter", 10, "bold"), foreground="red", background="#e0f7fa")
        self.message_label.pack(pady=(0, 10))

        # --- Action Buttons (moved to left_panel_frame) ---
        button_frame = ttk.Frame(self.left_panel_frame, padding="10 0 10 0")
        button_frame.pack(pady=15)
        btn_procesar = ttk.Button(button_frame, text="Procesar Pago", command=self.procesar_pago_seleccionado)
        btn_procesar.pack(side="left", padx=10)

        btn_limpiar = ttk.Button(button_frame, text="Limpiar Campos", command=self.clear_fields)
        btn_limpiar.pack(side="left", padx=10)

        # Stress Test Button
        btn_stress_test = ttk.Button(button_frame, text="Prueba de Estrés (1700)", command=self._run_stress_test)
        btn_stress_test.pack(side="left", padx=10)

        # Processing indicator label
        self.processing_label = ttk.Label(self.left_panel_frame, text="", font=("Inter", 11, "italic"), foreground="#004d40", background="#e0f7fa")
        self.processing_label.pack(pady=(0, 10))


        # --- Result Area (ScrolledText for console-like output, moved to right_panel_frame) ---
        result_frame = ttk.LabelFrame(self.right_panel_frame, text="Resultado del Pago", padding="15 15 15 15")
        result_frame.pack(pady=10, padx=10, fill="both", expand=True)
        self.resultado_text = scrolledtext.ScrolledText(result_frame, height=12, font=("Inter", 12), wrap=tk.WORD, # Increased height for more rectangular console
                                                        bg="#fcfcfc", fg="#333333", relief="flat", borderwidth=1,
                                                        state="disabled", padx=10, pady=10)
        self.resultado_text.pack(fill="both", expand=True)

        # --- Transaction History (Treeview, moved to right_panel_frame) ---
        history_frame = ttk.LabelFrame(self.right_panel_frame, text="Historial de Transacciones", padding="15 15 15 15")
        history_frame.pack(pady=10, padx=10, fill="both", expand=True)

        self.history_tree = ttk.Treeview(history_frame, columns=("ID", "Método", "Monto", "Destino", "Fecha", "Estado"), show="headings")
        # Define column headings
        self.history_tree.heading("ID", text="ID", anchor=tk.W)
        self.history_tree.heading("Método", text="Método", anchor=tk.W)
        self.history_tree.heading("Monto", text="Monto (S/)", anchor=tk.W)
        self.history_tree.heading("Destino", text="Destino/Ref.", anchor=tk.W)
        self.history_tree.heading("Fecha", text="Fecha", anchor=tk.W)
        self.history_tree.heading("Estado", text="Estado", anchor=tk.W)


        # Define column widths and stretch properties
        self.history_tree.column("ID", width=70, stretch=tk.NO)
        self.history_tree.column("Método", width=120, stretch=tk.NO)
        self.history_tree.column("Monto", width=80, stretch=tk.NO)
        self.history_tree.column("Destino", width=180, stretch=tk.YES)
        self.history_tree.column("Fecha", width=150, stretch=tk.NO)
        self.history_tree.column("Estado", width=90, stretch=tk.NO)

        self.history_tree.pack(side="left", fill="both", expand=True)

        # Add a scrollbar to the Treeview
        history_scrollbar = ttk.Scrollbar(history_frame, orient="vertical", command=self.history_tree.yview)
        history_scrollbar.pack(side="right", fill="y")
        self.history_tree.configure(yscrollcommand=history_scrollbar.set)

        # Bind double-click event to show transaction details
        self.history_tree.bind("<Double-1>", self.show_transaction_details)

        # Initialize input fields based on the default selected method
        self.update_input_fields()

    def _display_message(self, message: str, is_error: bool = True):
        """
        Displays a message (error or success) to the user in the message label.

        Args:
            message (str): The message text to display.
            is_error (bool): True if it's an error message (red text), False for success (green text).
        """
        self.message_label.config(text=message, foreground="red" if is_error else "#00796b")
        self.root.update_idletasks() # Ensures the UI updates immediately

    def clear_message(self, event=None):
        """
        Clears the currently displayed message in the message label.
        Can be triggered by an event (e.g., key press) or directly called.
        """
        self.message_label.config(text="")

    def _hide_all_dynamic_fields(self):
        """
        Hides all dynamic input fields and comboboxes.
        This is called before showing specific fields for the selected payment method.
        """
        # List of all dynamic widgets to hide
        dynamic_widgets = [
            self.dynamic_label_1, self.dynamic_entry_1,
            self.dynamic_label_2, self.dynamic_entry_2,
            self.dynamic_label_3, self.dynamic_entry_3,
            self.dynamic_label_4, self.dynamic_entry_4,
            self.dynamic_combobox_1, self.dynamic_combobox_2
        ]
        for widget in dynamic_widgets:
            widget.grid_forget()
            # Reset specific configurations if needed
            if isinstance(widget, ttk.Entry):
                widget.config(show="") # Reset show config for password/CVV fields
                widget.delete(0, tk.END) # Clear content

    def update_input_fields(self):
        """
        Updates the labels, placeholders, and visibility of dynamic input fields
        and comboboxes based on the currently selected payment method.
        """
        self.clear_message() # Clear any previous messages
        self._hide_all_dynamic_fields() # Hide all dynamic fields first

        selected_method = self.payment_method_var.get()

        # Configure fields specific to Credit Card
        if selected_method == "Tarjeta de Crédito":
            self.dynamic_label_1.config(text="Número de Tarjeta:")
            self.dynamic_entry_1.grid(row=1, column=1, padx=5, pady=8, sticky="ew")
            self.dynamic_entry_1.insert(0, "Ej: 1234567890123456")

            self.dynamic_label_2.config(text="Nombre del Titular:")
            self.dynamic_entry_2.grid(row=2, column=1, padx=5, pady=8, sticky="ew")
            self.dynamic_entry_2.insert(0, "Ej: Juan Pérez")

            self.dynamic_label_3.config(text="Fecha de Vencimiento (MM/AA):")
            self.dynamic_combobox_1.config(values=[f"{i:02d}" for i in range(1, 13)]) # Months 01-12
            self.dynamic_combobox_1.grid(row=3, column=1, padx=(5, 0), pady=8, sticky="ew")
            self.dynamic_combobox_1.set(datetime.datetime.now().strftime("%m")) # Set current month

            current_year = datetime.datetime.now().year
            self.dynamic_combobox_2.config(values=[str(current_year + i) for i in range(10)]) # Next 10 years
            self.dynamic_combobox_2.grid(row=3, column=2, padx=(0, 5), pady=8, sticky="ew")
            self.dynamic_combobox_2.set(str(current_year)) # Set current year

            self.dynamic_label_4.config(text="CVV:")
            self.dynamic_entry_4.grid(row=4, column=1, padx=5, pady=8, sticky="ew")
            self.dynamic_entry_4.insert(0, "Ej: 123")
            self.dynamic_entry_4.config(show="*") # Hide CVV input

            # Adjust grid column configuration for comboboxes
            self.input_frame.grid_columnconfigure(2, weight=1)
            self.input_frame.grid_rowconfigure(1, weight=1)
            self.input_frame.grid_rowconfigure(2, weight=1)
            self.input_frame.grid_rowconfigure(3, weight=1)
            self.input_frame.grid_rowconfigure(4, weight=1)

        # Configure fields specific to PayPal
        elif selected_method == "PayPal":
            self.dynamic_label_1.config(text="Correo PayPal:")
            self.dynamic_entry_1.grid(row=1, column=1, padx=5, pady=8, sticky="ew")
            self.dynamic_entry_1.insert(0, "Ej: tu.correo@example.com")

            self.dynamic_label_2.config(text="Contraseña (simulada):")
            self.dynamic_entry_2.grid(row=2, column=1, padx=5, pady=8, sticky="ew")
            self.dynamic_entry_2.config(show="*") # Hide password input
            self.dynamic_entry_2.insert(0, "password123")

            self.input_frame.grid_rowconfigure(1, weight=1)
            self.input_frame.grid_rowconfigure(2, weight=1)

        # Configure fields specific to Cryptocurrency
        elif selected_method == "Criptomoneda":
            self.dynamic_label_1.config(text="Dirección de Wallet:")
            self.dynamic_entry_1.grid(row=1, column=1, padx=5, pady=8, sticky="ew")
            self.dynamic_entry_1.insert(0, "Ej: bc1q... (Bitcoin) o 0x... (Ethereum)")

            self.dynamic_label_2.config(text="Red/Blockchain:")
            self.dynamic_combobox_1.config(values=["Bitcoin", "Ethereum", "Solana", "Litecoin", "Ripple", "Cardano", "Polkadot"])
            self.dynamic_combobox_1.grid(row=2, column=1, padx=5, pady=8, sticky="ew")
            self.dynamic_combobox_1.set("Bitcoin")

            self.input_frame.grid_rowconfigure(1, weight=1)
            self.input_frame.grid_rowconfigure(2, weight=1)

        # Configure fields specific to Bank Transfer
        elif selected_method == "Transferencia Bancaria":
            self.dynamic_label_1.config(text="Nombre del Banco:")
            self.dynamic_entry_1.grid(row=1, column=1, padx=5, pady=8, sticky="ew")
            self.dynamic_entry_1.insert(0, "Ej: Banco de Crédito del Perú")

            self.dynamic_label_2.config(text="Número de Cuenta/IBAN:")
            self.dynamic_entry_2.grid(row=2, column=1, padx=5, pady=8, sticky="ew")
            self.dynamic_entry_2.insert(0, "Ej: 000-123456789-0-00 o ESxx xxxx xxxx xxxx xxxx xxxx")

            self.dynamic_label_3.config(text="Código SWIFT/BIC:")
            self.dynamic_entry_3.grid(row=3, column=1, padx=5, pady=8, sticky="ew")
            self.dynamic_entry_3.insert(0, "Ej: BCPPLIMA")

            self.input_frame.grid_rowconfigure(1, weight=1)
            self.input_frame.grid_rowconfigure(2, weight=1)
            self.input_frame.grid_rowconfigure(3, weight=1)

        # Configure fields specific to Mobile Payment
        elif selected_method == "Pago Móvil":
            self.dynamic_label_1.config(text="Número de Teléfono:")
            self.dynamic_entry_1.grid(row=1, column=1, padx=5, pady=8, sticky="ew")
            self.dynamic_entry_1.insert(0, "Ej: 987654321")

            self.dynamic_label_2.config(text="Operador Móvil:")
            self.dynamic_combobox_1.config(values=["Claro", "Movistar", "Entel", "Bitel", "Otro"])
            self.dynamic_combobox_1.grid(row=2, column=1, padx=5, pady=8, sticky="ew")
            self.dynamic_combobox_1.set("Claro")

            self.input_frame.grid_rowconfigure(1, weight=1)
            self.input_frame.grid_rowconfigure(2, weight=1)


        # Re-grid the common elements (Monto and Destino) as they might have been affected by grid_forget
        ttk.Label(self.input_frame, text="Monto (S/):").grid(row=0, column=0, padx=5, pady=8, sticky="w")
        self.monto_entry.grid(row=0, column=1, padx=5, pady=8, sticky="ew")
        ttk.Label(self.input_frame, text="Destino/Referencia:").grid(row=5, column=0, padx=5, pady=8, sticky="w")
        self.destino_entry.grid(row=5, column=1, padx=5, pady=8, sticky="ew")


    # --- Validation Helper Functions ---
    def _validate_common_inputs(self) -> tuple[bool, dict | None]:
        """
        Validates common inputs for all payment methods: amount and destination.

        Returns:
            tuple[bool, dict | None]: (True, {'monto': float, 'destino': str}) if valid,
                                      (False, None) otherwise.
        """
        try:
            monto_str = self.monto_entry.get().replace(',', '.') # Allow comma as decimal separator
            monto = float(monto_str)
            if monto <= 0:
                self._display_message("Error: El monto debe ser un número positivo. Por favor, corrija el valor.", is_error=True)
                self.monto_entry.focus_set()
                return False, None
        except ValueError:
            self._display_message("Error: Por favor, ingrese un monto válido (número, Ej: 100.00).", is_error=True)
            self.monto_entry.focus_set()
            return False, None

        destino_input = self.destino_entry.get().strip()
        if not destino_input:
            self._display_message("Error: El campo 'Destino/Referencia' no puede estar vacío.", is_error=True)
            self.destino_entry.focus_set()
            return False, None

        return True, {"monto": monto, "destino": destino_input}

    def _is_valid_luhn(self, card_number: str) -> bool:
        """
        Validates a credit card number using the Luhn algorithm.

        Args:
            card_number (str): The credit card number string.

        Returns:
            bool: True if the card number is valid by Luhn algorithm, False otherwise.
        """
        digits = [int(d) for d in card_number if d.isdigit()]
        if not digits:
            return False

        total = 0
        num_digits = len(digits)
        for i in range(num_digits - 1, -1, -1):
            digit = digits[i]
            if (num_digits - 1 - i) % 2 == 1: # Double every second digit from the right
                digit *= 2
                if digit > 9:
                    digit -= 9 # Sum digits if doubled value is > 9 (e.g., 12 -> 1+2=3)
            total += digit
        return total % 10 == 0

    def _validate_card_number(self, card_number_raw: str) -> tuple[bool, str | None]:
        """Validates the format and Luhn checksum of a credit card number."""
        card_number_clean = re.sub(r'[\s-]', '', card_number_raw.strip()) # Remove spaces and hyphens
        if not (card_number_clean.isdigit() and 13 <= len(card_number_clean) <= 19):
            self._display_message("Error: Número de tarjeta inválido. Debe contener solo dígitos (13-19 caracteres).", is_error=True)
            self.dynamic_entry_1.focus_set()
            return False, None
        if not self._is_valid_luhn(card_number_clean):
            self._display_message("Error: Número de tarjeta inválido (falló la validación de Luhn).", is_error=True)
            self.dynamic_entry_1.focus_set()
            return False, None
        return True, card_number_clean

    def _validate_card_holder_name(self, name: str) -> tuple[bool, str | None]:
        """Validates the cardholder's name."""
        if not name or not re.match(r"^[a-zA-Z\s.'-]+$", name):
            self._display_message("Error: Nombre del titular inválido. Use solo letras, espacios, puntos, guiones y apóstrofes.", is_error=True)
            self.dynamic_entry_2.focus_set()
            return False, None
        return True, name

    def _validate_card_expiry_date(self, mes_exp: str, anio_exp: str) -> bool:
        """Validates the credit card expiry date."""
        if not mes_exp or not anio_exp:
            self._display_message("Error: Seleccione un mes y año de vencimiento válidos.", is_error=True)
            return False
        try:
            current_date = datetime.date.today()
            # Create a date object for the first day of the expiry month
            expiry_date = datetime.date(int(anio_exp), int(mes_exp), 1)
            # Check if the expiry month/year is in the past
            if expiry_date.replace(day=1) < current_date.replace(day=1):
                 self._display_message("Error: La tarjeta ha expirado. Por favor, verifique la fecha de vencimiento.", is_error=True)
                 return False
        except ValueError:
            self._display_message("Error: Fecha de vencimiento inválida.", is_error=True)
            return False
        return True

    def _validate_card_cvv(self, cvv: str) -> tuple[bool, str | None]:
        """Validates the CVV."""
        if not (cvv.isdigit() and 3 <= len(cvv) <= 4):
            self._display_message("Error: CVV inválido. Debe ser 3 o 4 dígitos.", is_error=True)
            self.dynamic_entry_4.focus_set()
            return False, None
        return True, cvv

    def _validate_email_format(self, email: str) -> tuple[bool, str | None]:
        """Validates an email address format."""
        email_regex = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
        if not re.match(email_regex, email):
            self._display_message("Error: Correo electrónico inválido. Verifique el formato.", is_error=True)
            self.dynamic_entry_1.focus_set()
            return False, None
        return True, email

    def _validate_password_sim(self, password: str) -> tuple[bool, str | None]:
        """Validates the simulated password (ensures it's not empty)."""
        if not password:
            self._display_message("Error: La contraseña (simulada) no puede estar vacía.", is_error=True)
            self.dynamic_entry_2.focus_set()
            return False, None
        # In a real system, you'd never handle passwords like this in the UI
        # This is purely for demonstrating a field exists.
        return True, password

    def _validate_wallet_address(self, wallet: str) -> tuple[bool, str | None]:
        """Validates a cryptocurrency wallet address (basic regex for common types)."""
        btc_regex = r"^(bc1|[13])[a-zA-HJ-NP-Z0-9]{25,39}$" # Bitcoin (P2PKH, P2SH, Bech32)
        eth_regex = r"^0x[a-fA-F0-9]{40}$" # Ethereum
        sol_regex = r"^[1-9A-HJ-NP-Za-km-z]{32,44}$" # Solana (base58)
        
        if not (re.match(btc_regex, wallet) or re.match(eth_regex, wallet) or re.match(sol_regex, wallet)):
            self._display_message("Error: Dirección de wallet inválida. Verifique el formato (Ej: Bitcoin: bc1, 1, 3; Ethereum: 0x; Solana: base58).", is_error=True)
            self.dynamic_entry_1.focus_set()
            return False, None
        return True, wallet

    def _validate_crypto_network(self, network: str) -> tuple[bool, str | None]:
        """Validates the selected cryptocurrency network."""
        if not network:
            self._display_message("Error: Seleccione una red/blockchain.", is_error=True)
            return False, None
        return True, network

    def _validate_bank_name(self, bank_name: str) -> tuple[bool, str | None]:
        """Validates the bank name."""
        if not bank_name:
            self._display_message("Error: El nombre del banco no puede estar vacío.", is_error=True)
            self.dynamic_entry_1.focus_set()
            return False, None
        return True, bank_name

    def _validate_account_number(self, account_num: str) -> tuple[bool, str | None]:
        """Validates the bank account number (basic digit check and length)."""
        # Allows digits and spaces/hyphens, then cleans
        account_num_clean = re.sub(r'[\s-]', '', account_num.strip())
        if not (account_num_clean.isdigit() and 8 <= len(account_num_clean) <= 34): # Common range for account numbers/IBANs
            self._display_message("Error: Número de cuenta inválido. Debe contener solo dígitos (8-34 caracteres).", is_error=True)
            self.dynamic_entry_2.focus_set()
            return False, None
        return True, account_num_clean

    def _validate_swift_bic(self, swift_bic: str) -> tuple[bool, str | None]:
        """Validates the SWIFT/BIC code format."""
        if not (re.match(r"^[A-Z]{6}[A-Z0-9]{2}([A-Z0-9]{3})?$", swift_bic.upper())):
            self._display_message("Error: SWIFT/BIC inválido. Formato: 8 o 11 caracteres alfanuméricos (letras mayúsculas y números).", is_error=True)
            self.dynamic_entry_3.focus_set()
            return False, None
        return True, swift_bic.upper() # Return uppercase for consistency

    def _validate_phone_number(self, phone_num: str) -> tuple[bool, str | None]:
        """Validates a Peruvian phone number (9 digits starting with 9)."""
        phone_num_clean = re.sub(r'[\s-]', '', phone_num.strip())
        if not (phone_num_clean.isdigit() and len(phone_num_clean) == 9 and phone_num_clean.startswith('9')):
            self._display_message("Error: Número de teléfono inválido. Debe ser 9 dígitos y empezar con '9'.", is_error=True)
            self.dynamic_entry_1.focus_set()
            return False, None
        return True, phone_num_clean

    def _validate_mobile_operator(self, operator: str) -> tuple[bool, str | None]:
        """Validates the selected mobile operator."""
        if not operator:
            self._display_message("Error: Seleccione un operador móvil.", is_error=True)
            return False, None
        return True, operator


    def procesar_pago_seleccionado(self):
        """
        Processes the payment based on the selected method and entered data.
        Performs validation and then simulates the payment.
        """
        self.clear_message() # Clear any previous messages
        self.processing_label.config(text="Procesando...") # Show processing indicator
        self.root.update_idletasks() # Update UI to show processing message
        time.sleep(0.5) # Simulate processing time (reduced for better responsiveness)

        # Validate common inputs first
        common_valid, common_data = self._validate_common_inputs()
        if not common_valid:
            self.processing_label.config(text="") # Clear processing indicator
            return

        monto = common_data["monto"]
        destino_input = common_data["destino"]
        user_id = self.logged_in_user_id
        transaction_id = str(uuid.uuid4()) # Generate a unique ID for each transaction

        pago = None # Initialize payment object

        selected_method = self.payment_method_var.get()

        # --- Method-specific Validations and Payment Object Creation ---
        if selected_method == "Tarjeta de Crédito":
            valid_card_num, numero_tarjeta = self._validate_card_number(self.dynamic_entry_1.get())
            if not valid_card_num: return self.processing_label.config(text="")

            valid_name, nombre_titular = self._validate_card_holder_name(self.dynamic_entry_2.get())
            if not valid_name: return self.processing_label.config(text="")

            mes_exp = self.dynamic_combobox_1.get()
            anio_exp = self.dynamic_combobox_2.get()
            if not self._validate_card_expiry_date(mes_exp, anio_exp): return self.processing_label.config(text="")

            valid_cvv, cvv = self._validate_card_cvv(self.dynamic_entry_4.get())
            if not valid_cvv: return self.processing_label.config(text="")
            
            # For simplicity, billing address is a fixed string for now or can be added as a separate entry
            billing_address = "Dirección de Facturación Simulada" 

            pago = PagoTarjetaCredito(monto, numero_tarjeta, nombre_titular, mes_exp, anio_exp, cvv, billing_address,
                                      destino_input, user_id, transaction_id)

        elif selected_method == "PayPal":
            valid_email, correo = self._validate_email_format(self.dynamic_entry_1.get())
            if not valid_email: return self.processing_label.config(text="")

            valid_password, password_sim = self._validate_password_sim(self.dynamic_entry_2.get())
            if not valid_password: return self.processing_label.config(text="")

            pago = PagoPayPal(monto, correo, password_sim, destino_input, user_id, transaction_id)

        elif selected_method == "Criptomoneda":
            valid_wallet, wallet = self._validate_wallet_address(self.dynamic_entry_1.get())
            if not valid_wallet: return self.processing_label.config(text="")

            valid_network, red = self._validate_crypto_network(self.dynamic_combobox_1.get())
            if not valid_network: return self.processing_label.config(text="")

            pago = PagoCriptomoneda(monto, wallet, red, destino_input, user_id, transaction_id)

        elif selected_method == "Transferencia Bancaria":
            valid_bank_name, banco = self._validate_bank_name(self.dynamic_entry_1.get())
            if not valid_bank_name: return self.processing_label.config(text="")

            valid_account_num, numero_cuenta = self._validate_account_number(self.dynamic_entry_2.get())
            if not valid_account_num: return self.processing_label.config(text="")

            valid_swift_bic, swift_bic = self._validate_swift_bic(self.dynamic_entry_3.get())
            if not valid_swift_bic: return self.processing_label.config(text="")

            pago = PagoTransferenciaBancaria(monto, banco, numero_cuenta, swift_bic, destino_input, user_id, transaction_id)
        
        elif selected_method == "Pago Móvil":
            valid_phone_num, numero_telefono = self._validate_phone_number(self.dynamic_entry_1.get())
            if not valid_phone_num: return self.processing_label.config(text="")

            valid_operator, operador_movil = self._validate_mobile_operator(self.dynamic_combobox_1.get())
            if not valid_operator: return self.processing_label.config(text="")

            pago = PagoMovil(monto, numero_telefono, operador_movil, destino_input, user_id, transaction_id)

        else:
            self._display_message("Error: Método de pago no seleccionado o no reconocido.", is_error=True)
            self.processing_label.config(text="")
            return

        # If a payment object was successfully created and validated
        if pago:
            pago.procesar_pago() # Process the payment (updates its state)
            self.mostrar_resultado(pago) # Display result in the text area
            self.add_to_history(pago) # Add to transaction history
            self.all_transactions.append(pago) # Store the transaction object
            self._display_message("Pago procesado exitosamente.", is_error=False) # Show success message
            self.processing_label.config(text="") # Clear processing indicator
            # self.clear_fields() # Optionally clear fields after successful payment

    def mostrar_resultado(self, metodo_pago: Pago):
        """
        Displays the payment processing result in the main result text area.

        Args:
            metodo_pago (Pago): The payment object to display details for.
        """
        self.resultado_text.config(state="normal") # Enable text area for writing
        self.resultado_text.delete(1.0, tk.END) # Clear previous content
        self.resultado_text.insert(tk.END, metodo_pago.get_summary() + "\n\n") # Insert summary
        self.resultado_text.insert(tk.END, metodo_pago.procesar_pago()) # Insert processing message
        self.resultado_text.config(state="disabled") # Disable text area for read-only

    def add_to_history(self, pago: Pago):
        """
        Adds a successful payment to the transaction history Treeview.

        Args:
            pago (Pago): The payment object to add to history.
        """
        # Insert payment details as a new row in the Treeview
        # The 'iid' (item identifier) is set to the payment object itself,
        # allowing easy retrieval of all payment data later.
        self.history_tree.insert("", "end", iid=pago, values=(
            pago.transaction_id[:7] + "...", # Display truncated ID in Treeview
            pago.mostrar_metodo(),
            f"S/{pago.monto:.2f}",
            pago.destino,
            pago.fecha_pago,
            pago.estado
        ))
        # Scroll to the last added item to make it visible
        self.history_tree.yview_moveto(1)

    def _run_stress_test(self):
        """
        Simulates a stress test by processing a large number of dummy transactions.
        """
        num_transactions = 1700
        self.processing_label.config(text=f"Iniciando prueba de estrés con {num_transactions} transacciones...")
        self.root.update_idletasks()

        # Disable UI during stress test
        for widget in self.root.winfo_children():
            if isinstance(widget, (ttk.Frame, ttk.LabelFrame)):
                for child_widget in widget.winfo_children():
                    if isinstance(child_widget, (ttk.Entry, ttk.Button, ttk.Radiobutton, ttk.Combobox)):
                        child_widget.config(state="disabled")
        self.menubar.entryconfig("Archivo", state="disabled")
        self.menubar.entryconfig("Ver", state="disabled")
        self.menubar.entryconfig("Ayuda", state="disabled")

        # Clear existing history for a clean test run
        for item in self.history_tree.get_children():
            self.history_tree.delete(item)
        self.all_transactions = [] # Clear stored transactions

        for i in range(1, num_transactions + 1):
            # Generate random data for a dummy credit card payment
            monto = round(random.uniform(1.0, 1000.0), 2)
            destino = f"Compra de prueba {i}"
            user_id = self.logged_in_user_id
            transaction_id = str(uuid.uuid4())

            # Dummy credit card details for the test
            numero_tarjeta = ''.join(random.choices('0123456789', k=16))
            nombre_titular = random.choice(["Juan Pérez", "Maria Garcia", "Carlos Rodriguez", "Ana Lopez"])
            mes_exp = f"{random.randint(1, 12):02d}"
            anio_exp = str(datetime.datetime.now().year + random.randint(1, 5))
            cvv = ''.join(random.choices('0123456789', k=3))
            billing_address = f"Calle Ficticia {random.randint(1, 999)}"

            pago = PagoTarjetaCredito(monto, numero_tarjeta, nombre_titular,
                                      mes_exp, anio_exp, cvv, billing_address,
                                      destino, user_id, transaction_id)
            
            pago.procesar_pago() # Simulate processing
            self.add_to_history(pago)
            self.all_transactions.append(pago)

            # Update progress label
            self.processing_label.config(text=f"Procesando transacción {i} de {num_transactions}...")
            if i % 50 == 0 or i == num_transactions: # Update UI every 50 transactions or at the end
                self.root.update_idletasks()
                # time.sleep(0.001) # Small sleep to allow UI to breathe, adjust as needed

        self.processing_label.config(text=f"Prueba de estrés completada. {num_transactions} transacciones procesadas.")
        self._display_message(f"Prueba de estrés completada. {num_transactions} transacciones procesadas.", is_error=False)

        # Re-enable UI after stress test
        for widget in self.root.winfo_children():
            if isinstance(widget, (ttk.Frame, ttk.LabelFrame)):
                for child_widget in widget.winfo_children():
                    if isinstance(child_widget, (ttk.Entry, ttk.Button, ttk.Radiobutton, ttk.Combobox)):
                        child_widget.config(state="normal")
        self.menubar.entryconfig("Archivo", state="normal")
        self.menubar.entryconfig("Ver", state="normal")
        self.menubar.entryconfig("Ayuda", state="normal")
        self.update_input_fields() # Re-apply correct dynamic field states


    def show_transaction_details(self, event):
        """
        Opens a new Toplevel window to display full details of a selected transaction.
        Triggered by double-clicking a row in the transaction history Treeview.
        """
        selected_item = self.history_tree.selection()
        if not selected_item:
            return # No item selected

        # Retrieve the payment object associated with the selected row
        # The iid was set to the payment object itself when inserted
        pago_obj = self.history_tree.item(selected_item, "iid")

        if isinstance(pago_obj, Pago): # Ensure it's a valid payment object
            TransactionDetailWindow(self.root, pago_obj)

    def clear_fields(self):
        """
        Clears all input fields, the result area, and messages.
        Resets the form to its initial state.
        """
        self.monto_entry.delete(0, tk.END)
        self.monto_entry.insert(0, "100.00")
        self.destino_entry.delete(0, tk.END)
        self.destino_entry.insert(0, "Compra de productos en línea")
        self.payment_method_var.set("Tarjeta de Crédito") # Reset to default method
        self.update_input_fields() # Update dynamic fields based on default
        self.resultado_text.config(state="normal")
        self.resultado_text.delete(1.0, tk.END)
        self.resultado_text.config(state="disabled")
        self.clear_message() # Clear any active message
        self.processing_label.config(text="")

    def logout(self):
        """
        Handles user logout. Destroys the current main window and
        re-opens the login window.
        """
        self.root.destroy()
        # Re-create the login window
        login_root = tk.Tk()
        LoginWindow(login_root)
        login_root.mainloop()

    def show_reports(self):
        """
        Opens a new Toplevel window to display basic transaction reports.
        """
        ReportWindow(self.root, self.all_transactions)

    def show_about_dialog(self):
        """
        Displays an 'About' dialog with application information.
        """
        about_window = tk.Toplevel(self.root)
        about_window.title("Acerca de")
        about_window.geometry("400x250")
        about_window.resizable(False, False)
        about_window.config(bg="#e0f7fa")
        about_window.grab_set()
        about_window.transient(self.root)

        ttk.Label(about_window, text="Sistema de Pagos Empresarial", font=("Inter", 14, "bold"), background="#e0f7fa", foreground="#004d40").pack(pady=15)
        ttk.Label(about_window, text="Versión: 1.0.0", background="#e0f7fa").pack(pady=5)
        ttk.Label(about_window, text="Desarrollado por: Gemini AI", background="#e0f7fa").pack(pady=5)
        ttk.Label(about_window, text="Propósito: Demostración de un sistema de pagos robusto con Tkinter.", background="#e0f7fa", wraplength=350).pack(pady=10)
        ttk.Button(about_window, text="Cerrar", command=about_window.destroy).pack(pady=10)


# === TRANSACTION DETAIL WINDOW CLASS ===
class TransactionDetailWindow(tk.Toplevel):
    """
    A Toplevel window to display detailed information about a single transaction.
    """
    def __init__(self, parent: tk.Tk, pago: Pago):
        """
        Initializes the transaction detail window.

        Args:
            parent (tk.Tk): The parent Tkinter window (main application).
            pago (Pago): The payment object whose details are to be displayed.
        """
        super().__init__(parent)
        self.title(f"Detalles de Transacción - {pago.transaction_id[:7]}...")
        self.geometry("550x500") # Increased size for more details
        self.resizable(False, False)
        self.config(bg="#e0f7fa")
        self.grab_set() # Make this window modal (blocks interaction with parent)
        self.transient(parent) # Set parent window

        # Style configuration (inherits from parent, but can be customized)
        style = ttk.Style()
        style.configure('Detail.TLabel', background='#e0f7fa', foreground='#263238', font=("Inter", 11))
        style.configure('Detail.TFrame', background='#e0f7fa')
        style.configure('DetailTitle.TLabel', background='#e0f7fa', foreground='#004d40', font=("Inter", 16, "bold"))


        # Title
        title_label = ttk.Label(self, text="Detalles Completos de la Transacción", style='DetailTitle.TLabel')
        title_label.pack(pady=15)

        # Frame for details
        details_frame = ttk.Frame(self, padding="15 15 15 15", style='Detail.TFrame')
        details_frame.pack(fill="both", expand=True, padx=20, pady=10)

        # Display all payment details
        # Common details
        ttk.Label(details_frame, text="ID Transacción:", style='Detail.TLabel').grid(row=0, column=0, sticky="w", pady=5, padx=5)
        ttk.Label(details_frame, text=pago.transaction_id, style='Detail.TLabel', font=("Inter", 11, "bold")).grid(row=0, column=1, sticky="w", pady=5, padx=5)

        ttk.Label(details_frame, text="ID Usuario:", style='Detail.TLabel').grid(row=1, column=0, sticky="w", pady=5, padx=5)
        ttk.Label(details_frame, text=pago.user_id, style='Detail.TLabel').grid(row=1, column=1, sticky="w", pady=5, padx=5)

        ttk.Label(details_frame, text="Método de Pago:", style='Detail.TLabel').grid(row=2, column=0, sticky="w", pady=5, padx=5)
        ttk.Label(details_frame, text=pago.mostrar_metodo(), style='Detail.TLabel', font=("Inter", 11, "bold")).grid(row=2, column=1, sticky="w", pady=5, padx=5)

        ttk.Label(details_frame, text="Monto:", style='Detail.TLabel').grid(row=3, column=0, sticky="w", pady=5, padx=5)
        ttk.Label(details_frame, text=f"S/{pago.monto:.2f}", style='Detail.TLabel', font=("Inter", 11, "bold")).grid(row=3, column=1, sticky="w", pady=5, padx=5)

        ttk.Label(details_frame, text="Destino/Referencia:", style='Detail.TLabel').grid(row=4, column=0, sticky="w", pady=5, padx=5)
        ttk.Label(details_frame, text=pago.destino, style='Detail.TLabel', wraplength=250).grid(row=4, column=1, sticky="w", pady=5, padx=5)

        ttk.Label(details_frame, text="Fecha y Hora:", style='Detail.TLabel').grid(row=5, column=0, sticky="w", pady=5, padx=5)
        ttk.Label(details_frame, text=pago.fecha_pago, style='Detail.TLabel').grid(row=5, column=1, sticky="w", pady=5, padx=5)

        ttk.Label(details_frame, text="Estado:", style='Detail.TLabel').grid(row=6, column=0, sticky="w", pady=5, padx=5)
        ttk.Label(details_frame, text=pago.estado, style='Detail.TLabel', font=("Inter", 11, "bold"),
                  foreground="green" if pago.estado == "Completado" else "red").grid(row=6, column=1, sticky="w", pady=5, padx=5)

        # Method-specific details
        current_row = 7
        if isinstance(pago, PagoTarjetaCredito):
            ttk.Label(details_frame, text="Número de Tarjeta:", style='Detail.TLabel').grid(row=current_row, column=0, sticky="w", pady=5, padx=5)
            ttk.Label(details_frame, text=f"****{pago.numero_tarjeta[-4:]}", style='Detail.TLabel').grid(row=current_row, column=1, sticky="w", pady=5, padx=5)
            current_row += 1
            ttk.Label(details_frame, text="Titular:", style='Detail.TLabel').grid(row=current_row, column=0, sticky="w", pady=5, padx=5)
            ttk.Label(details_frame, text=pago.nombre_titular, style='Detail.TLabel').grid(row=current_row, column=1, sticky="w", pady=5, padx=5)
            current_row += 1
            ttk.Label(details_frame, text="Vencimiento:", style='Detail.TLabel').grid(row=current_row, column=0, sticky="w", pady=5, padx=5)
            ttk.Label(details_frame, text=f"{pago.mes_exp}/{pago.anio_exp}", style='Detail.TLabel').grid(row=current_row, column=1, sticky="w", pady=5, padx=5)
            current_row += 1
            ttk.Label(details_frame, text="CVV (oculto):", style='Detail.TLabel').grid(row=current_row, column=0, sticky="w", pady=5, padx=5)
            ttk.Label(details_frame, text="***", style='Detail.TLabel').grid(row=current_row, column=1, sticky="w", pady=5, padx=5)
            current_row += 1
            ttk.Label(details_frame, text="Dirección Facturación:", style='Detail.TLabel').grid(row=current_row, column=0, sticky="w", pady=5, padx=5)
            ttk.Label(details_frame, text=pago.billing_address, style='Detail.TLabel', wraplength=250).grid(row=current_row, column=1, sticky="w", pady=5, padx=5)
            current_row += 1

        elif isinstance(pago, PagoPayPal):
            ttk.Label(details_frame, text="Correo PayPal:", style='Detail.TLabel').grid(row=current_row, column=0, sticky="w", pady=5, padx=5)
            ttk.Label(details_frame, text=pago.correo, style='Detail.TLabel').grid(row=current_row, column=1, sticky="w", pady=5, padx=5)
            current_row += 1
            ttk.Label(details_frame, text="Contraseña (simulada):", style='Detail.TLabel').grid(row=current_row, column=0, sticky="w", pady=5, padx=5)
            ttk.Label(details_frame, text="********", style='Detail.TLabel').grid(row=current_row, column=1, sticky="w", pady=5, padx=5)
            current_row += 1

        elif isinstance(pago, PagoCriptomoneda):
            ttk.Label(details_frame, text="Dirección de Wallet:", style='Detail.TLabel').grid(row=current_row, column=0, sticky="w", pady=5, padx=5)
            ttk.Label(details_frame, text=pago.wallet, style='Detail.TLabel', wraplength=250).grid(row=current_row, column=1, sticky="w", pady=5, padx=5)
            current_row += 1
            ttk.Label(details_frame, text="Red/Blockchain:", style='Detail.TLabel').grid(row=current_row, column=0, sticky="w", pady=5, padx=5)
            ttk.Label(details_frame, text=pago.red, style='Detail.TLabel').grid(row=current_row, column=1, sticky="w", pady=5, padx=5)
            current_row += 1

        elif isinstance(pago, PagoTransferenciaBancaria):
            ttk.Label(details_frame, text="Banco:", style='Detail.TLabel').grid(row=current_row, column=0, sticky="w", pady=5, padx=5)
            ttk.Label(details_frame, text=pago.banco, style='Detail.TLabel').grid(row=current_row, column=1, sticky="w", pady=5, padx=5)
            current_row += 1
            ttk.Label(details_frame, text="Número de Cuenta:", style='Detail.TLabel').grid(row=current_row, column=0, sticky="w", pady=5, padx=5)
            ttk.Label(details_frame, text=pago.numero_cuenta, style='Detail.TLabel').grid(row=current_row, column=1, sticky="w", pady=5, padx=5)
            current_row += 1
            ttk.Label(details_frame, text="SWIFT/BIC:", style='Detail.TLabel').grid(row=current_row, column=0, sticky="w", pady=5, padx=5)
            ttk.Label(details_frame, text=pago.swift_bic, style='Detail.TLabel').grid(row=current_row, column=1, sticky="w", pady=5, padx=5)
            current_row += 1
        
        elif isinstance(pago, PagoMovil):
            ttk.Label(details_frame, text="Número de Teléfono:", style='Detail.TLabel').grid(row=current_row, column=0, sticky="w", pady=5, padx=5)
            ttk.Label(details_frame, text=pago.numero_telefono, style='Detail.TLabel').grid(row=current_row, column=1, sticky="w", pady=5, padx=5)
            current_row += 1
            ttk.Label(details_frame, text="Operador Móvil:", style='Detail.TLabel').grid(row=current_row, column=0, sticky="w", pady=5, padx=5)
            ttk.Label(details_frame, text=pago.operador_movil, style='Detail.TLabel').grid(row=current_row, column=1, sticky="w", pady=5, padx=5)
            current_row += 1


        details_frame.columnconfigure(1, weight=1) # Allow detail values to expand

        # Close button
        close_button = ttk.Button(self, text="Cerrar", command=self.destroy, style='TButton')
        close_button.pack(pady=15)

# === REPORT WINDOW CLASS ===
class ReportWindow(tk.Toplevel):
    """
    A Toplevel window to display various reports and statistics on transactions.
    """
    def __init__(self, parent: tk.Tk, transactions: list):
        """
        Initializes the report window.

        Args:
            parent (tk.Tk): The parent Tkinter window (main application).
            transactions (list): A list of all Pago objects to analyze.
        """
        super().__init__(parent)
        self.title("Reportes y Estadísticas de Pagos")
        self.geometry("700x550")
        self.resizable(False, False)
        self.config(bg="#e0f7fa")
        self.grab_set()
        self.transient(parent)

        style = ttk.Style()
        style.configure('ReportTitle.TLabel', background='#e0f7fa', foreground='#004d40', font=("Inter", 18, "bold"))
        style.configure('ReportHeader.TLabel', background='#e0f7fa', foreground='#263238', font=("Inter", 12, "bold"))
        style.configure('ReportValue.TLabel', background='#e0f7fa', foreground='#004d40', font=("Inter", 14, "bold"))
        style.configure('ReportFrame.TLabelframe', background='#e0f7fa', foreground='#004d40', font=("Inter", 13, "bold"))
        style.configure('ReportFrame.TLabelframe.Label', background='#e0f7fa', foreground='#004d40')

        ttk.Label(self, text="Reportes y Estadísticas", style='ReportTitle.TLabel').pack(pady=15)

        # --- Summary Statistics Frame ---
        summary_frame = ttk.LabelFrame(self, text="Resumen General", style='ReportFrame.TLabelframe', padding="15 15 15 15")
        summary_frame.pack(pady=10, padx=20, fill="x")

        total_payments = sum(p.monto for p in transactions if p.estado == "Completado")
        num_transactions = len(transactions)
        num_completed = sum(1 for p in transactions if p.estado == "Completado")
        num_failed = sum(1 for p in transactions if p.estado == "Fallido")
        num_pending = sum(1 for p in transactions if p.estado == "Pendiente")

        ttk.Label(summary_frame, text="Total de Pagos Completados:", style='ReportHeader.TLabel').grid(row=0, column=0, sticky="w", pady=5, padx=5)
        ttk.Label(summary_frame, text=f"S/{total_payments:.2f}", style='ReportValue.TLabel').grid(row=0, column=1, sticky="w", pady=5, padx=5)

        ttk.Label(summary_frame, text="Número Total de Transacciones:", style='ReportHeader.TLabel').grid(row=1, column=0, sticky="w", pady=5, padx=5)
        ttk.Label(summary_frame, text=f"{num_transactions}", style='ReportValue.TLabel').grid(row=1, column=1, sticky="w", pady=5, padx=5)

        ttk.Label(summary_frame, text="Transacciones Completadas:", style='ReportHeader.TLabel').grid(row=2, column=0, sticky="w", pady=5, padx=5)
        ttk.Label(summary_frame, text=f"{num_completed}", style='ReportValue.TLabel', foreground="green").grid(row=2, column=1, sticky="w", pady=5, padx=5)

        ttk.Label(summary_frame, text="Transacciones Fallidas:", style='ReportHeader.TLabel').grid(row=3, column=0, sticky="w", pady=5, padx=5)
        ttk.Label(summary_frame, text=f"{num_failed}", style='ReportValue.TLabel', foreground="red").grid(row=3, column=1, sticky="w", pady=5, padx=5)
        
        ttk.Label(summary_frame, text="Transacciones Pendientes:", style='ReportHeader.TLabel').grid(row=4, column=0, sticky="w", pady=5, padx=5)
        ttk.Label(summary_frame, text=f"{num_pending}", style='ReportValue.TLabel', foreground="orange").grid(row=4, column=1, sticky="w", pady=5, padx=5)


        summary_frame.columnconfigure(1, weight=1)

        # --- Payments by Method Frame ---
        method_summary_frame = ttk.LabelFrame(self, text="Pagos por Método", style='ReportFrame.TLabelframe', padding="15 15 15 15")
        method_summary_frame.pack(pady=10, padx=20, fill="x")

        method_counts = {}
        method_totals = {}
        for p in transactions:
            method_name = p.mostrar_metodo()
            method_counts[method_name] = method_counts.get(method_name, 0) + 1
            if p.estado == "Completado":
                method_totals[method_name] = method_totals.get(method_name, 0) + p.monto

        row_idx = 0
        for method, count in method_counts.items():
            total_amount = method_totals.get(method, 0)
            ttk.Label(method_summary_frame, text=f"{method}:", style='ReportHeader.TLabel').grid(row=row_idx, column=0, sticky="w", pady=2, padx=5)
            ttk.Label(method_summary_frame, text=f"{count} transacciones (S/{total_amount:.2f})", style='ReportValue.TLabel').grid(row=row_idx, column=1, sticky="w", pady=2, padx=5)
            row_idx += 1
        
        if not method_counts:
            ttk.Label(method_summary_frame, text="No hay transacciones para mostrar.", style='ReportHeader.TLabel').grid(row=0, column=0, columnspan=2, sticky="w", pady=5, padx=5)


        method_summary_frame.columnconfigure(1, weight=1)

        close_button = ttk.Button(self, text="Cerrar", command=self.destroy, style='TButton')
        close_button.pack(pady=20)


# === LOGIN WINDOW CLASS ===
class LoginWindow(tk.Toplevel):
    """
    A Toplevel window for user login.
    Simulates user authentication before accessing the main application.
    """
    def __init__(self, parent_root: tk.Tk):
        """
        Initializes the login window.

        Args:
            parent_root (tk.Tk): The root Tkinter window (will be used for the main app).
        """
        self.parent_root = parent_root
        super().__init__(parent_root)
        self.title("Iniciar Sesión - Sistema de Pagos")
        self.geometry("400x300")
        self.resizable(False, False)
        self.config(bg="#e0f7fa")
        self.grab_set() # Make this window modal
        self.transient(parent_root) # Set parent window

        # Center the login window
        self.update_idletasks()
        x = parent_root.winfo_x() + (parent_root.winfo_width() // 2) - (self.winfo_width() // 2)
        y = parent_root.winfo_y() + (parent_root.winfo_height() // 2) - (self.winfo_height() // 2)
        self.geometry(f"+{x}+{y}")

        # Explicitly bring to front and force focus
        self.lift()
        self.attributes('-topmost', True) # Keep on top initially
        self.after_idle(self.attributes, '-topmost', False) # Remove topmost after a short delay
        self.focus_force() # Force focus

        # Style configuration for login window
        style = ttk.Style()
        style.configure('Login.TFrame', background='#e0f7fa')
        style.configure('Login.TLabel', background='#e0f7fa', foreground='#263238', font=("Inter", 11))
        style.configure('LoginTitle.TLabel', background='#e0f7fa', foreground='#004d40', font=("Inter", 18, "bold"))
        style.configure('Login.TEntry', fieldbackground='#ffffff', foreground='#263238', font=("Inter", 11), padding=8)
        style.configure('Login.TButton', font=("Inter", 12, "bold"), background='#00796b', foreground='white', padding=[10, 5])
        style.map('Login.TButton', background=[('active', '#004d40')])

        ttk.Label(self, text="Iniciar Sesión", style='LoginTitle.TLabel').pack(pady=20)

        login_frame = ttk.Frame(self, padding="20 20 20 20", style='Login.TFrame')
        login_frame.pack(pady=10, padx=20, fill="both", expand=True)

        ttk.Label(login_frame, text="Usuario:", style='Login.TLabel').grid(row=0, column=0, sticky="w", pady=5, padx=5)
        self.username_entry = ttk.Entry(login_frame, width=30, style='Login.TEntry')
        self.username_entry.grid(row=0, column=1, sticky="ew", pady=5, padx=5)
        self.username_entry.insert(0, "admin") # Default for testing

        ttk.Label(login_frame, text="Contraseña:", style='Login.TLabel').grid(row=1, column=0, sticky="w", pady=5, padx=5)
        self.password_entry = ttk.Entry(login_frame, width=30, show="*", style='Login.TEntry')
        self.password_entry.grid(row=1, column=1, sticky="ew", pady=5, padx=5)
        self.password_entry.insert(0, "password") # Default for testing

        self.login_message_label = ttk.Label(login_frame, text="", font=("Inter", 9, "bold"), foreground="red", background="#e0f7fa")
        self.login_message_label.grid(row=2, column=0, columnspan=2, pady=5)

        login_button = ttk.Button(login_frame, text="Entrar", command=self._attempt_login, style='Login.TButton')
        login_button.grid(row=3, column=0, columnspan=2, pady=15)

        login_frame.columnconfigure(1, weight=1) # Allow entry fields to expand

        # Bind Enter key to login attempt
        self.username_entry.bind("<Return>", lambda event: self._attempt_login())
        self.password_entry.bind("<Return>", lambda event: self._attempt_login())
        self.username_entry.focus_set() # Set focus to username field on startup

    def _attempt_login(self):
        """
        Attempts to log in the user with the provided credentials.
        This is a simulated authentication.
        """
        username = self.username_entry.get().strip()
        password = self.password_entry.get().strip()

        # Simulated valid credentials
        valid_username = "admin"
        valid_password = "password"

        if username == valid_username and password == valid_password:
            self.login_message_label.config(text="Inicio de sesión exitoso!", foreground="green")
            self.after(500, self._start_main_app) # Delay to show success message
        else:
            self.login_message_label.config(text="Usuario o contraseña incorrectos.", foreground="red")
            self.password_entry.delete(0, tk.END) # Clear password field

    def _start_main_app(self):
        """
        Destroys the login window and starts the main application on the parent root.
        """
        self.destroy() # Destroy the login window
        self.parent_root.deiconify() # Show the main root window
        # Initialize the main application interface on the parent_root
        InterfazPagos(self.parent_root, self.username_entry.get().strip())


# === START APPLICATION ===
if __name__ == "__main__":
    # Create the initial root window for the entire application
    root = tk.Tk()
    # Hide the main root window initially, so only the login window is visible
    root.withdraw() 
    
    # Create and show the login window
    login_window = LoginWindow(root)
    
    # Start the Tkinter event loop. This will run until the root window is closed.
    root.mainloop()
